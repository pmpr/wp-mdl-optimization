<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58598b21ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Setting\Setting; use Pmpr\Module\Optimization\Traits\CommonTrait; abstract class Container extends BaseClass implements CommonInterface { use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } public function qwmkuasciiicwaie() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return $ewgmommeawggyaek->ksgkoukcicwkkaum() && $ewgmommeawggyaek->scmcyesmmikkucie(); } public function miueaekaaugaccmg(&$iswcokucwmiosiaq, ?string $aiowsaccomcoikus = self::xwwaeweqegiqeqkm, ?string $aiamqeawckcsuaou = self::waoywqksqecymesy) : bool { $kuuugksiksqcaaaa = parent::miueaekaaugaccmg($iswcokucwmiosiaq, $aiowsaccomcoikus, $aiamqeawckcsuaou); if (!($kuuugksiksqcaaaa && !$this->qwmkuasciiicwaie())) { goto eqemcocqsyasqycq; } $iswcokucwmiosiaq = __("\120\145\162\x6d\x69\163\163\x69\157\156\40\x64\145\156\151\145\x64", PR__MDL__OPTIMIZATION); eqemcocqsyasqycq: return $kuuugksiksqcaaaa; } }
