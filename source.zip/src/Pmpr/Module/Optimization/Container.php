<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd253c8f77d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Setting\Setting; use Pmpr\Module\Optimization\Traits\CommonTrait; abstract class Container extends BaseClass implements CommonInterface { use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } public function qwmkuasciiicwaie() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return $ewgmommeawggyaek->ksgkoukcicwkkaum() && $ewgmommeawggyaek->scmcyesmmikkucie(); } public function miueaekaaugaccmg(&$iswcokucwmiosiaq, ?string $aiowsaccomcoikus = self::xwwaeweqegiqeqkm, ?string $aiamqeawckcsuaou = self::waoywqksqecymesy) : bool { $kuuugksiksqcaaaa = parent::miueaekaaugaccmg($iswcokucwmiosiaq, $aiowsaccomcoikus, $aiamqeawckcsuaou); if (!($kuuugksiksqcaaaa && !$this->qwmkuasciiicwaie())) { goto mgiwqumikeuieocg; } $iswcokucwmiosiaq = __("\120\145\162\x6d\x69\163\163\151\157\x6e\x20\144\145\x6e\151\x65\x64", PR__MDL__OPTIMIZATION); mgiwqumikeuieocg: return $kuuugksiksqcaaaa; } }
