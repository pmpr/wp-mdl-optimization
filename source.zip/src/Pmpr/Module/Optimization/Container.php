<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668664c7535d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Setting\Setting; use Pmpr\Module\Optimization\Traits\CommonTrait; abstract class Container extends BaseClass implements CommonInterface { use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } public function qwmkuasciiicwaie() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return $ewgmommeawggyaek->ksgkoukcicwkkaum() && $ewgmommeawggyaek->scmcyesmmikkucie(); } public function miueaekaaugaccmg(&$iswcokucwmiosiaq, ?string $aiowsaccomcoikus = self::xwwaeweqegiqeqkm, ?string $aiamqeawckcsuaou = self::waoywqksqecymesy) : bool { $kuuugksiksqcaaaa = parent::miueaekaaugaccmg($iswcokucwmiosiaq, $aiowsaccomcoikus, $aiamqeawckcsuaou); if (!($kuuugksiksqcaaaa && !$this->qwmkuasciiicwaie())) { goto qsygcycwieukkgwc; } $iswcokucwmiosiaq = __("\120\145\162\155\151\x73\x73\x69\x6f\156\x20\144\x65\156\151\x65\144", PR__MDL__OPTIMIZATION); qsygcycwieukkgwc: return $kuuugksiksqcaaaa; } }
