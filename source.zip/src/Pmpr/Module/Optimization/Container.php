<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8b6b9a73             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Setting\Setting; use Pmpr\Module\Optimization\Traits\CommonTrait; abstract class Container extends BaseClass implements CommonInterface { use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } public function qwmkuasciiicwaie() : bool { $ewgmommeawggyaek = $this->uwkmaywceaaaigwo()->issssuygyewuaswa(); return $ewgmommeawggyaek->ksgkoukcicwkkaum() && $ewgmommeawggyaek->scmcyesmmikkucie(); } public function miueaekaaugaccmg(&$iswcokucwmiosiaq, ?string $aiowsaccomcoikus = self::xwwaeweqegiqeqkm, ?string $aiamqeawckcsuaou = self::waoywqksqecymesy) : bool { $kuuugksiksqcaaaa = parent::miueaekaaugaccmg($iswcokucwmiosiaq, $aiowsaccomcoikus, $aiamqeawckcsuaou); if (!($kuuugksiksqcaaaa && !$this->qwmkuasciiicwaie())) { goto qsygcycwieukkgwc; } $iswcokucwmiosiaq = __("\x50\x65\162\155\151\x73\163\151\x6f\156\x20\x64\x65\x6e\x69\x65\144", PR__MDL__OPTIMIZATION); qsygcycwieukkgwc: return $kuuugksiksqcaaaa; } }
