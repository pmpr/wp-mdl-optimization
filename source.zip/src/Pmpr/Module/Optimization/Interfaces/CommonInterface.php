<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a697384             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Interfaces; interface CommonInterface { const scskcyisyowcuagq = self::kgswyesggeyekgmg . "\x62\165\x66\x66\145\162\x5f\x70\162\157\x63\145\163\163"; const qsmgiigmguoewgga = self::kgswyesggeyekgmg . "\x70\162\145\154\x6f\x61\144\x5f\162\165\x6e\156\151\x6e\147"; const mcaqmysyscusmsac = self::kgswyesggeyekgmg . "\160\162\x65\154\x6f\x61\x64\x5f\x6a\157\142\137"; const kegeqyusqiqwoogi = self::mcaqmysyscusmsac . "\160\x72\x65\154\x6f\x61\144\137\x75\162\x6c"; const hwawamsmicyywemy = "\x63\141\143\150\x65\137\163\x74\141\164\165\x73"; const csqewiewikwcmcug = "\x6d\x6f\x62\x69\154\x65\137\143\141\x63\150\x65\x5f\x73\164\141\x74\x75\163"; const qmaukyqwkwkuouoo = "\x64\145\163\153\164\x6f\x70\137\x63\x61\143\x68\x65\x5f\x73\x74\x61\x74\165\x73"; }
