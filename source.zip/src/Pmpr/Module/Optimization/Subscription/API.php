<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\x75\x62\163\x63\x72\151\x70\x74\151\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\146\x65\x74\143\150\55\x64\141\x74\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto cmmusgkieoqyymgs; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); cmmusgkieoqyymgs: return $sogksuscggsicmac; } }
