<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66696e7e43c2d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\x75\142\x73\143\x72\151\160\x74\151\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x66\x65\164\x63\x68\55\144\141\164\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto wcesymwqykqoyuqk; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; wcesymwqykqoyuqk: return $sogksuscggsicmac; } }
