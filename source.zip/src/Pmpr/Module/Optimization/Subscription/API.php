<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f17f3222             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\x75\142\x73\x63\162\x69\160\164\x69\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\145\x74\55\x64\141\164\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto mseokuecmeoyoggk; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; mseokuecmeoyoggk: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\145\x74\55\x70\165\162\143\x68\x61\x73\145\x73\77\x70\141\x67\x65\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto uookseqsmsqgweuy; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; uookseqsmsqgweuy: return $sogksuscggsicmac; } }
