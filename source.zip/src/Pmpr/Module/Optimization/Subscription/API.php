<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b73dc7163             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\x75\142\163\143\162\151\160\x74\x69\157\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\145\x74\55\x64\x61\164\x61"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x67\145\x74\55\160\165\162\x63\x68\141\x73\x65\163\77\160\x61\147\145\75{$suaemuyiacqyugsm}"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } }
