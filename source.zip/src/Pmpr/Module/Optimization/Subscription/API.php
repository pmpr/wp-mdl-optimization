<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665afacdd5cec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\163\x75\142\x73\143\162\151\160\164\151\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\146\x65\164\x63\x68\x2d\144\141\x74\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto goacqqsgaaigyuaw; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); goacqqsgaaigyuaw: return $sogksuscggsicmac; } }
