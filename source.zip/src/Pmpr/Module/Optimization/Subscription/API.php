<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed4e3da1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\163\165\142\x73\143\x72\151\x70\x74\151\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\146\x65\164\x63\150\55\x64\141\164\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto goacqqsgaaigyuaw; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); goacqqsgaaigyuaw: return $sogksuscggsicmac; } }
