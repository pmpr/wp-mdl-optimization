<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663757b0e9f86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\163\165\x62\163\x63\162\x69\x70\x74\x69\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x66\x65\164\143\150\55\x64\x61\x74\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto cmmusgkieoqyymgs; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); cmmusgkieoqyymgs: return $sogksuscggsicmac; } }
