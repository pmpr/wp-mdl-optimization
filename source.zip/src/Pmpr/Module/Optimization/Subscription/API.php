<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634ff5a86835             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\x75\x62\x73\143\162\151\x70\x74\x69\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x66\x65\164\143\150\55\144\141\164\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto cmmusgkieoqyymgs; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); cmmusgkieoqyymgs: return $sogksuscggsicmac; } }
