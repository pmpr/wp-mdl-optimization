<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668664c7535d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\165\x62\x73\x63\x72\151\x70\x74\x69\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\145\x74\55\x64\x61\164\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto sequgigsgkqaikmq; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; sequgigsgkqaikmq: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\145\164\55\x70\165\x72\x63\150\x61\x73\145\x73\77\x70\x61\147\145\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto aemoyqueimayqcaw; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; aemoyqueimayqcaw: return $sogksuscggsicmac; } }
