<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2393d5ec4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\165\x62\163\x63\162\x69\160\x74\151\157\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\x65\x74\55\x64\x61\x74\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto sckyiekoceuisqyq; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; sckyiekoceuisqyq: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x67\x65\164\55\160\165\162\x63\150\x61\163\145\x73\77\160\x61\147\x65\x3d{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto kusuakkwcuqkcqaw; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; kusuakkwcuqkcqaw: return $sogksuscggsicmac; } }
