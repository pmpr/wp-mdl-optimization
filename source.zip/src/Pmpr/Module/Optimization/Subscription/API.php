<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a555dadc1bf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\163\x75\x62\163\x63\x72\151\160\x74\151\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\145\164\55\144\x61\x74\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto akwwuuiykscgicuw; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; akwwuuiykscgicuw: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\x65\x74\55\160\165\x72\143\150\141\163\x65\163\x3f\160\x61\x67\x65\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto ueqsiwuwumoqgsck; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; ueqsiwuwumoqgsck: return $sogksuscggsicmac; } }
