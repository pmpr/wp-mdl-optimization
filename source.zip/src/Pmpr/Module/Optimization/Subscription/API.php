<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69f59378cd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\x75\x62\x73\143\162\x69\x70\x74\151\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\x65\164\x2d\x64\x61\x74\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto kkmwwqyesmkescyg; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; kkmwwqyesmkescyg: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\145\164\55\160\165\162\143\150\141\x73\x65\x73\x3f\160\x61\147\145\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto uamuuwkyuqomqyuy; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; uamuuwkyuqomqyuy: return $sogksuscggsicmac; } }
