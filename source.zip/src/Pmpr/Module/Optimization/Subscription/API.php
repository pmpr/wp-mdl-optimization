<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fa68d1c92             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\x75\142\163\x63\x72\151\x70\164\151\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\x65\x74\x2d\144\141\164\x61"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\145\164\55\160\x75\162\143\150\x61\x73\x65\163\77\x70\141\x67\x65\75{$suaemuyiacqyugsm}"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } }
