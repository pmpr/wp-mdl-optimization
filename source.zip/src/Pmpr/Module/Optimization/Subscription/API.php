<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637558f2381c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\x75\142\163\143\x72\151\x70\x74\151\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x66\x65\x74\x63\150\x2d\x64\x61\164\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto cmmusgkieoqyymgs; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); cmmusgkieoqyymgs: return $sogksuscggsicmac; } }
