<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32325cda1b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\163\x75\142\163\x63\x72\151\160\164\151\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\145\164\55\x64\x61\x74\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto ikuwigsmisimaqoc; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; ikuwigsmisimaqoc: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\145\164\55\x70\165\162\x63\x68\141\x73\145\163\x3f\160\141\x67\145\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto sigukociqouigous; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; sigukociqouigous: return $sogksuscggsicmac; } }
