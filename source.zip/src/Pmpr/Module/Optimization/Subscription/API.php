<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665f4289276f4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\x75\142\x73\x63\162\151\160\164\151\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x66\x65\164\x63\150\x2d\x64\141\164\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto goacqqsgaaigyuaw; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); goacqqsgaaigyuaw: return $sogksuscggsicmac; } }
