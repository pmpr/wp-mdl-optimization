<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c4e0adc06c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\x75\142\163\x63\x72\151\160\x74\x69\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\x65\164\55\144\x61\164\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto icuukwkwqeoogyae; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; icuukwkwqeoogyae: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x67\x65\164\x2d\160\165\x72\143\150\141\x73\x65\x73\x3f\160\x61\x67\145\x3d{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto iwcmgioeaiyuacwi; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; iwcmgioeaiyuacwi: return $sogksuscggsicmac; } }
