<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69a35d5c5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\165\x62\x73\x63\162\151\160\x74\x69\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x67\x65\164\55\x64\x61\x74\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto kkmwwqyesmkescyg; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; kkmwwqyesmkescyg: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\x65\x74\55\160\x75\x72\143\150\141\x73\145\163\77\x70\x61\147\x65\x3d{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto uamuuwkyuqomqyuy; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; uamuuwkyuqomqyuy: return $sogksuscggsicmac; } }
