<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400e520636             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\163\x75\142\163\143\162\151\160\164\151\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\x65\164\x2d\144\x61\164\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto seaiwkkgyyegiyug; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; seaiwkkgyyegiyug: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\x65\x74\55\x70\x75\162\x63\x68\141\163\x65\x73\77\160\141\147\145\x3d{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto uauuoyigkmqoasaq; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; uauuoyigkmqoasaq: return $sogksuscggsicmac; } }
