<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aecacc41ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\165\142\x73\143\162\151\160\x74\x69\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x66\145\164\x63\x68\55\144\141\164\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto goacqqsgaaigyuaw; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); goacqqsgaaigyuaw: return $sogksuscggsicmac; } }
