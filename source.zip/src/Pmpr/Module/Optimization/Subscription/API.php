<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb3b4b1ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\165\x62\x73\x63\162\151\160\x74\151\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\x65\164\x2d\x64\141\x74\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto uaiiuywoakccusge; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; uaiiuywoakccusge: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\145\164\x2d\160\x75\x72\x63\150\x61\163\x65\x73\x3f\160\x61\147\145\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto ysiwoiqiaosqoikm; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; ysiwoiqiaosqoikm: return $sogksuscggsicmac; } }
