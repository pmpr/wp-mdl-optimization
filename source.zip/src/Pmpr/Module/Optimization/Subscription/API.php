<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635046c437f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\165\x62\163\x63\162\x69\160\164\151\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\146\145\x74\x63\x68\x2d\144\141\164\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto cmmusgkieoqyymgs; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); cmmusgkieoqyymgs: return $sogksuscggsicmac; } }
