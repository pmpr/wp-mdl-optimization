<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f43f6aa4f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\x73\165\142\x73\x63\162\x69\x70\164\x69\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\x65\x74\x2d\x64\141\164\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto seaiwkkgyyegiyug; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; seaiwkkgyyegiyug: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x67\x65\x74\55\x70\x75\162\143\x68\x61\163\x65\163\77\x70\141\x67\x65\x3d{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto uauuoyigkmqoasaq; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; uauuoyigkmqoasaq: return $sogksuscggsicmac; } }
