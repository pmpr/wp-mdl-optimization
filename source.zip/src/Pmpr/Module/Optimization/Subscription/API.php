<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7059178ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\x73\x75\142\x73\x63\162\x69\x70\164\151\x6f\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\x65\x74\x2d\x64\141\x74\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto esgyqksmcukeuwyk; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; esgyqksmcukeuwyk: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\x65\x74\x2d\x70\165\162\x63\150\141\163\145\163\x3f\x70\x61\147\x65\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto iigmgswcogqemgao; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; iigmgswcogqemgao: return $sogksuscggsicmac; } }
