<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66872493a1a65             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\163\165\x62\x73\143\162\x69\160\164\151\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\x65\164\55\x64\141\164\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto mmqkuymyyycywmqu; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; mmqkuymyyycywmqu: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x67\145\164\x2d\x70\165\x72\x63\x68\141\x73\145\x73\x3f\x70\x61\147\x65\x3d{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto iaockwkwaiqgeuyu; } $sogksuscggsicmac = $sogksuscggsicmac[self::uiwqcumqkgikqyue] ?? []; iaockwkwaiqgeuyu: return $sogksuscggsicmac; } }
