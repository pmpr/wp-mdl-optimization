<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aec46370c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Traits\SubscriptionEngineTrait; class Subscription extends Common { use SubscriptionEngineTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu(Process::yagmsygwcocaqmqy, [$this, "\x61\143\147\145\151\143\143\x6f\x77\143\161\x69\x77\x6d\161\141"]); } public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kecwuwwcwokuksyq; } Ajax::symcgieuakksimmu(); kecwuwwcwokuksyq: } public function acgeiccowcqiwmqa() { $this->cqscwmqsgomkogoq()->acgeiccowcqiwmqa(); } }
