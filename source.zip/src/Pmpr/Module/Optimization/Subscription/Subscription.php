<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634ff5a86835             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Traits\SubscriptionEngineTrait; class Subscription extends Common { use SubscriptionEngineTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu(Process::yagmsygwcocaqmqy, [$this, "\141\x63\147\x65\x69\x63\143\157\x77\x63\x71\x69\x77\155\161\x61"]); } public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto mkgmaguyswskyioa; } Ajax::symcgieuakksimmu(); mkgmaguyswskyioa: } public function acgeiccowcqiwmqa() { $this->cqscwmqsgomkogoq()->acgeiccowcqiwmqa(); } }
