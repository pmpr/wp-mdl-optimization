<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Traits\SubscriptionEngineTrait; class Subscription extends Common { use SubscriptionEngineTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu(Process::yagmsygwcocaqmqy, [$this, "\141\143\147\x65\x69\143\x63\x6f\x77\143\x71\x69\167\155\x71\x61"]); } public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kecwuwwcwokuksyq; } Ajax::symcgieuakksimmu(); kecwuwwcwokuksyq: } public function acgeiccowcqiwmqa() { $this->cqscwmqsgomkogoq()->acgeiccowcqiwmqa(); } }
