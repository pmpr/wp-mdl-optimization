<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6654cb65a9906             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Traits\SubscriptionEngineTrait; class Subscription extends Common { use SubscriptionEngineTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu(Process::yagmsygwcocaqmqy, [$this, "\141\x63\147\145\151\x63\x63\157\x77\x63\x71\x69\167\155\161\141"]); } public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kecwuwwcwokuksyq; } Ajax::symcgieuakksimmu(); kecwuwwcwokuksyq: } public function acgeiccowcqiwmqa() { $this->cqscwmqsgomkogoq()->acgeiccowcqiwmqa(); } }
