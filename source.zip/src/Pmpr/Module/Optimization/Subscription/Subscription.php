<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Traits\SubscriptionEngineTrait; class Subscription extends Common { use SubscriptionEngineTrait; public function wigskegsqequoeks() { $this->qcsmikeggeemccuu(Process::yagmsygwcocaqmqy, [$this, "\141\143\147\145\x69\x63\x63\x6f\x77\x63\161\x69\167\x6d\x71\x61"]); } public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto kecwuwwcwokuksyq; } Ajax::symcgieuakksimmu(); kecwuwwcwokuksyq: } public function acgeiccowcqiwmqa() { $this->cqscwmqsgomkogoq()->acgeiccowcqiwmqa(); } }
