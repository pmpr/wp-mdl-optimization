<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668660e287d70             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription\Model; use Pmpr\Module\Optimization\Model; abstract class Common extends Model { const yocqkmeouaamomke = "\157\162\151\147\151\x6e\x5f\151\144"; public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->qemeyueyiwgsokuc(); } }
