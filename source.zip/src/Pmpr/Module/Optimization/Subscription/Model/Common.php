<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788399683ac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription\Model; use Pmpr\Module\Optimization\Model; abstract class Common extends Model { const yocqkmeouaamomke = "\157\162\x69\147\151\x6e\x5f\x69\x64"; public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->qemeyueyiwgsokuc(); } }
