<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686aaf854850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription\Model; use Pmpr\Module\Optimization\Model; abstract class Common extends Model { const yocqkmeouaamomke = "\157\162\151\147\151\156\137\x69\144"; public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->qemeyueyiwgsokuc(); } }
