<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d5dd19f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription\Model; use Pmpr\Module\Optimization\Model; abstract class Common extends Model { const yocqkmeouaamomke = "\157\162\151\147\x69\156\137\151\144"; public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->qemeyueyiwgsokuc(); } }
