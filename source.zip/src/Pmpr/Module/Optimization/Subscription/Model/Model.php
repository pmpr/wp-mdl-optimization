<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b3f9de7f0df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription\Model; use Pmpr\Module\Optimization\Subscription\Common; class Model extends Common { public function mameiwsayuyquoeq() { Purchase::symcgieuakksimmu(); } }
