<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const yagmsygwcocaqmqy = self::kgswyesggeyekgmg . "\x6a\x6f\142\137\146\x65\x74\143\x68\137\x73\x75\142\x73\143\x72\x69\160\164\x69\x6f\156\x5f\144\x61\x74\141"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x73\165\x62\163\143\x72\x69\x70\x74\x69\157\x6e"; } public function gqgseoowsgqemmgu() : int { return $this->ooosmymooksgmyos(time(), self::wmasmcgmyeoaisoa, self::yagmsygwcocaqmqy); } }
