<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665afacdd5cec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const yagmsygwcocaqmqy = self::kgswyesggeyekgmg . "\152\x6f\x62\x5f\x66\x65\164\x63\x68\x5f\x73\165\142\163\x63\162\151\x70\x74\151\157\x6e\137\144\x61\164\141"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\163\165\142\163\x63\x72\x69\160\x74\151\x6f\x6e"; } public function gqgseoowsgqemmgu() : int { return $this->ooosmymooksgmyos(time(), self::wmasmcgmyeoaisoa, self::yagmsygwcocaqmqy); } }
