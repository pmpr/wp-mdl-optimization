<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f163107a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const yagmsygwcocaqmqy = self::kgswyesggeyekgmg . "\152\x6f\142\137\146\x65\x74\143\x68\x5f\x73\165\x62\x73\143\x72\x69\x70\164\x69\157\x6e\x5f\144\141\x74\141"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x73\x75\x62\163\143\x72\x69\x70\164\x69\157\156"; } public function gqgseoowsgqemmgu() : int { return $this->ooosmymooksgmyos(time(), self::wmasmcgmyeoaisoa, self::yagmsygwcocaqmqy); } }
