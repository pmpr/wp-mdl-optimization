<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668aef2e0bbf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const yagmsygwcocaqmqy = self::kgswyesggeyekgmg . "\x6a\157\142\x5f\x66\145\164\143\150\137\163\x75\x62\163\x63\162\x69\x70\164\151\x6f\156\137\x64\141\164\141"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\163\165\142\x73\143\x72\x69\x70\164\x69\x6f\x6e"; } public function gqgseoowsgqemmgu() : int { return $this->ooosmymooksgmyos(time(), self::wmasmcgmyeoaisoa, self::yagmsygwcocaqmqy); } }
