<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2e8b4802f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const yagmsygwcocaqmqy = self::kgswyesggeyekgmg . "\152\x6f\x62\137\x66\x65\x74\x63\150\137\163\165\x62\x73\143\x72\x69\160\x74\151\x6f\156\x5f\144\141\x74\141"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x73\165\x62\163\143\162\x69\x70\x74\x69\x6f\x6e"; } public function gqgseoowsgqemmgu() : int { return $this->ooosmymooksgmyos(time(), self::wmasmcgmyeoaisoa, self::yagmsygwcocaqmqy); } }
