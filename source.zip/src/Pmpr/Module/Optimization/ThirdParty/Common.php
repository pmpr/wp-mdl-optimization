<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f163107a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\Container; abstract class Common extends Container { }
