<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4f986c850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\Container; abstract class Common extends Container { }
