<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\Container; abstract class Common extends Container { }
