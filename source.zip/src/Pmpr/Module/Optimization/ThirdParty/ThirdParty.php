<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66369e99bb80d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\ThirdParty\CDN\CDN; class ThirdParty extends Common { public function mameiwsayuyquoeq() { CDN::symcgieuakksimmu(); } }
