<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b4bcd5eb86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\Asset; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\JSDeliver; use Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare\Cloudflare; class ThirdParty extends Container { public function mameiwsayuyquoeq() { JSDeliver::symcgieuakksimmu(); Cloudflare::symcgieuakksimmu(); } }
