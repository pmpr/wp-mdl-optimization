<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a57ce0afbe8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\ThirdParty\CDN\CDN; class ThirdParty extends Common { public function mameiwsayuyquoeq() { CDN::symcgieuakksimmu(); } }
