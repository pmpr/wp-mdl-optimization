<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf8fcabf8fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\ThirdParty\CDN\CDN; class ThirdParty extends Common { public function mameiwsayuyquoeq() { CDN::symcgieuakksimmu(); } }
