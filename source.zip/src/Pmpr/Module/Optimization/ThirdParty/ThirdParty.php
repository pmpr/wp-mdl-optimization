<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63f5133702             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\Asset; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\JSDeliver; use Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare\Cloudflare; class ThirdParty extends Container { public function mameiwsayuyquoeq() { JSDeliver::symcgieuakksimmu(); Cloudflare::symcgieuakksimmu(); } }
