<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7139a54fa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN; use Pmpr\Module\Optimization\ThirdParty\Common as BaseClass; abstract class Common extends BaseClass { }
