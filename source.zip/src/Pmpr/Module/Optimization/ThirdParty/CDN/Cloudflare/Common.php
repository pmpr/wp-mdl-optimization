<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\x63\x6c\157\165\x64\146\154\141\x72\145"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\x63\x61\143\x68\145\137\x6d\x65\164\x61\144\x61\x74\141"; private ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto yqqseqskcqeqkacm; } $this->engine = Engine::symcgieuakksimmu(); yqqseqskcqeqkacm: return $this->engine; } public function yusooeuwemoqcwmm() : bool { return Setting::symcgieuakksimmu()->yusooeuwemoqcwmm(); } public function qoyqoeoicgmuskoc() : bool { return (bool) $this->weysguygiseoukqw(Setting::amkasseuucsemuqm); } }
