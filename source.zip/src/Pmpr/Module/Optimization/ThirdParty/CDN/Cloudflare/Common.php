<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689b42493617             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\143\x6c\157\165\x64\146\154\x61\x72\145"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\143\141\143\150\145\x5f\155\145\x74\x61\144\x61\164\x61"; private ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto quewwumogiocouii; } $this->engine = Engine::symcgieuakksimmu(); quewwumogiocouii: return $this->engine; } public function yusooeuwemoqcwmm() : bool { return Setting::symcgieuakksimmu()->yusooeuwemoqcwmm(); } public function qoyqoeoicgmuskoc() : bool { return (bool) $this->weysguygiseoukqw(Setting::amkasseuucsemuqm); } }
