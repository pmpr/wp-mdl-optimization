<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663506337ce5d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\x63\154\x6f\x75\144\x66\x6c\x61\x72\x65"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\x63\x61\x63\x68\145\137\x6d\x65\x74\x61\x64\141\164\141"; public function yusooeuwemoqcwmm() : bool { return $this->weysguygiseoukqw(Setting::kwuagsmkgsoqgqqi) && $this->weysguygiseoukqw(Setting::iqksqseqeqmaukkk); } public function yoaiuuuwwssswyqa() { return $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->get(Setting::waugumayqaqkeeqq, self::OFF); } public function awwuyycwuuuggkqy($eqgoocgaqwqcimie) { $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->update(Setting::waugumayqaqkeeqq, $eqgoocgaqwqcimie); } public function eisusiekaciioueg() : bool { return $this->yoaiuuuwwssswyqa() === self::ON; } }
