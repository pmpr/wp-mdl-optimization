<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689580cbf1c8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\x63\154\x6f\165\144\x66\154\x61\162\145"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\143\x61\143\x68\145\137\155\145\164\x61\x64\x61\x74\x61"; private ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto mgwgiesscqoaqcau; } $this->engine = Engine::symcgieuakksimmu(); mgwgiesscqoaqcau: return $this->engine; } public function yusooeuwemoqcwmm() : bool { return Setting::symcgieuakksimmu()->yusooeuwemoqcwmm(); } public function qoyqoeoicgmuskoc() : bool { return (bool) $this->weysguygiseoukqw(Setting::amkasseuucsemuqm); } }
