<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb3b4b1ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\143\154\x6f\165\x64\x66\154\x61\x72\x65"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\143\141\x63\x68\x65\137\155\145\164\141\x64\141\164\x61"; private ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto mgwgiesscqoaqcau; } $this->engine = Engine::symcgieuakksimmu(); mgwgiesscqoaqcau: return $this->engine; } public function yusooeuwemoqcwmm() : bool { return Setting::symcgieuakksimmu()->yusooeuwemoqcwmm(); } public function qoyqoeoicgmuskoc() : bool { return (bool) $this->weysguygiseoukqw(Setting::amkasseuucsemuqm); } }
