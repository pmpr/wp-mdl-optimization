<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350bd82c2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\x63\x6c\x6f\x75\x64\x66\154\x61\x72\x65"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\x63\141\143\150\x65\137\155\x65\164\141\144\x61\164\141"; public function yusooeuwemoqcwmm() : bool { return $this->weysguygiseoukqw(Setting::kwuagsmkgsoqgqqi) && $this->weysguygiseoukqw(Setting::iqksqseqeqmaukkk); } public function yoaiuuuwwssswyqa() { return $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->get(Setting::waugumayqaqkeeqq, self::OFF); } public function awwuyycwuuuggkqy($eqgoocgaqwqcimie) { $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->update(Setting::waugumayqaqkeeqq, $eqgoocgaqwqcimie); } public function eisusiekaciioueg() : bool { return $this->yoaiuuuwwssswyqa() === self::ON; } }
