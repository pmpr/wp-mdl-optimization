<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b20910f9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\Container; abstract class Common extends Container { private ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if (!$this->engine) { $this->engine = Engine::symcgieuakksimmu(); } return $this->engine; } public function yusooeuwemoqcwmm() : bool { return $this->weysguygiseoukqw(Setting::kwuagsmkgsoqgqqi) && $this->weysguygiseoukqw(Setting::iqksqseqeqmaukkk); } public function qoyqoeoicgmuskoc() : bool { return (bool) $this->weysguygiseoukqw(Setting::amkasseuucsemuqm); } }
