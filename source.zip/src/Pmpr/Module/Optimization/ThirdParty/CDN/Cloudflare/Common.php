<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a57ce0afbe8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\143\154\x6f\165\144\146\154\141\x72\145"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\143\x61\x63\150\x65\x5f\x6d\145\x74\x61\x64\x61\x74\141"; private ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto wmmggowmigekyoso; } $this->engine = Engine::symcgieuakksimmu(); wmmggowmigekyoso: return $this->engine; } public function yusooeuwemoqcwmm() : bool { return Setting::symcgieuakksimmu()->yusooeuwemoqcwmm(); } public function qoyqoeoicgmuskoc() : bool { return (bool) $this->weysguygiseoukqw(Setting::amkasseuucsemuqm); } }
