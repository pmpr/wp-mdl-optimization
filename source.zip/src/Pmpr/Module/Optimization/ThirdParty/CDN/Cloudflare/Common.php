<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637d2bee1dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { const kakkwkmmmaykeoeq = self::kgswyesggeyekgmg . "\x63\x6c\x6f\x75\x64\146\x6c\141\162\x65"; const suyoqewagugqoeuy = self::kakkwkmmmaykeoeq . self::wassgkgmoyygyaya; const cuocomkikquemaqq = self::suyoqewagugqoeuy . "\143\x61\x63\x68\145\x5f\155\145\164\141\144\141\164\x61"; public function yusooeuwemoqcwmm() : bool { return $this->weysguygiseoukqw(Setting::kwuagsmkgsoqgqqi) && $this->weysguygiseoukqw(Setting::iqksqseqeqmaukkk); } public function yoaiuuuwwssswyqa() { return $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->get(Setting::waugumayqaqkeeqq, self::OFF); } public function awwuyycwuuuggkqy($eqgoocgaqwqcimie) { $this->uwkmaywceaaaigwo()->giiuwsmyumqwwiyq()->update(Setting::waugumayqaqkeeqq, $eqgoocgaqwqcimie); } public function eisusiekaciioueg() : bool { return $this->yoaiuuuwwssswyqa() === self::ON; } }
