<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668709b77727f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\JSDeliver; class Asset extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); JSDeliver::symcgieuakksimmu(); } }
