<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c6c5682             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\JSDeliver; class Asset extends Common { public function mameiwsayuyquoeq() { JSDeliver::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto yoauoocuckogmsuw; } Setting::symcgieuakksimmu(); yoauoocuckogmsuw: } }
