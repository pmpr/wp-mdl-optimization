<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\x73\145\164\x5f\143\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\x6f\x6e\164\x65\x6e\164\40\x44\x65\x6c\151\166\x65\x72\171\40\x4e\x65\164\167\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\141\x70\x74\x20\x77\x69\164\x68\40\103\x44\x4e\x73", PR__MDL__OPTIMIZATION))); } }
