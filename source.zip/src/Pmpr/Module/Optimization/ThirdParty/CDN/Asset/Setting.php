<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb0c5939             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\x73\x65\x74\137\143\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\x6f\x6e\x74\x65\156\164\40\104\x65\154\151\166\x65\162\x79\x20\116\x65\x74\x77\157\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\141\160\164\x20\x77\151\164\x68\40\x43\104\116\x73", PR__MDL__OPTIMIZATION))); } }
