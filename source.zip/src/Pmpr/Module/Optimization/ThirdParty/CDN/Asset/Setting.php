<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f9435286             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\x73\145\x74\x5f\143\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\x6f\x6e\164\x65\156\164\x20\104\x65\154\x69\x76\x65\x72\171\x20\x4e\x65\164\x77\157\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\x64\x61\160\164\x20\167\x69\164\x68\40\103\x44\x4e\x73", PR__MDL__OPTIMIZATION))); } }
