<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5704a7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\x73\145\164\x5f\143\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\x6e\164\145\156\164\40\104\145\x6c\x69\166\x65\x72\x79\40\116\x65\164\x77\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\x70\164\40\167\151\164\150\40\x43\104\x4e\x73", PR__MDL__OPTIMIZATION))); } }
