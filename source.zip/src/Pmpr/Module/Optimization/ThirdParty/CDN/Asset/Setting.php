<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af1935df9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\163\x65\x74\137\x63\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\156\x74\x65\156\164\x20\x44\x65\x6c\x69\166\x65\162\x79\x20\x4e\145\x74\167\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\141\160\164\x20\x77\151\164\x68\40\x43\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
