<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758115135c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\Setting as JSDeliverSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { JSDeliverSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\x73\145\164\137\143\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\x74\145\156\x74\40\x44\x65\x6c\x69\166\145\162\x79\x20\x4e\145\164\x77\x6f\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\141\160\x74\x20\167\x69\x74\150\x20\103\x44\116\163", PR__MDL__OPTIMIZATION))); } }
