<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668664c7535d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\163\x65\164\137\x63\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\x6e\164\x65\156\x74\x20\104\x65\154\151\166\145\x72\x79\40\x4e\145\164\167\x6f\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\141\160\164\x20\x77\151\x74\150\40\x43\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
