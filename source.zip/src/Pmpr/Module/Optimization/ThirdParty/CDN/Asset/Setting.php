<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31f6c057e7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\163\145\x74\137\x63\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\x6e\164\x65\x6e\x74\x20\104\145\154\x69\166\145\162\171\x20\x4e\x65\x74\x77\x6f\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\160\x74\40\167\151\164\x68\x20\x43\x44\116\x73", PR__MDL__OPTIMIZATION))); } }
