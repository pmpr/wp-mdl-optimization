<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2e8b4802f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\x73\145\164\x5f\143\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\164\145\x6e\x74\40\104\145\154\151\x76\145\x72\171\x20\116\x65\164\x77\x6f\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\x64\x61\x70\164\40\x77\151\x74\150\40\x43\x44\116\x73", PR__MDL__OPTIMIZATION))); } }
