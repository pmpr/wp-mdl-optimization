<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8e1ec93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\Setting as JSDeliverSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { JSDeliverSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\163\x65\x74\x5f\x63\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\156\x74\x65\156\x74\x20\x44\145\154\x69\x76\x65\162\x79\x20\x4e\145\164\167\x6f\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\x61\x70\x74\40\167\151\164\x68\x20\x43\104\116\x73", PR__MDL__OPTIMIZATION))); } }
