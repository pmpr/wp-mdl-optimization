<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8b6b9a73             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\x73\145\x74\x5f\143\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\x6e\x74\145\x6e\x74\40\104\145\154\x69\x76\145\x72\x79\x20\x4e\x65\164\x77\x6f\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\x70\x74\40\x77\x69\164\150\40\103\x44\116\163", PR__MDL__OPTIMIZATION))); } }
