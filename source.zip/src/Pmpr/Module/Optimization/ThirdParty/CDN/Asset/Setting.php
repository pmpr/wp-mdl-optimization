<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd253c8f77d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\x73\145\x74\137\143\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\156\164\x65\x6e\x74\40\104\x65\x6c\x69\x76\x65\162\171\x20\116\x65\x74\167\157\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\141\160\x74\x20\167\x69\x74\x68\40\103\x44\x4e\x73", PR__MDL__OPTIMIZATION))); } }
