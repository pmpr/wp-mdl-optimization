<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668b0fe6d179             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\x73\145\164\x5f\143\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\x6e\164\x65\x6e\x74\x20\104\x65\x6c\151\x76\145\162\171\40\x4e\145\x74\167\157\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\x64\x61\160\x74\x20\x77\x69\164\x68\40\x43\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
