<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2337171efe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\163\145\164\x5f\x63\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\156\x74\x65\x6e\x74\x20\x44\145\154\151\x76\x65\162\x79\x20\x4e\145\164\x77\x6f\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\x61\x70\x74\x20\167\x69\x74\x68\40\103\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
