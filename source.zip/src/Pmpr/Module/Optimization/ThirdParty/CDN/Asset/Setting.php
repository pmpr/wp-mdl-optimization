<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635076d1df7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\x73\145\164\x5f\x63\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\156\x74\x65\156\164\x20\104\x65\x6c\x69\x76\145\x72\x79\40\116\145\x74\x77\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\141\x70\x74\x20\167\x69\164\150\40\x43\104\116\x73", PR__MDL__OPTIMIZATION))); } }
