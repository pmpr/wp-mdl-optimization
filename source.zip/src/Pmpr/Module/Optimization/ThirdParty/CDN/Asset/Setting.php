<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581d1c9b1ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\Setting as JSDeliverSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { JSDeliverSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\x73\x65\x74\x5f\143\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\x6e\x74\x65\x6e\164\40\104\145\154\151\166\x65\x72\171\x20\x4e\145\x74\x77\157\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\141\x70\164\40\167\x69\164\x68\x20\x43\x44\x4e\163", PR__MDL__OPTIMIZATION))); } }
