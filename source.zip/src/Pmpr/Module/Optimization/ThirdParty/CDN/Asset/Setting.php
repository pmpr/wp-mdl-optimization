<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56de52d1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\163\x65\x74\x5f\x63\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\x6e\164\x65\156\164\40\x44\x65\x6c\151\x76\x65\162\171\x20\x4e\145\164\x77\157\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\141\x70\164\40\167\x69\x74\150\x20\103\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
