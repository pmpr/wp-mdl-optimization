<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687508050272             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\x73\145\164\137\x63\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\x6f\156\x74\145\156\x74\40\x44\145\154\x69\166\145\x72\x79\x20\116\x65\x74\167\x6f\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\x64\x61\x70\164\40\x77\151\x74\150\x20\103\x44\x4e\163", PR__MDL__OPTIMIZATION))); } }
