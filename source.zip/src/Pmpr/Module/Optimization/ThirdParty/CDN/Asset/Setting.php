<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2182256c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\x73\x65\164\x5f\x63\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\x6f\x6e\164\145\156\x74\40\104\145\154\x69\166\145\x72\x79\40\116\x65\164\x77\157\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\x61\160\164\x20\x77\151\x74\150\x20\103\x44\116\x73", PR__MDL__OPTIMIZATION))); } }
