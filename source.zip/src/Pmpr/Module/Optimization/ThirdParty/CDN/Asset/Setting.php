<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\x73\145\164\137\143\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\x6e\164\145\156\x74\40\104\145\x6c\151\166\145\162\x79\x20\x4e\x65\x74\167\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\141\x70\x74\40\167\151\164\x68\x20\103\x44\116\163", PR__MDL__OPTIMIZATION))); } }
