<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668aef2e0bbf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\163\145\x74\x5f\143\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\x74\x65\x6e\x74\x20\x44\x65\x6c\151\x76\145\x72\x79\x20\116\145\164\x77\x6f\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\160\x74\x20\167\151\x74\150\40\103\104\116\163", PR__MDL__OPTIMIZATION))); } }
