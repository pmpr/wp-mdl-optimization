<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cebac3c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\163\145\164\x5f\x63\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\x6f\156\164\x65\x6e\x74\40\x44\x65\154\151\166\145\x72\x79\x20\x4e\x65\164\x77\157\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\160\x74\40\167\151\x74\150\x20\103\x44\x4e\163", PR__MDL__OPTIMIZATION))); } }
