<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508f721bbb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\163\x65\x74\x5f\143\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\x74\x65\x6e\164\40\x44\x65\154\x69\x76\x65\162\171\x20\x4e\145\164\x77\157\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\x61\160\164\x20\167\151\164\x68\40\103\104\x4e\x73", PR__MDL__OPTIMIZATION))); } }
