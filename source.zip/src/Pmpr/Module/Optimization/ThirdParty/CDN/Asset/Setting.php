<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e6136ef8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\x73\x65\164\x5f\x63\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\156\164\x65\x6e\x74\x20\104\145\154\x69\x76\x65\x72\171\40\116\x65\x74\167\x6f\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\x64\x61\x70\164\x20\167\x69\164\150\40\x43\104\x4e\x73", PR__MDL__OPTIMIZATION))); } }
