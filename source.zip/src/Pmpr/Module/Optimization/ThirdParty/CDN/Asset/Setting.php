<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663506337ce5d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\163\145\164\x5f\143\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\x74\x65\x6e\x74\40\104\145\x6c\151\x76\x65\162\171\40\x4e\x65\164\167\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\141\160\164\x20\167\x69\x74\x68\40\x43\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
