<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79d4da80             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\163\145\x74\x5f\x63\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\x6e\x74\145\x6e\x74\40\x44\x65\x6c\151\x76\x65\162\x79\40\x4e\x65\x74\167\157\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\141\x70\164\x20\167\x69\164\x68\x20\103\x44\x4e\163", PR__MDL__OPTIMIZATION))); } }
