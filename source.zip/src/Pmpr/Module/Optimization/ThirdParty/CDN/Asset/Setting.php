<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4e02be33a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\x73\x65\x74\137\143\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\x6e\x74\x65\x6e\164\40\104\145\x6c\x69\x76\x65\162\x79\x20\x4e\145\x74\x77\x6f\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\x61\160\164\40\x77\151\x74\x68\40\x43\104\x4e\x73", PR__MDL__OPTIMIZATION))); } }
