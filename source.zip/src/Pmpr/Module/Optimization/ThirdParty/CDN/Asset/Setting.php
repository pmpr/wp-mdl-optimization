<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708194f632             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\x73\145\164\x5f\143\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\x6e\x74\145\156\164\40\x44\x65\154\x69\x76\x65\x72\171\40\x4e\x65\x74\167\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\141\x70\x74\x20\x77\151\x74\150\40\103\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
