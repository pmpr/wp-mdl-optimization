<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663757b0e9f86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\x73\x65\x74\137\x63\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\x6e\x74\x65\x6e\164\40\x44\145\154\151\x76\x65\162\x79\40\x4e\x65\x74\167\157\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\x64\141\160\164\x20\167\151\x74\150\x20\103\104\116\x73", PR__MDL__OPTIMIZATION))); } }
