<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a608b965f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\x73\145\164\x5f\143\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\x6e\164\145\x6e\x74\x20\x44\145\x6c\x69\x76\145\x72\171\x20\116\145\164\x77\157\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\160\164\40\167\x69\x74\x68\40\x43\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
