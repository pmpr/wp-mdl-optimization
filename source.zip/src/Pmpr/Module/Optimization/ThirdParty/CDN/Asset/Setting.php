<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6347bb78c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\x73\x65\x74\x5f\x63\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\156\164\145\156\164\40\104\145\x6c\x69\x76\145\162\171\40\x4e\x65\164\167\x6f\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\141\x70\x74\x20\167\x69\164\x68\40\103\x44\116\x73", PR__MDL__OPTIMIZATION))); } }
