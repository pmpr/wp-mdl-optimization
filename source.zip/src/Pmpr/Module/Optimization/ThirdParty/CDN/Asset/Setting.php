<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c5745b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\163\145\164\x5f\x63\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\156\164\145\x6e\x74\x20\x44\x65\154\151\x76\x65\162\x79\40\116\145\x74\167\x6f\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\141\x70\164\40\167\151\x74\x68\40\x43\104\x4e\x73", PR__MDL__OPTIMIZATION))); } }
