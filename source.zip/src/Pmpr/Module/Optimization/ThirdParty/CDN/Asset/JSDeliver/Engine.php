<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668724cd3b441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\CDNData; class Engine extends Common { protected array $items = []; public function wasgwsogmuquqeaa() : array { if ($this->items) { goto mmesoisgqucowwms; } $this->items = CDNData::symcgieuakksimmu()->cwkywyqksyucoyia(); mmesoisgqucowwms: return $this->items; } public function yqgiqqayamyeemuu() { global $wp_scripts, $wp_styles; } public function asqwqaqowgeyyayw() { } }
