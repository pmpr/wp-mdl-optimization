<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ad6e880229             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\CDNData; class Engine extends Common { protected array $items = []; public function wasgwsogmuquqeaa() : array { if ($this->items) { goto ekgkiioywougquka; } $this->items = CDNData::symcgieuakksimmu()->cwkywyqksyucoyia(); ekgkiioywougquka: return $this->items; } public function yqgiqqayamyeemuu() { global $wp_scripts, $wp_styles; } public function asqwqaqowgeyyayw() { } }
