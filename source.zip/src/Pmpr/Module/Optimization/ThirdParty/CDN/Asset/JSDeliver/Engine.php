<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cba0bde7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\CDNData; class Engine extends Common { protected array $items = []; public function wasgwsogmuquqeaa() : array { if ($this->items) { goto yisoawmmammassqk; } $this->items = CDNData::symcgieuakksimmu()->cwkywyqksyucoyia(); yisoawmmammassqk: return $this->items; } public function yqgiqqayamyeemuu() { global $wp_scripts, $wp_styles; } public function asqwqaqowgeyyayw() { } }
