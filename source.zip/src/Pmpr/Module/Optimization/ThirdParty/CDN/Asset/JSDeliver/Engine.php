<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6d38ae4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\CDNData; class Engine extends Common { protected array $items = []; public function wasgwsogmuquqeaa() : array { if ($this->items) { goto aemoyqueimayqcaw; } $this->items = CDNData::symcgieuakksimmu()->cwkywyqksyucoyia(); aemoyqueimayqcaw: return $this->items; } public function yqgiqqayamyeemuu() { global $wp_scripts, $wp_styles; } public function asqwqaqowgeyyayw() { } }
