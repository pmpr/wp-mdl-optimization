<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350bd82c2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\CDNData; class Engine extends Common { protected array $items = []; public function wasgwsogmuquqeaa() : array { if ($this->items) { goto uwaimsisescsgyqk; } $this->items = CDNData::symcgieuakksimmu()->cwkywyqksyucoyia(); uwaimsisescsgyqk: return $this->items; } public function yqgiqqayamyeemuu() { global $wp_scripts, $wp_styles; } public function asqwqaqowgeyyayw() { } }
