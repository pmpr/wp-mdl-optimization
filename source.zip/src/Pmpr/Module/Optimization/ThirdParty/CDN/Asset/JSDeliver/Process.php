<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = self::kgswyesggeyekgmg . "\152\163\144\x65\x6c\x69\166\145\162\x5f\141\x6e\141\154\171\x7a\x65\137\163\157\165\x72\143\x65\163\137\150\157\157\x6b"; const akguikecmoggsykg = self::kgswyesggeyekgmg . "\152\163\144\145\154\151\x76\x65\162\137\x72\145\155\x6f\x76\x65\137\x6f\x6c\x64\x5f\x73\157\165\x72\x63\x65\163\137\150\157\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\163\144\x65\154\151\x76\x65\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
