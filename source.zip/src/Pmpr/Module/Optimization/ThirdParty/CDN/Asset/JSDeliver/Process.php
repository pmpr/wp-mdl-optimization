<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa800b89726             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\x73\144\145\154\151\x76\145\x72\137\141\156\x61\x6c\x79\172\145\137\x73\157\165\x72\143\145\x73\137\150\x6f\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\x73\x64\x65\x6c\x69\166\x65\x72\137\x72\145\155\x6f\166\x65\x5f\x6f\154\144\137\x73\157\165\x72\x63\145\x73\137\x68\x6f\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\144\x65\154\x69\166\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
