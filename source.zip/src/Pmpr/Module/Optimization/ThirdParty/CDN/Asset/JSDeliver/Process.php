<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ea6553f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\163\144\145\x6c\151\166\145\162\x5f\x61\x6e\x61\154\x79\x7a\x65\137\x73\x6f\165\x72\x63\x65\163\x5f\x68\x6f\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\163\144\145\154\151\166\145\162\137\x72\x65\155\157\166\x65\x5f\x6f\154\x64\137\163\157\x75\162\143\145\163\137\150\157\157\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\163\x64\x65\x6c\151\166\145\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
