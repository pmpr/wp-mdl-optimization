<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae90c7cdea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\x73\144\145\x6c\151\166\x65\x72\137\141\156\141\154\x79\x7a\x65\137\163\157\x75\162\143\145\x73\137\x68\x6f\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\163\144\x65\x6c\x69\166\145\x72\x5f\x72\145\155\157\x76\x65\137\x6f\x6c\144\137\x73\157\x75\162\x63\x65\x73\137\x68\x6f\x6f\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\163\144\x65\x6c\x69\x76\x65\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
