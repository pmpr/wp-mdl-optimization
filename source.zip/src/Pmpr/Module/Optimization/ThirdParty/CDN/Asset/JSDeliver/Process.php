<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581d1c9b1ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\163\x64\x65\154\151\166\145\x72\137\141\156\141\154\171\172\x65\137\163\157\165\162\x63\145\x73\x5f\150\x6f\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\163\144\145\154\151\166\x65\162\x5f\162\x65\x6d\x6f\x76\x65\137\x6f\154\x64\x5f\x73\x6f\165\162\x63\145\163\137\150\157\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\163\144\x65\154\x69\x76\x65\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
