<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4159a97563             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = self::kgswyesggeyekgmg . "\152\x73\144\145\154\151\x76\145\x72\x5f\141\156\141\x6c\171\x7a\145\x5f\163\x6f\x75\x72\143\x65\x73\137\x68\157\x6f\153"; const akguikecmoggsykg = self::kgswyesggeyekgmg . "\152\x73\x64\x65\x6c\x69\x76\x65\162\x5f\162\145\x6d\157\x76\x65\x5f\157\154\x64\137\163\x6f\165\162\x63\145\163\x5f\150\157\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\163\144\145\x6c\151\166\x65\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
