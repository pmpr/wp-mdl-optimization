<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79d4da80             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\x73\144\145\x6c\151\166\x65\x72\137\x61\x6e\141\154\171\x7a\x65\137\x73\157\x75\162\143\145\163\x5f\150\x6f\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\163\x64\x65\154\x69\x76\145\162\137\x72\x65\155\x6f\166\145\x5f\157\154\144\137\163\157\165\x72\x63\x65\163\137\x68\157\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\163\144\x65\154\151\x76\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
