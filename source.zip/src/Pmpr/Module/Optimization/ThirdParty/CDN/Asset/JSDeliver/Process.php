<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eafa500a52f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\145\x6c\151\166\145\162\137\x61\x6e\141\x6c\x79\x7a\x65\x5f\x73\x6f\165\x72\x63\x65\x73\x5f\150\x6f\157\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\x73\144\x65\x6c\151\166\145\x72\x5f\162\x65\x6d\x6f\x76\x65\x5f\x6f\154\144\137\x73\157\x75\162\143\x65\x73\137\x68\x6f\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\163\144\x65\x6c\151\x76\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
