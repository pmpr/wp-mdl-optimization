<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f9435286             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\x65\x6c\x69\166\145\x72\137\x61\156\141\154\171\x7a\x65\137\x73\157\165\x72\143\x65\x73\x5f\150\157\x6f\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\163\x64\145\x6c\x69\x76\145\x72\137\162\145\x6d\x6f\166\145\x5f\x6f\x6c\x64\137\x73\x6f\165\162\143\x65\x73\137\x68\x6f\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\163\x64\145\x6c\x69\166\x65\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
