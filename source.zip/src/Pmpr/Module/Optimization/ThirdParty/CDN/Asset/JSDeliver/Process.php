<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8e1ec93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\x65\154\x69\x76\x65\x72\x5f\x61\x6e\141\154\x79\x7a\x65\x5f\x73\x6f\x75\162\x63\145\163\x5f\150\x6f\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\145\154\x69\x76\145\162\137\162\145\155\x6f\166\145\x5f\157\154\144\x5f\163\157\165\x72\143\145\163\x5f\x68\157\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\163\x64\145\x6c\151\166\x65\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
