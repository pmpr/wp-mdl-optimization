<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4c4bca826             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\163\144\145\154\x69\x76\145\162\x5f\141\x6e\x61\x6c\171\172\145\137\163\x6f\x75\x72\x63\x65\163\137\x68\157\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\x65\x6c\151\166\145\162\137\x72\145\x6d\157\x76\x65\x5f\x6f\x6c\x64\x5f\163\157\165\x72\143\x65\163\x5f\x68\x6f\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\x73\x64\145\x6c\151\166\145\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
