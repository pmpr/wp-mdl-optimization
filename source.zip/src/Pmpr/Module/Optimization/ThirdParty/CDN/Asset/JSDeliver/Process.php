<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd21640c7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = self::kgswyesggeyekgmg . "\x6a\x73\144\x65\154\x69\166\x65\x72\137\x61\x6e\141\154\x79\x7a\145\x5f\163\x6f\165\162\143\145\163\x5f\150\157\157\x6b"; const akguikecmoggsykg = self::kgswyesggeyekgmg . "\x6a\x73\x64\145\154\151\166\145\162\137\162\x65\155\x6f\x76\145\137\157\x6c\144\x5f\163\x6f\x75\162\x63\145\163\137\x68\x6f\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\163\144\x65\x6c\x69\x76\x65\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
