<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b5148c02d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\163\144\145\x6c\x69\x76\x65\x72\137\x61\156\141\x6c\x79\172\x65\x5f\163\157\x75\162\143\x65\x73\x5f\x68\157\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\x73\x64\145\x6c\151\166\145\162\x5f\162\x65\x6d\157\x76\x65\137\x6f\x6c\x64\137\163\x6f\165\162\x63\145\163\x5f\150\x6f\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\144\x65\x6c\151\166\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
