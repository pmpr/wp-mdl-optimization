<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508f721bbb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = self::kgswyesggeyekgmg . "\152\x73\144\145\x6c\x69\166\x65\x72\x5f\141\x6e\x61\x6c\171\x7a\x65\x5f\163\157\x75\162\143\145\x73\x5f\150\x6f\157\153"; const akguikecmoggsykg = self::kgswyesggeyekgmg . "\x6a\163\144\145\154\151\x76\145\162\137\x72\x65\155\x6f\x76\x65\137\x6f\154\144\137\163\x6f\165\162\143\145\x73\137\x68\157\157\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\x73\x64\145\x6c\x69\166\x65\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
