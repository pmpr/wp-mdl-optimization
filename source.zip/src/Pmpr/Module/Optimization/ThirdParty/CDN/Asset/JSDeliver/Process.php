<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afcef5beb16             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = self::kgswyesggeyekgmg . "\x6a\x73\144\145\x6c\151\166\145\x72\x5f\141\156\x61\154\x79\x7a\145\x5f\x73\157\x75\162\143\x65\x73\x5f\x68\157\x6f\x6b"; const akguikecmoggsykg = self::kgswyesggeyekgmg . "\152\x73\144\x65\154\x69\x76\x65\162\x5f\x72\145\x6d\157\166\x65\x5f\157\154\144\x5f\163\x6f\165\162\x63\145\x73\x5f\150\157\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\x64\x65\x6c\x69\166\x65\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
