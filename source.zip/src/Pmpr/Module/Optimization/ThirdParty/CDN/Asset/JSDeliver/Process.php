<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2ec2cd5b75             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\163\x64\x65\154\x69\166\x65\x72\137\x61\156\x61\x6c\171\x7a\145\x5f\x73\157\x75\x72\x63\x65\x73\137\150\157\157\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\163\x64\x65\154\x69\166\145\162\137\162\x65\x6d\157\166\145\137\157\154\x64\x5f\x73\157\x75\x72\143\145\163\x5f\x68\x6f\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\x73\x64\x65\154\x69\x76\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
