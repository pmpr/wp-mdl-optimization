<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c6c5682             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\163\x64\145\154\x69\166\145\x72\137\x61\x6e\x61\x6c\x79\172\145\137\163\x6f\165\x72\143\145\163\x5f\150\157\x6f\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\163\144\145\x6c\x69\166\145\162\x5f\x72\145\x6d\x6f\x76\x65\137\x6f\154\144\x5f\x73\x6f\x75\x72\x63\x65\x73\137\x68\x6f\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\144\145\154\x69\166\x65\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
