<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16dc16c38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\142\154\145\x5f\x6a\163\x64\x65\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\x74\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\151\x76\x65\x72\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\145\x6c\x69\x76\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\x6c\145\x20\x46\x6f\x72\x20\101\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\143\153\40\164\150\151\163\x20\x6f\160\164\151\157\156\x20\x74\x6f\40\162\145\160\x6c\x61\x63\x65\40\162\x65\163\x6f\165\162\x63\x65\x73\40\142\x79\40\112\123\104\145\x6c\151\166\145\162\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
