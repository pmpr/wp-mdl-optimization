<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686aaf854850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\x62\x6c\145\137\152\x73\144\145\x6c\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\164\137\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\151\166\145\162\x5f\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\154\151\166\145\162\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\x62\x6c\145\40\x46\x6f\x72\x20\101\163\x73\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\40\x74\150\x69\163\x20\x6f\x70\x74\151\157\156\40\164\x6f\40\162\145\x70\154\x61\x63\145\x20\162\x65\x73\157\x75\162\143\145\x73\x20\142\171\x20\x4a\x53\104\x65\x6c\x69\x76\145\x72\40\x63\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
