<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66375048491fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\154\145\137\152\163\144\x65\x6c\151\x76\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\164\x5f\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\154\151\166\145\162\137\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\145\x6c\x69\166\x65\162\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\154\145\40\106\x6f\x72\40\x41\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\153\40\x74\150\151\x73\40\157\160\x74\x69\x6f\x6e\40\164\157\x20\162\x65\x70\x6c\x61\143\x65\40\x72\x65\163\157\165\162\x63\x65\163\x20\142\171\40\112\x53\104\145\x6c\151\x76\145\162\40\x63\144\156\56", PR__MDL__OPTIMIZATION)))); } }
