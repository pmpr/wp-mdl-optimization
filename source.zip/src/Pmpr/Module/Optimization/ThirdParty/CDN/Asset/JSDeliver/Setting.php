<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f091293fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\154\145\137\152\163\144\145\x6c\151\x76\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\145\x74\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\x65\154\x69\x76\x65\x72\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\154\151\166\x65\162\40\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\x6c\145\x20\106\x6f\x72\40\x41\163\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\143\153\40\164\150\151\x73\40\157\160\x74\151\x6f\x6e\x20\x74\x6f\x20\162\145\160\x6c\141\143\x65\x20\x72\x65\x73\157\x75\x72\x63\x65\163\x20\x62\x79\x20\112\x53\104\x65\x6c\x69\x76\145\x72\x20\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
