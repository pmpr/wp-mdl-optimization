<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae90c7cdea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\154\145\137\x6a\x73\x64\145\x6c\151\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\x74\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\151\166\x65\x72\x5f\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\x6c\x69\166\145\x72\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\142\x6c\x65\x20\x46\157\x72\x20\x41\x73\163\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\153\40\x74\x68\151\163\40\157\160\164\x69\157\x6e\x20\x74\157\40\x72\145\x70\154\141\x63\x65\x20\162\145\163\x6f\x75\x72\x63\x65\x73\x20\x62\171\x20\112\123\104\x65\154\x69\x76\x65\162\x20\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
