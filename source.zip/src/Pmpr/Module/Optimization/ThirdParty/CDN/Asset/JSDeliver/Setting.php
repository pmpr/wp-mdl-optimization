<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb592725             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\x62\154\145\137\152\x73\x64\x65\x6c\151\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\145\x74\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\154\151\166\x65\162\137\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\151\166\x65\x72\x20\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\x6c\145\40\106\x6f\x72\40\101\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\x6b\x20\164\x68\x69\163\40\x6f\160\164\x69\x6f\x6e\40\x74\x6f\40\162\x65\x70\154\141\x63\145\x20\162\145\163\157\x75\162\x63\145\x73\40\x62\x79\40\x4a\x53\x44\x65\154\151\x76\x65\x72\40\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
