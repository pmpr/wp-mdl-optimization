<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663757b0e9f86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\x65\137\152\x73\144\x65\x6c\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\x74\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\x6c\x69\x76\145\x72\137\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\x6c\151\166\x65\x72\x20\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\142\154\145\40\106\x6f\x72\40\x41\163\163\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\40\x74\x68\x69\x73\40\157\x70\x74\x69\157\156\40\x74\x6f\40\162\145\x70\x6c\141\143\145\40\162\x65\x73\157\x75\162\143\145\163\40\142\x79\40\112\x53\104\x65\x6c\x69\166\x65\162\x20\143\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
