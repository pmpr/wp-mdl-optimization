<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a608b965f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\x6c\x65\137\152\163\144\145\154\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\145\x74\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\x6c\151\166\x65\162\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\145\154\x69\x76\145\162\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\154\x65\x20\x46\157\x72\40\101\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\x63\x6b\x20\x74\x68\x69\163\x20\157\x70\x74\x69\157\x6e\x20\164\x6f\x20\162\x65\x70\154\x61\143\145\40\162\x65\163\x6f\165\x72\143\x65\163\40\142\x79\x20\x4a\123\x44\x65\x6c\151\166\x65\x72\40\x63\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
