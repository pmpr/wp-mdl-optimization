<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686855490492             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\x62\x6c\x65\137\152\x73\x64\x65\x6c\151\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\145\x74\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\145\154\151\x76\145\162\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\x6c\151\x76\x65\x72\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\142\x6c\145\x20\106\157\x72\40\101\163\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\153\x20\x74\x68\151\163\40\157\x70\x74\x69\x6f\156\40\x74\x6f\x20\x72\x65\x70\154\x61\x63\x65\40\162\145\x73\157\165\x72\143\145\x73\x20\142\x79\x20\x4a\x53\104\x65\x6c\151\x76\x65\x72\40\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
