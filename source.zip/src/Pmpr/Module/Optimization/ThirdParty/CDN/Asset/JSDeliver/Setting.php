<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819c784426             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\154\x65\x5f\x6a\x73\x64\145\154\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\145\164\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\x6c\151\166\x65\162\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\154\x69\x76\145\x72\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\154\x65\x20\106\x6f\x72\40\101\x73\163\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\x20\164\150\x69\163\40\157\160\164\x69\157\x6e\x20\x74\x6f\x20\162\145\x70\x6c\x61\143\145\x20\x72\x65\x73\157\x75\162\x63\x65\163\40\x62\x79\x20\112\123\104\x65\154\x69\166\x65\x72\x20\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
