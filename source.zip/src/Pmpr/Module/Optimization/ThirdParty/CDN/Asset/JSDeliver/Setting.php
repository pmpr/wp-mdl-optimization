<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29dc7ba6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\x62\x6c\x65\x5f\152\x73\x64\x65\x6c\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\164\x5f\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\154\x69\166\x65\x72\137\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\145\x6c\x69\166\145\x72\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\154\145\40\x46\x6f\x72\40\x41\163\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\x65\x63\x6b\40\x74\x68\151\163\40\157\160\x74\x69\x6f\x6e\x20\164\157\40\x72\x65\x70\x6c\x61\143\145\40\162\x65\x73\157\165\x72\143\x65\163\x20\142\171\40\x4a\123\x44\x65\154\151\166\x65\162\40\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
