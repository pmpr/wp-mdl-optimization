<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cebac3c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\142\x6c\x65\137\152\163\x64\145\154\151\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\164\x5f\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\145\x6c\x69\x76\x65\162\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\151\166\x65\162\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\x65\x20\x46\157\x72\x20\101\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\x20\x74\x68\151\163\40\157\160\x74\151\x6f\x6e\x20\x74\x6f\x20\x72\x65\x70\x6c\x61\x63\145\40\162\145\x73\x6f\x75\162\143\x65\163\x20\142\x79\40\112\123\104\x65\154\151\x76\x65\x72\40\x63\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
