<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668664c7535d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\154\x65\137\152\x73\x64\145\154\151\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\145\x74\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\x65\x6c\151\x76\x65\x72\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\x69\x76\x65\162\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\x65\40\x46\x6f\x72\x20\x41\163\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\x20\x74\150\151\x73\40\x6f\x70\164\151\157\x6e\40\164\157\40\x72\x65\x70\154\141\143\x65\x20\162\145\163\157\x75\x72\x63\145\x73\40\142\171\x20\112\x53\104\145\154\151\166\145\162\40\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
