<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d5dd19f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\154\145\137\x6a\x73\x64\x65\154\151\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\154\151\166\x65\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\154\x69\x76\145\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\154\x65\x20\x46\x6f\162\40\101\163\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\x6b\x20\164\150\x69\x73\x20\157\x70\x74\x69\x6f\156\x20\164\157\40\x72\x65\160\x6c\141\143\x65\x20\x72\145\163\157\x75\162\x63\145\163\x20\x62\171\40\112\123\104\x65\154\151\x76\x65\x72\x20\x63\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
