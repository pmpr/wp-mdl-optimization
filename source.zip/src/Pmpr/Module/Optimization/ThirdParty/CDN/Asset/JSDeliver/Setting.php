<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba5a468b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\142\154\145\x5f\152\163\144\145\x6c\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\164\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\166\x65\162\x5f\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\145\154\x69\166\145\x72\x20\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\142\x6c\145\40\x46\x6f\162\40\x41\x73\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\153\x20\164\x68\x69\x73\40\x6f\160\x74\151\x6f\156\40\x74\x6f\40\x72\145\160\154\141\143\145\40\162\x65\163\x6f\165\162\x63\145\163\40\142\171\x20\x4a\123\104\x65\154\x69\x76\145\162\40\x63\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
