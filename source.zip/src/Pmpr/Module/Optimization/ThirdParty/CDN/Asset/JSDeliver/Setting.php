<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69f59378cd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\x6c\x65\137\x6a\x73\144\x65\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\x74\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\x6c\x69\166\x65\x72\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\x69\x76\145\x72\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\154\145\x20\x46\x6f\x72\x20\101\163\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\x20\164\150\x69\163\40\x6f\x70\x74\x69\157\x6e\40\164\x6f\40\x72\x65\x70\x6c\x61\143\x65\40\x72\145\x73\x6f\x75\x72\143\145\x73\x20\142\171\x20\112\x53\x44\145\x6c\151\x76\145\162\x20\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
