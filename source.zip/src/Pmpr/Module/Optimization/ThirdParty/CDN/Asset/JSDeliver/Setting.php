<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357314a443             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\154\x65\137\152\163\144\145\x6c\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\145\164\x5f\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\x6c\151\x76\x65\162\137\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\x6c\x69\166\x65\x72\40\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\154\145\x20\106\157\162\x20\101\x73\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\x63\153\40\164\150\x69\163\x20\157\x70\164\x69\x6f\x6e\40\164\x6f\x20\162\x65\160\154\x61\x63\145\x20\x72\x65\163\157\x75\162\x63\145\x73\x20\142\171\40\x4a\x53\x44\145\154\x69\166\x65\x72\x20\x63\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
