<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c5745b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\142\154\x65\137\x6a\x73\x64\x65\x6c\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\x65\164\137\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\x6c\151\166\145\x72\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\x65\154\151\166\145\162\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\x62\x6c\x65\x20\106\x6f\x72\40\x41\x73\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\40\x74\x68\151\x73\40\157\160\164\151\157\x6e\40\164\x6f\x20\162\x65\x70\x6c\x61\143\145\x20\162\x65\163\x6f\165\162\x63\145\163\x20\x62\171\x20\x4a\123\x44\145\154\x69\x76\145\x72\x20\x63\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
