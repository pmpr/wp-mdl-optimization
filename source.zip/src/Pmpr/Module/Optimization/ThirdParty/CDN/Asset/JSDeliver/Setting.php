<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689580cbf1c8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\x65\x5f\152\163\144\145\x6c\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\145\164\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\145\154\151\166\x65\162\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\x6c\151\166\x65\x72\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\142\x6c\145\40\x46\157\162\40\x41\163\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\40\164\x68\x69\x73\x20\157\160\164\x69\x6f\x6e\x20\x74\157\40\162\x65\160\154\141\143\x65\x20\x72\145\x73\157\165\x72\x63\x65\163\40\x62\x79\40\x4a\123\x44\x65\154\x69\166\x65\x72\40\x63\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
