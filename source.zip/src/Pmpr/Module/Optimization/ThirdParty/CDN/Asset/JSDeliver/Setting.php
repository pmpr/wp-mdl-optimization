<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668b0fe6d179             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\154\145\137\152\163\144\145\154\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\x65\x74\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\x65\154\151\x76\x65\x72\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\154\x69\166\x65\x72\x20\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\154\145\x20\x46\157\x72\40\101\x73\x73\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\153\40\x74\x68\x69\x73\x20\157\x70\x74\x69\157\x6e\40\x74\x6f\x20\x72\145\160\154\141\x63\x65\x20\x72\x65\163\x6f\x75\162\x63\x65\163\x20\142\171\x20\x4a\123\x44\145\154\x69\166\145\162\x20\x63\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
