<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350bd82c2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\x65\x5f\x6a\x73\x64\145\x6c\151\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\145\164\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\154\x69\166\145\x72\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\154\x69\166\145\x72\40\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\x6c\145\40\x46\157\x72\40\x41\163\163\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\x63\153\x20\164\150\x69\163\x20\157\160\164\x69\157\x6e\x20\x74\157\x20\162\x65\x70\x6c\141\x63\145\40\x72\x65\163\x6f\x75\x72\143\x65\163\40\x62\x79\40\x4a\x53\x44\x65\x6c\x69\166\145\162\40\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
