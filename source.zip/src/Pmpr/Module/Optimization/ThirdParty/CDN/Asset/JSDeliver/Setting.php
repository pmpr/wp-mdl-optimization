<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66696e7e43c2d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\x6c\145\137\x6a\163\144\145\154\151\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\151\166\x65\x72\137\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\145\154\151\x76\145\162\40\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\142\x6c\x65\40\x46\x6f\162\x20\x41\x73\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\143\x6b\40\x74\x68\151\x73\x20\x6f\160\164\x69\x6f\x6e\40\x74\x6f\x20\x72\145\x70\x6c\x61\x63\x65\x20\x72\145\163\157\165\162\143\x65\163\x20\x62\171\x20\x4a\123\x44\145\x6c\x69\166\x65\162\40\143\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
