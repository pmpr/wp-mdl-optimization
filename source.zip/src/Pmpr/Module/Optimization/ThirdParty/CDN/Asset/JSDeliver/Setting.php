<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635046c437f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\154\x65\137\x6a\x73\x64\145\x6c\151\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\145\164\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\145\154\x69\x76\145\162\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\x6c\151\166\x65\x72\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\145\x20\x46\x6f\x72\40\x41\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\x65\143\153\x20\164\150\151\163\x20\157\160\x74\x69\x6f\x6e\x20\x74\x6f\40\162\x65\x70\x6c\141\143\145\x20\162\145\163\x6f\165\162\143\145\163\x20\x62\x79\40\x4a\x53\104\145\154\151\x76\145\x72\x20\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
