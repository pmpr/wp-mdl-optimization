<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fc96ddb33             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\x62\x6c\145\137\152\x73\144\x65\x6c\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\164\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\166\145\x72\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\145\x6c\151\x76\x65\162\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\x6c\x65\x20\x46\x6f\x72\40\101\x73\163\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\x20\x74\150\x69\163\x20\157\x70\x74\151\157\x6e\x20\164\x6f\x20\162\x65\160\154\141\143\x65\40\x72\145\163\x6f\x75\x72\143\x65\163\40\142\171\40\112\123\104\x65\x6c\151\x76\x65\x72\40\143\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
