<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ea6553f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\x62\154\145\x5f\152\163\x64\145\x6c\151\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\x74\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\x65\154\151\166\145\x72\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\145\154\151\x76\x65\162\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\x6c\x65\x20\x46\157\162\40\101\x73\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\x63\x6b\40\x74\150\151\163\x20\157\160\164\151\x6f\x6e\40\164\x6f\x20\x72\145\x70\154\x61\x63\x65\40\x72\145\x73\157\x75\x72\x63\x65\x73\x20\142\171\x20\x4a\123\x44\x65\x6c\x69\166\x65\162\40\x63\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
