<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2393d5ec4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\142\154\145\x5f\152\x73\x64\x65\154\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\164\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\154\151\166\145\162\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\151\x76\x65\x72\x20\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\x6c\145\x20\106\x6f\162\40\x41\163\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\x20\x74\150\x69\163\x20\x6f\x70\x74\x69\157\x6e\40\x74\157\40\162\x65\x70\x6c\x61\x63\x65\40\162\145\163\157\165\x72\x63\145\163\40\x62\x79\40\112\123\104\x65\x6c\151\166\145\x72\40\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
