<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2162b04da4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\145\137\152\x73\x64\x65\x6c\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\137\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\154\x69\x76\x65\162\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\145\154\x69\x76\x65\162\x20\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\x62\x6c\145\40\x46\x6f\x72\40\x41\163\x73\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\40\164\x68\x69\163\x20\x6f\160\164\151\157\156\x20\x74\157\40\162\145\160\x6c\x61\143\145\x20\162\x65\163\x6f\165\162\143\145\163\x20\142\171\x20\x4a\x53\x44\x65\154\x69\166\x65\x72\40\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
