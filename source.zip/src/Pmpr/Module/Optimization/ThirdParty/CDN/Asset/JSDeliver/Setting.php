<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6347bb78c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\x6c\145\x5f\x6a\x73\144\x65\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\164\x5f\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\x69\166\x65\x72\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\x6c\x69\x76\x65\162\x20\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\x6c\x65\40\106\157\x72\40\x41\163\163\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\x63\153\40\x74\150\x69\x73\x20\x6f\160\x74\x69\157\156\40\x74\x6f\40\x72\145\160\154\x61\x63\x65\40\162\x65\163\157\165\162\x63\x65\x73\x20\142\x79\40\112\123\104\x65\154\151\166\x65\162\40\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
