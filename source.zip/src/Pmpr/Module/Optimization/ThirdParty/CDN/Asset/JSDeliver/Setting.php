<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afcef5beb16             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\x62\x6c\145\x5f\152\163\144\x65\x6c\151\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\x74\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\x6c\151\166\145\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\154\151\x76\145\x72\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\142\x6c\145\40\106\157\x72\x20\x41\163\163\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\x63\x6b\x20\x74\150\151\163\x20\x6f\x70\164\151\157\x6e\40\164\157\x20\162\x65\160\154\x61\x63\145\40\162\x65\x73\157\165\162\x63\x65\x73\40\x62\x79\40\x4a\x53\x44\x65\x6c\x69\166\145\x72\x20\x63\144\156\56", PR__MDL__OPTIMIZATION)))); } }
