<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580890b0d1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\x62\x6c\145\137\x6a\163\144\x65\154\151\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\164\x5f\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\x6c\151\166\x65\x72\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\x65\154\151\x76\x65\162\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\142\x6c\x65\40\106\157\162\x20\x41\x73\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\x20\164\x68\x69\163\x20\157\160\164\151\157\x6e\40\x74\157\x20\x72\145\x70\154\141\143\145\40\x72\x65\x73\157\x75\162\x63\x65\x73\x20\142\171\x20\112\x53\x44\x65\154\151\x76\x65\162\x20\x63\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
