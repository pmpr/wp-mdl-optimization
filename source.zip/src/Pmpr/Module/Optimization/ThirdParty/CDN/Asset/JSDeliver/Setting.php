<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bec25a4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\x62\x6c\145\137\152\x73\x64\x65\154\151\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\x74\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\154\x69\x76\x65\x72\137\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\154\151\x76\x65\162\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\x6c\x65\x20\106\x6f\x72\x20\101\163\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\40\x74\x68\x69\163\40\x6f\x70\x74\x69\x6f\x6e\x20\x74\x6f\40\162\x65\160\x6c\x61\143\x65\40\x72\x65\x73\x6f\165\x72\143\145\x73\40\x62\171\40\112\123\104\145\154\x69\166\x65\x72\x20\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
