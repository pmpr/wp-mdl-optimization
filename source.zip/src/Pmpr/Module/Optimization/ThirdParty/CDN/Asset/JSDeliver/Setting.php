<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1504adf49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\x62\154\145\137\x6a\163\x64\145\x6c\151\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\164\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\x69\166\145\x72\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\154\x69\x76\x65\x72\40\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\x6c\x65\40\106\x6f\x72\x20\x41\x73\163\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\40\164\x68\151\163\40\157\x70\164\x69\157\156\40\x74\157\x20\x72\145\x70\x6c\x61\143\x65\x20\162\145\x73\x6f\x75\x72\143\x65\x73\x20\x62\x79\x20\x4a\x53\x44\x65\x6c\x69\x76\145\x72\40\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
