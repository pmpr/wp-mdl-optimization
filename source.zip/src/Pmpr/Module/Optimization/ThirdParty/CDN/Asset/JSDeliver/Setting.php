<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69b17b7795             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\154\x65\x5f\x6a\x73\144\145\154\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\145\164\137\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\x65\154\x69\x76\x65\162\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\154\x69\x76\145\x72\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\142\154\x65\40\x46\157\162\x20\101\x73\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\153\40\164\150\151\x73\40\x6f\x70\x74\x69\x6f\x6e\40\x74\157\40\162\x65\160\154\x61\143\145\x20\162\145\x73\x6f\x75\x72\x63\145\x73\x20\142\x79\40\112\123\x44\x65\x6c\x69\166\145\x72\40\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
