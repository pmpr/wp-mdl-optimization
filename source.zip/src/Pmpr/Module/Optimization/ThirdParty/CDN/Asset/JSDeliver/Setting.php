<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637dda1d1856             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\x62\154\145\x5f\152\x73\144\x65\x6c\151\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\x65\x6c\151\166\145\162\137\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\x6c\x69\x76\145\x72\40\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\x6c\145\x20\x46\157\x72\x20\x41\163\x73\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\x65\143\153\x20\x74\150\151\163\40\157\160\x74\151\x6f\156\40\x74\x6f\40\x72\x65\x70\154\x61\x63\x65\40\x72\x65\163\157\x75\x72\143\145\163\x20\x62\x79\40\x4a\x53\x44\x65\x6c\151\166\145\162\x20\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
