<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a697384             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\x6c\x65\137\152\x73\144\x65\x6c\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\x65\164\137\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\x65\x6c\x69\166\145\162\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\x6c\x69\x76\145\x72\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\154\x65\x20\106\157\162\x20\101\x73\163\x65\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\40\x74\150\x69\x73\x20\157\x70\164\x69\157\156\40\x74\x6f\x20\162\x65\x70\x6c\x61\143\145\x20\162\x65\163\157\x75\162\x63\x65\163\40\142\x79\40\x4a\x53\x44\145\x6c\x69\166\x65\x72\x20\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
