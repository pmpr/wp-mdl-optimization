<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665adeeecdb44             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\x6c\145\x5f\x6a\163\x64\x65\x6c\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\145\x74\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\x65\x6c\x69\x76\x65\x72\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\151\166\x65\x72\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\x6c\x65\40\106\x6f\x72\x20\101\163\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\x63\x6b\40\164\150\x69\163\x20\x6f\160\x74\151\x6f\x6e\x20\164\157\x20\162\145\160\x6c\x61\x63\145\x20\162\x65\163\x6f\165\162\143\x65\x73\x20\x62\171\x20\112\x53\104\x65\x6c\x69\166\145\x72\x20\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
