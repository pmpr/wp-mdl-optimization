<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668aef2e0bbf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\142\x6c\145\x5f\x6a\x73\x64\145\x6c\151\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\x65\164\x5f\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\145\x6c\151\x76\x65\x72\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\x6c\151\166\x65\162\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\142\154\145\x20\106\157\162\40\101\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\153\40\164\x68\151\163\40\157\160\x74\151\157\x6e\x20\164\157\x20\x72\145\x70\x6c\x61\x63\145\x20\x72\x65\x73\x6f\165\x72\143\145\x73\40\x62\x79\x20\x4a\123\x44\x65\154\x69\x76\x65\x72\40\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
