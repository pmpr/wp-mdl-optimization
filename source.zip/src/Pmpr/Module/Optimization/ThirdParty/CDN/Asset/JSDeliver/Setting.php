<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\154\x65\137\x6a\x73\144\x65\x6c\151\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\x65\x74\x5f\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\x6c\x69\x76\x65\162\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\x6c\x69\166\145\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\x62\154\x65\40\106\x6f\x72\40\x41\x73\x73\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\153\40\x74\x68\x69\x73\x20\157\x70\x74\151\157\x6e\40\164\x6f\40\x72\x65\160\154\x61\143\x65\x20\162\145\x73\x6f\x75\x72\143\x65\x73\40\142\x79\x20\112\x53\x44\145\x6c\x69\166\x65\162\x20\x63\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
