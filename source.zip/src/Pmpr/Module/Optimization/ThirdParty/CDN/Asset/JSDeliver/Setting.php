<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fa68d1c92             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\x6c\x65\137\x6a\x73\144\x65\x6c\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\137\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\151\x76\145\x72\x5f\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\x6c\151\166\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\x6c\x65\40\x46\157\162\x20\101\163\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\x20\164\150\x69\163\x20\157\x70\164\x69\157\156\40\x74\157\40\162\145\160\154\141\x63\x65\40\162\x65\163\x6f\x75\x72\x63\145\x73\40\142\171\x20\112\x53\x44\145\154\x69\166\x65\162\x20\143\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
