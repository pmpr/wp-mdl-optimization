<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a6a10b62e31             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\x6c\x65\x5f\x6a\163\144\145\x6c\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\164\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\145\154\x69\166\x65\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\154\151\166\145\162\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\x62\154\x65\x20\x46\x6f\162\x20\x41\163\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\x65\x63\153\x20\164\150\x69\163\40\x6f\x70\164\151\157\x6e\40\164\x6f\40\x72\x65\x70\154\141\143\x65\40\162\145\x73\157\x75\162\143\145\x73\x20\142\x79\x20\112\123\x44\x65\x6c\x69\x76\x65\x72\x20\x63\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
