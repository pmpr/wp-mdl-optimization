<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af1935df9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\x62\x6c\x65\x5f\152\x73\x64\x65\x6c\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\x65\164\x5f\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\x65\154\x69\166\145\162\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\x65\x6c\151\166\x65\x72\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\x6c\145\40\106\x6f\x72\40\x41\163\163\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\x6b\40\164\150\151\x73\x20\x6f\160\164\x69\x6f\x6e\40\164\x6f\40\162\x65\x70\x6c\x61\x63\x65\40\x72\x65\x73\x6f\x75\x72\x63\x65\x73\40\x62\x79\40\112\123\x44\x65\x6c\x69\166\145\x72\40\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
