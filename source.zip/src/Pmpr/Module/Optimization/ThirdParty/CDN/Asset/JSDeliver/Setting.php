<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665adbb76768c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\x6c\145\137\152\x73\x64\x65\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\164\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\x6c\151\166\145\162\x5f\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\154\151\166\x65\x72\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\142\x6c\x65\x20\106\x6f\x72\x20\x41\163\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\153\40\x74\x68\x69\163\x20\x6f\160\x74\x69\x6f\156\40\164\x6f\x20\162\145\160\154\141\x63\145\x20\162\145\163\157\165\x72\x63\145\x73\x20\x62\x79\x20\x4a\123\104\x65\154\151\166\x65\162\40\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
