<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb3b4b1ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\x62\154\145\137\152\x73\144\x65\x6c\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\x74\x5f\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\x6c\151\166\x65\x72\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\154\x69\x76\145\162\40\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\x6c\x65\x20\106\157\x72\40\101\x73\163\x65\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\x63\x6b\40\164\x68\x69\163\x20\157\160\164\151\x6f\x6e\40\164\157\x20\162\145\x70\154\141\x63\145\x20\x72\x65\x73\x6f\x75\162\x63\145\163\40\142\x79\40\112\x53\x44\145\154\x69\166\x65\162\x20\143\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
