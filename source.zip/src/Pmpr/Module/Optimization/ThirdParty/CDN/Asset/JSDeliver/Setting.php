<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58598b21ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\x6c\x65\x5f\x6a\x73\x64\x65\154\151\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\145\x74\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\154\x69\166\145\162\x5f\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\145\154\x69\x76\x65\162\40\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\x62\154\x65\40\106\x6f\x72\x20\x41\x73\x73\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\153\40\164\150\x69\x73\40\x6f\x70\164\151\157\x6e\40\164\157\40\162\x65\x70\x6c\141\x63\145\x20\162\145\x73\157\165\x72\143\x65\163\x20\142\x79\x20\x4a\123\104\145\x6c\151\x76\145\162\40\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
