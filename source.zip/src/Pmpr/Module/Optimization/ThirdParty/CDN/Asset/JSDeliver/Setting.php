<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666978e4a7c7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\x6c\x65\x5f\152\163\x64\145\154\151\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\145\x74\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\x6c\x69\166\145\162\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\154\x69\x76\x65\x72\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\x6c\x65\x20\106\157\162\x20\101\x73\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\x65\143\153\x20\x74\150\151\163\40\157\x70\x74\x69\157\x6e\40\x74\x6f\40\162\x65\x70\154\141\x63\x65\40\x72\145\x73\x6f\165\x72\143\x65\x73\x20\142\x79\x20\x4a\123\x44\x65\154\151\x76\145\162\x20\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
