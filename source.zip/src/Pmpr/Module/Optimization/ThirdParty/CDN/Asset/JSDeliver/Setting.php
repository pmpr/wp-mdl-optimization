<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663698627f721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\142\x6c\145\x5f\x6a\x73\144\145\x6c\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\154\151\x76\145\x72\x5f\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\145\154\x69\166\145\x72\40\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\142\x6c\x65\40\106\x6f\162\x20\101\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\x20\164\x68\151\163\x20\x6f\160\164\151\157\156\x20\164\x6f\x20\x72\145\x70\154\141\x63\145\40\x72\145\163\157\165\x72\x63\145\x73\x20\x62\x79\x20\x4a\x53\x44\145\154\151\166\x65\162\x20\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
