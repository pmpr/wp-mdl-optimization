<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bb05f1e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\142\x6c\x65\137\152\x73\144\x65\154\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\164\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\151\x76\x65\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\151\166\145\162\40\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\154\x65\x20\106\157\162\40\101\163\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\143\153\40\164\x68\x69\163\40\x6f\160\164\151\157\x6e\x20\x74\157\x20\x72\x65\x70\154\x61\143\x65\x20\162\x65\163\157\x75\x72\x63\145\163\x20\142\171\x20\112\123\104\x65\x6c\x69\x76\145\x72\40\143\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
