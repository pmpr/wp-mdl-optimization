<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4c4bca826             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\x62\x6c\145\x5f\152\x73\x64\x65\154\151\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\145\164\137\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\154\151\166\x65\x72\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\145\x6c\151\x76\x65\x72\x20\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\154\x65\40\x46\157\162\x20\x41\163\163\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\153\40\164\x68\151\x73\40\x6f\160\x74\151\x6f\156\x20\164\157\x20\162\145\x70\x6c\141\x63\145\x20\162\x65\163\x6f\165\x72\x63\x65\x73\x20\x62\171\x20\x4a\123\104\145\x6c\151\166\145\162\x20\143\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
