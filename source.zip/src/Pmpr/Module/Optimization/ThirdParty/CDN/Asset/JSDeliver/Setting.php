<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758115135c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\x62\x6c\x65\137\x6a\163\144\145\154\151\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\x5f\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\145\x6c\x69\166\x65\162\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\x69\166\145\162\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\154\x65\x20\106\157\x72\x20\101\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\x20\164\x68\151\x73\40\x6f\160\x74\x69\157\x6e\x20\164\157\x20\162\145\160\154\141\x63\x65\40\162\145\x73\x6f\x75\x72\143\x65\163\40\142\x79\x20\112\x53\104\145\x6c\x69\166\145\x72\x20\143\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
