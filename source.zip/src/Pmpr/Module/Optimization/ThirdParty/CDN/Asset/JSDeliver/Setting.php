<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\x62\x6c\145\x5f\152\163\x64\x65\154\x69\x76\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\x65\x74\137\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\x65\x6c\x69\x76\x65\162\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\154\151\x76\x65\x72\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\x62\x6c\x65\x20\106\x6f\x72\x20\x41\x73\163\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\40\164\150\x69\x73\40\157\x70\x74\x69\157\156\40\164\157\x20\x72\x65\160\154\x61\x63\145\x20\x72\x65\163\x6f\165\162\x63\x65\x73\x20\142\x79\x20\112\123\104\145\154\151\166\x65\x72\40\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
