<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b40b3181dac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\x62\x6c\x65\x5f\x6a\x73\x64\145\x6c\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\164\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\x65\x6c\151\x76\145\x72\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\x69\166\145\x72\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\x62\154\x65\x20\x46\157\x72\40\101\x73\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\153\x20\x74\x68\151\x73\x20\157\160\x74\151\x6f\x6e\x20\x74\x6f\x20\x72\x65\x70\154\x61\143\145\x20\x72\145\x73\x6f\x75\162\143\145\163\x20\x62\x79\40\112\x53\x44\x65\x6c\151\166\x65\x72\40\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
