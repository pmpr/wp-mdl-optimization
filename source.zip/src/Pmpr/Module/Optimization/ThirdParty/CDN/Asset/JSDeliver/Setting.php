<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d230b1b85af             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\x6c\x65\x5f\152\x73\144\x65\154\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\x6c\x69\x76\x65\162\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\154\151\166\145\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\x6c\x65\x20\x46\x6f\162\x20\101\163\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\x6b\x20\x74\x68\151\x73\x20\157\160\x74\x69\157\x6e\x20\164\x6f\40\162\x65\160\x6c\141\x63\x65\x20\x72\145\x73\157\x75\162\x63\x65\x73\x20\142\171\x20\x4a\x53\104\145\154\151\x76\x65\x72\x20\143\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
