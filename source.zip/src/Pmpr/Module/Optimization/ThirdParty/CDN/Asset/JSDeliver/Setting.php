<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508f721bbb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\154\145\x5f\152\163\x64\145\154\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\164\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\x76\x65\x72\137\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\x65\x6c\x69\166\x65\x72\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\x6c\145\x20\106\157\x72\x20\101\x73\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\x6b\x20\x74\x68\x69\163\x20\x6f\160\164\151\157\156\x20\x74\x6f\x20\162\x65\160\154\x61\x63\145\40\162\x65\163\x6f\x75\162\x63\x65\x73\40\142\x79\40\x4a\123\x44\x65\x6c\151\x76\x65\162\x20\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
