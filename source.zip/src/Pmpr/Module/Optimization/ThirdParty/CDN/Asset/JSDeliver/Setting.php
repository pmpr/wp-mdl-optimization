<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4f986c850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\x6c\x65\137\x6a\163\x64\x65\154\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\145\164\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\x6c\x69\x76\x65\162\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\x6c\151\166\x65\x72\40\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\x62\154\145\40\x46\x6f\x72\x20\101\x73\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\x6b\x20\x74\x68\151\x73\x20\x6f\160\x74\x69\x6f\156\x20\x74\x6f\40\162\145\160\x6c\x61\143\145\40\162\x65\163\157\165\162\x63\145\163\40\142\171\40\112\123\x44\x65\x6c\151\x76\x65\162\x20\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
