<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687508050272             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\142\x6c\x65\x5f\152\163\144\145\x6c\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\164\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\x6c\x69\x76\145\x72\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\154\151\166\x65\162\40\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\x62\154\145\x20\106\x6f\x72\x20\101\x73\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\153\40\x74\150\x69\163\40\157\160\164\x69\157\x6e\x20\164\157\x20\162\145\x70\x6c\x61\x63\145\x20\x72\145\x73\157\165\162\143\145\163\x20\142\x79\x20\112\x53\104\145\x6c\x69\x76\x65\162\40\x63\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
