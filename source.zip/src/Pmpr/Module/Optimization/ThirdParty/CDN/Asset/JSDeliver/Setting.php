<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7059178ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\x6c\145\137\x6a\163\x64\145\x6c\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\164\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\x65\154\x69\166\145\x72\x5f\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\154\x69\166\145\x72\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\x6c\145\40\x46\x6f\162\40\101\163\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\x63\x6b\x20\x74\150\151\163\40\x6f\x70\164\151\x6f\156\x20\x74\x6f\40\x72\x65\x70\154\x61\x63\145\40\x72\145\x73\x6f\165\162\143\145\163\x20\x62\x79\x20\x4a\123\x44\x65\154\151\x76\x65\x72\x20\143\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
