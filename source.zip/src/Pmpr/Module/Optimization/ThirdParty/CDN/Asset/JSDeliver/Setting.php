<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668660e287d70             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\145\137\152\x73\144\145\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\x65\164\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\x69\166\145\x72\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\x6c\x69\166\x65\162\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\145\x20\x46\x6f\x72\40\x41\163\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\143\x6b\40\164\150\151\163\x20\x6f\x70\164\151\157\x6e\x20\x74\x6f\40\162\x65\160\x6c\141\143\145\x20\162\145\163\157\165\162\x63\145\163\40\x62\x79\40\112\x53\104\x65\154\151\166\145\x72\x20\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
