<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             664697c805b60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\x6c\x65\137\152\163\x64\x65\x6c\151\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\x74\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\x76\x65\x72\x5f\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\145\x6c\151\166\145\162\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\x62\x6c\145\40\x46\157\162\40\101\163\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\x65\x63\x6b\x20\164\150\x69\x73\40\x6f\160\164\151\157\156\x20\164\x6f\40\x72\x65\x70\154\x61\x63\x65\x20\162\x65\163\157\165\x72\x63\145\x73\40\x62\171\x20\112\x53\104\145\x6c\x69\x76\145\x72\x20\x63\144\156\x2e", PR__MDL__OPTIMIZATION)))); } }
