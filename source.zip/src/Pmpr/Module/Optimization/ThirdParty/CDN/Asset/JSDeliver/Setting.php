<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c30d9443ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\x62\154\x65\x5f\152\163\144\x65\154\151\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\164\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\151\x76\x65\x72\137\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\x6c\151\x76\145\162\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\x6c\x65\x20\x46\157\x72\40\101\163\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\143\x6b\x20\x74\150\151\163\x20\157\160\164\151\157\156\x20\164\157\40\x72\145\x70\154\x61\143\x65\40\x72\145\163\157\x75\x72\x63\145\163\x20\x62\171\40\x4a\x53\x44\145\154\151\x76\x65\x72\40\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
