<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6654cb65a9906             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\142\x6c\x65\x5f\152\x73\144\145\154\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\145\164\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\154\151\x76\x65\162\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\154\151\x76\145\162\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\x62\154\145\x20\106\x6f\162\40\101\x73\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\x6b\40\x74\150\x69\163\40\x6f\160\164\151\157\156\40\164\157\x20\162\145\x70\x6c\141\143\145\40\x72\145\163\x6f\165\162\143\145\x73\40\142\171\x20\112\123\x44\x65\x6c\x69\166\x65\162\x20\x63\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
