<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a54fbc54301             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\x62\x6c\x65\x5f\x6a\x73\144\x65\154\151\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\x74\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\154\151\166\x65\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\154\x69\166\x65\x72\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\x62\x6c\x65\x20\x46\157\x72\40\x41\x73\163\x65\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\x63\x6b\x20\164\x68\x69\163\x20\x6f\x70\x74\x69\x6f\156\x20\x74\157\x20\162\x65\160\x6c\141\143\x65\x20\x72\x65\163\x6f\165\162\143\145\x73\40\x62\x79\x20\x4a\123\104\145\154\151\166\x65\162\40\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
