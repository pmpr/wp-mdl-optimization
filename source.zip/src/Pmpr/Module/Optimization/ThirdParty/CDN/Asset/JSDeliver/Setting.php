<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66697656b7da9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\145\137\152\x73\x64\145\x6c\151\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\164\x5f\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\x65\154\x69\x76\x65\162\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\154\x69\166\x65\162\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\x6c\145\x20\x46\x6f\x72\40\101\x73\163\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\x6b\x20\x74\150\151\163\x20\157\160\164\x69\x6f\x6e\x20\164\157\x20\162\145\160\x6c\x61\x63\x65\40\x72\x65\x73\x6f\165\162\x63\145\x73\x20\x62\x79\40\112\123\104\x65\x6c\x69\x76\x65\x72\40\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
