<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66585f57028db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\x6c\145\x5f\x6a\163\x64\x65\154\151\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\x5f\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\x65\x6c\151\166\145\x72\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\x6c\x69\x76\145\162\40\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\154\145\40\x46\157\162\x20\101\163\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\143\153\40\164\150\x69\163\x20\x6f\x70\164\151\157\x6e\40\164\157\x20\x72\145\160\154\141\x63\x65\40\x72\x65\x73\x6f\165\x72\x63\145\x73\40\x62\171\40\112\x53\x44\145\154\151\x76\x65\162\x20\x63\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
