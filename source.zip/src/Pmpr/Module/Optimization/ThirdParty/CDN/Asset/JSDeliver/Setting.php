<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a869bef5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\142\x6c\x65\137\152\163\x64\x65\x6c\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\154\x69\166\145\162\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\151\166\145\x72\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\154\145\40\x46\157\162\40\101\163\163\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\143\x6b\x20\164\150\151\163\40\x6f\x70\x74\x69\x6f\x6e\x20\164\x6f\40\162\x65\x70\154\141\143\145\x20\x72\x65\x73\157\x75\x72\x63\145\x73\40\142\x79\x20\112\123\104\x65\154\x69\166\x65\x72\x20\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
