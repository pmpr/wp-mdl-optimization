<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af54c961e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\142\154\145\x5f\x6a\x73\144\x65\x6c\151\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\137\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\x6c\151\166\x65\x72\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\145\x6c\x69\166\x65\x72\40\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\x62\154\145\40\106\157\162\40\101\163\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\143\x6b\40\164\x68\x69\x73\x20\x6f\160\164\151\x6f\x6e\x20\164\x6f\40\162\145\x70\x6c\x61\143\x65\x20\162\x65\163\x6f\165\162\143\145\x73\40\x62\x79\40\x4a\123\x44\x65\x6c\x69\x76\145\162\40\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
