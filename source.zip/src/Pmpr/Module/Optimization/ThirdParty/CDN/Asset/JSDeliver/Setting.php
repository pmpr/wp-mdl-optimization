<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665b6a8b74913             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\x62\154\x65\137\x6a\163\x64\x65\x6c\151\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\x74\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\154\x69\166\x65\x72\x5f\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\x6c\x69\166\x65\162\x20\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\x62\x6c\145\x20\x46\157\162\40\x41\163\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\x6b\x20\x74\x68\x69\163\x20\x6f\160\164\x69\x6f\x6e\40\x74\x6f\x20\x72\x65\160\x6c\x61\143\145\40\x72\145\163\x6f\x75\162\143\x65\163\x20\x62\171\40\112\x53\104\145\154\151\x76\145\162\x20\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
