<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665875e35aad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\142\154\x65\137\x6a\163\x64\145\x6c\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\x65\x74\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\151\166\145\162\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\154\151\166\x65\x72\x20\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\154\x65\x20\106\157\162\x20\101\x73\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\153\x20\164\x68\x69\x73\40\157\160\164\x69\x6f\156\40\164\157\40\162\145\x70\154\141\143\x65\40\162\x65\x73\x6f\x75\x72\143\x65\163\40\142\171\40\112\x53\104\x65\x6c\151\x76\145\162\40\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
