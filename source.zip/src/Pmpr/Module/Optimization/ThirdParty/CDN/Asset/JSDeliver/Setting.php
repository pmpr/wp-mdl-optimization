<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd21640c7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\x62\154\x65\x5f\x6a\163\x64\145\x6c\151\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\145\x74\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\x65\x6c\151\166\x65\x72\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\x6c\x69\x76\145\162\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\154\145\40\106\157\162\40\101\x73\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\x63\153\40\x74\x68\151\163\40\x6f\160\164\x69\x6f\156\40\164\x6f\x20\x72\x65\160\x6c\x61\143\x65\x20\162\145\x73\x6f\165\162\x63\x65\163\40\x62\171\x20\x4a\123\104\145\154\x69\166\145\162\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
