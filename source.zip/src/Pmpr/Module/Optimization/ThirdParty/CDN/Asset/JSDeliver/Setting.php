<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a5875d8609d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\x62\154\x65\x5f\x6a\x73\144\x65\x6c\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\x74\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\x76\x65\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\145\154\x69\166\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\142\154\145\x20\x46\x6f\162\40\101\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\143\x6b\40\x74\150\151\x73\40\x6f\160\x74\x69\x6f\156\40\164\x6f\40\162\x65\x70\x6c\x61\143\x65\x20\162\145\x73\x6f\165\x72\x63\x65\x73\x20\142\171\x20\x4a\x53\104\145\x6c\x69\166\145\162\x20\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
