<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4181e072c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\154\x65\137\x6a\x73\x64\x65\154\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\164\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\x65\x6c\x69\x76\x65\x72\x5f\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\154\151\166\145\162\x20\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\x6c\x65\40\106\157\x72\x20\x41\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\x6b\40\164\150\151\163\x20\x6f\160\x74\x69\157\x6e\40\x74\x6f\x20\162\x65\160\x6c\x61\143\x65\x20\162\x65\163\157\165\162\143\x65\x73\40\142\x79\40\x4a\x53\104\x65\x6c\x69\166\x65\162\x20\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
