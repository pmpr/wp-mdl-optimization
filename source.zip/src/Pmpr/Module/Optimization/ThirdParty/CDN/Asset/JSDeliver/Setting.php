<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2182256c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\x6c\145\x5f\x6a\x73\x64\x65\154\151\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\x74\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\x6c\x69\x76\145\x72\137\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\154\151\166\145\162\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\x65\x20\x46\157\162\40\101\x73\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\153\x20\164\x68\x69\163\40\157\x70\x74\151\157\x6e\40\164\x6f\40\x72\145\x70\154\x61\143\x65\40\162\x65\x73\157\x75\162\143\x65\x73\40\142\171\40\112\123\x44\145\x6c\x69\166\145\x72\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
