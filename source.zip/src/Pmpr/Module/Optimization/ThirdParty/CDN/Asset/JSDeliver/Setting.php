<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665afacdd5cec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\154\x65\x5f\152\163\x64\145\154\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\164\x5f\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\x65\154\x69\x76\x65\162\137\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\145\154\151\166\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\142\x6c\x65\40\106\x6f\x72\40\x41\163\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\153\x20\x74\x68\151\163\x20\x6f\160\164\x69\x6f\156\x20\x74\157\40\x72\x65\160\x6c\141\x63\145\x20\x72\145\x73\157\165\x72\143\x65\163\x20\x62\x79\40\x4a\x53\x44\145\154\151\166\x65\x72\x20\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
