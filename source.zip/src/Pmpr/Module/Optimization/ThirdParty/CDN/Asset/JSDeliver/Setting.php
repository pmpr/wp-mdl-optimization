<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31ce4ed382             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\x6c\145\x5f\x6a\x73\144\x65\154\151\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\145\x74\x5f\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\x65\154\x69\x76\x65\x72\x5f\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\x6c\x69\x76\x65\162\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\145\40\x46\x6f\162\x20\101\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\40\164\150\151\163\40\157\160\x74\x69\x6f\156\x20\164\x6f\x20\162\x65\160\x6c\141\143\145\40\x72\145\x73\157\165\162\x63\145\163\40\x62\171\x20\112\x53\x44\145\x6c\x69\x76\x65\x72\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
