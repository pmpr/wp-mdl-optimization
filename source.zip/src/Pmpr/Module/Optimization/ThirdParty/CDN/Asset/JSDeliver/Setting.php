<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66369e99bb80d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\x62\154\145\137\152\163\x64\x65\154\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\x74\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\151\166\145\162\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\x65\154\151\x76\145\x72\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\154\145\40\106\x6f\x72\40\101\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\143\x6b\x20\164\150\151\163\40\x6f\x70\x74\151\x6f\156\40\164\157\x20\162\x65\x70\x6c\x61\x63\x65\x20\x72\145\163\157\165\x72\x63\x65\x73\40\142\171\40\x4a\123\104\145\154\x69\166\x65\x72\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
