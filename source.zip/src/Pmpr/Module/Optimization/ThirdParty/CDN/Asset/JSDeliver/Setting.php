<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef5105e9703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\x62\154\145\137\x6a\x73\144\145\x6c\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\145\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\151\x76\145\x72\x5f\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\x65\x6c\151\x76\145\162\x20\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\x6c\x65\40\x46\157\x72\x20\101\x73\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\x63\x6b\x20\164\150\x69\163\40\157\160\x74\x69\x6f\156\40\x74\157\40\x72\145\160\x6c\x61\x63\145\40\162\145\163\x6f\x75\162\143\145\x73\x20\x62\171\x20\112\123\104\145\x6c\151\166\145\162\40\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
