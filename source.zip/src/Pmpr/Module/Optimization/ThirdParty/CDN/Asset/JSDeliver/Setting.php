<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635076d1df7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\145\x5f\152\x73\x64\145\x6c\151\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\164\x5f\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\x65\x6c\x69\166\145\x72\x5f\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\x6c\x69\166\145\162\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\x62\154\145\40\106\x6f\x72\40\101\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\153\x20\164\x68\151\163\40\157\x70\164\151\x6f\156\40\x74\x6f\40\162\145\x70\x6c\x61\143\145\40\x72\x65\x73\x6f\165\162\x63\145\x73\x20\x62\x79\x20\x4a\x53\104\x65\x6c\151\x76\x65\x72\40\x63\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
