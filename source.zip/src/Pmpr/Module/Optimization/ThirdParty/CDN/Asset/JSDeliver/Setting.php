<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663506337ce5d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\x6c\x65\137\x6a\x73\x64\x65\x6c\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\164\x5f\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\x65\154\x69\166\x65\162\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\x69\166\x65\x72\x20\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\142\154\145\x20\x46\157\x72\x20\101\x73\x73\x65\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\153\x20\164\x68\x69\163\40\x6f\x70\164\151\x6f\x6e\x20\x74\157\40\162\145\160\154\141\143\145\40\162\145\x73\157\165\x72\x63\145\x73\x20\142\x79\40\x4a\123\104\145\154\x69\166\x65\162\x20\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
