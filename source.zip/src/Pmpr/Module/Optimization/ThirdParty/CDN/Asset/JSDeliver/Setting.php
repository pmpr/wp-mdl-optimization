<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d30394ae64b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\x6c\145\x5f\152\163\144\x65\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\145\164\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\154\151\x76\145\162\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\x6c\x69\166\x65\x72\x20\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\142\154\145\x20\106\x6f\x72\40\101\163\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\153\x20\x74\150\x69\163\40\x6f\x70\x74\x69\157\156\40\164\157\x20\162\x65\x70\x6c\x61\143\x65\40\162\145\x73\157\x75\x72\x63\145\163\40\142\x79\40\x4a\x53\x44\145\x6c\x69\x76\145\x72\x20\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
