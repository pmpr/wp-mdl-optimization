<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66869afc6c108             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\x65\137\152\x73\144\x65\x6c\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\164\x5f\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\x69\x76\x65\x72\x5f\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\x6c\151\x76\x65\162\x20\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\154\x65\x20\x46\x6f\162\40\x41\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\x6b\40\164\x68\x69\163\x20\x6f\160\164\x69\157\156\x20\164\157\x20\162\145\x70\154\141\x63\145\40\x72\x65\163\157\165\162\x63\x65\x73\40\x62\x79\40\112\x53\x44\x65\x6c\x69\x76\x65\x72\40\143\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
