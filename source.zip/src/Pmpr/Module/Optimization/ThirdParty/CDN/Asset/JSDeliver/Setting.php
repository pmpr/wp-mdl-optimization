<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dd893c52c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\154\x65\x5f\x6a\x73\144\x65\x6c\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\x74\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\x65\x6c\x69\166\x65\162\x5f\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\154\x69\166\x65\x72\40\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\154\145\x20\x46\157\x72\40\101\163\163\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\153\x20\164\x68\151\x73\x20\157\160\164\x69\157\x6e\40\164\x6f\x20\x72\145\x70\154\141\143\145\x20\162\x65\163\x6f\x75\162\143\x65\163\40\142\171\40\x4a\123\x44\x65\154\x69\166\145\x72\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
