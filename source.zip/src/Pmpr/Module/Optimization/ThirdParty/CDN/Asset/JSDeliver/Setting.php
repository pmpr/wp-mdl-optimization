<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708194f632             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\x62\154\x65\137\x6a\x73\x64\x65\x6c\151\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\x74\137\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\154\x69\x76\x65\162\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\145\x6c\151\x76\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\142\x6c\145\40\x46\157\x72\40\101\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\x20\x74\x68\151\x73\40\x6f\x70\164\x69\x6f\156\40\164\157\x20\162\x65\160\x6c\x61\143\x65\40\162\x65\x73\157\x75\162\x63\x65\163\x20\x62\171\40\x4a\123\x44\x65\x6c\x69\x76\145\x72\x20\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
