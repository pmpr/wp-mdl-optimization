<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668750eb007f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\142\x6c\x65\137\152\163\x64\145\154\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\x74\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\x65\154\x69\x76\x65\x72\x5f\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\154\x69\x76\145\162\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\x62\x6c\145\40\x46\x6f\162\40\x41\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\40\x74\150\151\x73\x20\x6f\160\164\151\157\156\x20\164\x6f\x20\x72\x65\160\154\141\x63\x65\x20\x72\x65\x73\x6f\165\x72\143\x65\x73\x20\x62\171\40\x4a\123\x44\145\x6c\x69\x76\145\x72\40\143\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
