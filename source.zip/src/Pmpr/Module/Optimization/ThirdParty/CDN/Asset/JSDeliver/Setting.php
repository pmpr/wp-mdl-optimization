<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf8fcabf8fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\x62\154\145\x5f\152\163\x64\145\154\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\164\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\x6c\151\x76\145\x72\x5f\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\145\154\x69\x76\145\162\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\x62\x6c\145\x20\106\157\162\40\x41\x73\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\40\x74\150\151\163\40\157\x70\x74\x69\x6f\156\40\x74\x6f\x20\x72\x65\160\x6c\141\143\145\x20\x72\145\163\x6f\x75\162\x63\145\x73\x20\x62\171\40\112\x53\x44\145\x6c\151\x76\x65\162\40\143\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
