<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d249276cd51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\142\x6c\145\137\152\163\144\145\154\x69\x76\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\x65\164\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\154\x69\x76\x65\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\x69\x76\x65\162\x20\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\142\154\x65\40\x46\157\x72\40\x41\x73\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\x20\164\x68\x69\163\40\157\x70\x74\151\157\x6e\40\164\x6f\40\x72\145\160\154\x61\x63\x65\x20\x72\x65\163\157\165\x72\x63\145\163\40\142\171\x20\112\x53\x44\x65\x6c\151\166\x65\162\x20\143\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
