<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32f1aa2d0a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\x6c\145\137\x6a\163\144\x65\x6c\x69\x76\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\x65\164\137\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\154\x69\x76\145\162\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\145\154\151\x76\145\x72\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\154\x65\x20\106\x6f\x72\x20\101\x73\163\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\x6b\x20\x74\x68\x69\x73\x20\x6f\160\x74\151\157\x6e\x20\164\x6f\40\x72\145\160\x6c\x61\x63\145\x20\x72\x65\x73\x6f\x75\162\143\x65\163\x20\142\x79\40\x4a\x53\104\145\154\x69\x76\145\162\40\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
