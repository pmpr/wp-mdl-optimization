<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666957c99839f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\x62\x6c\x65\137\x6a\163\x64\x65\154\151\x76\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\x74\x5f\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\x6c\151\166\x65\x72\137\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\154\151\x76\x65\x72\x20\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\x62\154\x65\40\106\157\x72\40\101\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\143\153\40\164\x68\151\x73\40\157\160\x74\151\157\156\40\164\x6f\40\x72\x65\x70\x6c\141\143\x65\40\162\145\163\157\165\162\143\145\x73\40\142\x79\40\112\123\104\145\x6c\151\166\x65\x72\40\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
