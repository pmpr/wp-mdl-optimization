<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c10d873e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\x62\154\x65\x5f\152\x73\144\x65\x6c\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\x65\x74\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\x6c\x69\x76\x65\162\x5f\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\145\x6c\151\x76\145\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\142\154\x65\40\106\x6f\x72\40\x41\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\143\x6b\x20\x74\150\x69\163\x20\157\x70\x74\x69\x6f\x6e\40\164\157\x20\162\x65\x70\154\141\143\145\40\x72\145\x73\x6f\x75\162\x63\x65\163\x20\x62\x79\40\x4a\123\x44\145\x6c\x69\x76\145\162\x20\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
