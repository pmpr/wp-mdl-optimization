<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc55b1df53             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\142\x6c\145\x5f\152\163\x64\145\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\154\x69\x76\x65\162\x5f\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\x6c\x69\x76\x65\x72\40\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\x6c\145\40\x46\157\x72\40\x41\163\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\x20\x74\x68\x69\x73\40\157\x70\x74\x69\157\x6e\40\164\157\40\x72\x65\160\154\141\x63\x65\x20\x72\145\x73\157\x75\x72\x63\145\163\40\x62\x79\x20\112\123\104\145\x6c\x69\166\145\162\40\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
