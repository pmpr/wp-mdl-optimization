<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afa619aaca2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\x62\154\x65\137\152\x73\x64\145\154\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\x74\x5f\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\x69\x76\x65\162\x5f\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\x65\x6c\x69\x76\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\x6c\145\x20\x46\157\162\40\101\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\40\x74\150\x69\x73\x20\157\160\164\151\x6f\x6e\40\x74\x6f\40\162\x65\x70\154\141\143\x65\x20\x72\145\163\157\x75\x72\143\x65\163\40\142\x79\40\112\123\x44\x65\154\151\x76\145\162\40\x63\144\156\56", PR__MDL__OPTIMIZATION)))); } }
