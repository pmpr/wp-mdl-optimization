<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22d2c9f327             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\154\145\x5f\x6a\163\x64\x65\154\151\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\x74\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\x65\154\151\166\x65\x72\137\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\154\x69\x76\x65\x72\x20\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\154\145\40\x46\157\162\40\x41\163\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\x63\x6b\40\164\150\151\163\x20\157\160\x74\151\157\x6e\x20\164\x6f\x20\162\145\160\x6c\141\x63\145\40\x72\x65\163\x6f\165\x72\x63\x65\x73\40\142\171\x20\x4a\x53\104\x65\154\x69\x76\145\162\x20\143\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
