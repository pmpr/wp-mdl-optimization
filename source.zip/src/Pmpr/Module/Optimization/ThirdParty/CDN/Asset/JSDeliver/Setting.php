<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1342843d30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\x6c\x65\137\152\163\x64\145\154\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\145\164\x5f\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\145\x6c\151\x76\145\x72\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\x6c\151\166\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\154\x65\40\x46\157\x72\40\101\x73\x73\145\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\x63\153\x20\x74\150\x69\163\x20\x6f\160\164\151\x6f\x6e\40\x74\x6f\x20\x72\x65\x70\x6c\x61\x63\145\40\162\x65\163\157\x75\162\x63\x65\163\x20\142\x79\40\x4a\x53\104\145\154\x69\x76\x65\x72\x20\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
