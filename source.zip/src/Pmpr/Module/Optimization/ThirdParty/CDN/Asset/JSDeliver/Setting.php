<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f9435286             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\142\x6c\145\x5f\x6a\163\144\145\x6c\151\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\x74\137\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\x65\x6c\x69\166\x65\x72\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\145\x6c\151\166\145\162\x20\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\x62\x6c\145\40\106\157\x72\40\x41\163\163\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\153\x20\x74\150\x69\x73\40\x6f\x70\164\x69\157\x6e\40\x74\x6f\x20\162\x65\x70\x6c\141\x63\145\40\162\x65\163\157\x75\x72\x63\x65\163\40\142\171\x20\x4a\123\x44\x65\154\151\x76\145\x72\40\x63\144\156\56", PR__MDL__OPTIMIZATION)))); } }
