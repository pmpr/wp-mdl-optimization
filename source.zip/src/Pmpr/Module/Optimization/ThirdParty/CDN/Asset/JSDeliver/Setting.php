<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675815b20ad5f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\154\x65\137\152\163\144\x65\x6c\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\x65\x74\137\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\x6c\x69\x76\145\x72\x5f\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\x65\154\151\x76\x65\162\x20\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\x6c\x65\40\x46\157\162\40\x41\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\153\x20\x74\x68\x69\163\40\x6f\x70\x74\x69\157\156\x20\x74\157\40\162\x65\x70\154\141\143\x65\40\x72\145\163\157\165\x72\x63\145\x73\x20\142\x79\40\112\x53\x44\145\154\151\166\x65\162\x20\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
