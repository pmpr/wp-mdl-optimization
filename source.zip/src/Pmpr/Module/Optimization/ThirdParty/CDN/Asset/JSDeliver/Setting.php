<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637d2bee1dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\142\x6c\145\x5f\x6a\163\144\x65\x6c\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\x74\x5f\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\x6c\151\x76\x65\x72\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\154\x69\x76\x65\x72\40\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\142\x6c\145\x20\106\x6f\162\40\x41\x73\163\x65\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\143\153\x20\x74\x68\151\163\x20\x6f\x70\x74\x69\157\156\40\x74\x6f\x20\x72\x65\160\x6c\141\x63\x65\40\162\145\x73\157\x75\x72\143\x65\x73\x20\x62\171\x20\x4a\x53\104\145\154\151\166\145\162\x20\143\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
