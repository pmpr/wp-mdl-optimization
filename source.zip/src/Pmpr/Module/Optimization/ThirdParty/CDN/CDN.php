<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aec46370c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\Asset; use Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare\Cloudflare; class CDN extends Common { public function mameiwsayuyquoeq() { Asset::symcgieuakksimmu(); Cloudflare::symcgieuakksimmu(); } }
