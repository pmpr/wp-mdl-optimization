<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed4e3da1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer; use Pmpr\Module\Optimization\Container; abstract class Common extends Container { }
