<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b20910f9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\x65\170\164\145\156\163\151\157\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\164\150\x65\x6d\145")->gswweykyogmsyawy(__("\x54\x68\x65\x6d\145", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::aakkqqcouuoqymkg)); } }
