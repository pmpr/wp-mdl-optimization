<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f9435286             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; use Pmpr\Module\Optimization\Optimizer\Extension\Common as BaseClass; abstract class Common extends BaseClass { }
