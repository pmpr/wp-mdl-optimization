<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4e02be33a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; class Theme extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
