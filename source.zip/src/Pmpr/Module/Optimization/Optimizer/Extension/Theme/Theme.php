<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66697656b7da9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; class Theme extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
