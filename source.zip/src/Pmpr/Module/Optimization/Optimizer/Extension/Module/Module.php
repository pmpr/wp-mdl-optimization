<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2337171efe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Module; use Pmpr\Module\Optimization\Optimizer\Extension\Common; class Module extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
