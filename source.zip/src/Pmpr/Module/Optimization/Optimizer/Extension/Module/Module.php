<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56de52d1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Module; use Pmpr\Module\Optimization\Optimizer\Extension\Common; class Module extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
