<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a3b3fc9b6de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Module; use Pmpr\Module\Optimization\Optimizer\Extension\Common; class Module extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
