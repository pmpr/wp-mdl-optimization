<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4c57cf814             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\x65\x6e\x73\x69\x6f\x6e")->gswweykyogmsyawy(__("\x45\x78\164\145\x6e\x73\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\x75\x6c\x65\163\x2c\x20\143\x6f\166\x65\x72\163\x2c\x20\160\154\x75\x67\151\x6e\x73\x20\x61\x6e\x64\40\164\x68\x65\155\x65\x73\40\x43\x6f\x6e\x66\151\147\x75\162\141\164\151\157\x6e"))); } }
