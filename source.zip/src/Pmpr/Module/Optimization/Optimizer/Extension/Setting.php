<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af1935df9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\145\x6e\163\151\157\x6e")->gswweykyogmsyawy(__("\x45\170\164\x65\x6e\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\x75\x6c\145\163\54\40\x63\157\166\x65\x72\x73\x2c\40\x70\x6c\165\x67\x69\156\163\40\141\156\x64\x20\x74\x68\145\x6d\x65\x73\x20\103\157\156\146\x69\x67\x75\162\141\x74\x69\x6f\156"))); } }
