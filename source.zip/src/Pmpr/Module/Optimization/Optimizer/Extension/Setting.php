<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aecacc41ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\145\x6e\x73\x69\157\156")->gswweykyogmsyawy(__("\x45\170\x74\x65\156\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\x6c\x65\163\54\x20\143\157\166\x65\162\163\x2c\40\x70\154\x75\147\151\156\x73\x20\141\156\x64\40\x74\x68\x65\155\x65\163\x20\103\157\x6e\146\151\147\165\x72\x61\164\151\x6f\x6e"))); } }
