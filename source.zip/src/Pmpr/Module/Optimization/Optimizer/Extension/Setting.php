<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686855490492             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\x6e\163\x69\157\156")->gswweykyogmsyawy(__("\x45\170\x74\145\x6e\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\165\x6c\145\163\x2c\40\143\157\x76\x65\x72\x73\x2c\40\160\x6c\165\147\x69\x6e\x73\x20\x61\156\x64\40\x74\150\145\x6d\145\x73\x20\x43\157\156\146\x69\147\165\162\141\164\151\x6f\156"))); } }
