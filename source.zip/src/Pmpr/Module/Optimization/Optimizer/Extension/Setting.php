<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6688fb3b4b1ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\x6e\163\151\x6f\156")->gswweykyogmsyawy(__("\105\x78\x74\x65\x6e\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\165\x6c\x65\163\x2c\40\x63\157\166\145\162\163\x2c\x20\160\x6c\x75\x67\151\156\163\x20\141\x6e\144\40\x74\x68\x65\155\x65\x73\x20\103\157\x6e\146\151\x67\165\162\141\164\151\157\x6e"))); } }
