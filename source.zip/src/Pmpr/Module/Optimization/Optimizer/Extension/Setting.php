<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6347bb78c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\145\x6e\x73\151\157\156")->gswweykyogmsyawy(__("\x45\170\164\x65\156\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\x75\154\x65\x73\54\40\143\x6f\x76\145\162\163\x2c\x20\160\x6c\165\147\151\156\x73\40\x61\156\x64\40\x74\150\145\155\x65\163\x20\103\157\156\146\x69\147\165\x72\x61\164\x69\x6f\x6e"))); } }
