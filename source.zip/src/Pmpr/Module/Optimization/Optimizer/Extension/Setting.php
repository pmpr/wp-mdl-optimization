<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a608b965f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\156\x73\151\x6f\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\164\145\x6e\x73\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\165\154\145\x73\54\x20\143\157\x76\145\162\163\x2c\x20\x70\154\165\x67\151\x6e\163\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
