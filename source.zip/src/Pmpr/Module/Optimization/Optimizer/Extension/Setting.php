<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56de52d1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\145\x6e\163\x69\x6f\156")->gswweykyogmsyawy(__("\x45\x78\164\x65\x6e\x73\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\x6c\145\163\54\x20\143\157\x76\x65\x72\x73\54\40\160\x6c\165\147\x69\156\163\40\141\x6e\144\x20\x74\150\145\155\x65\163\x20\103\x6f\156\146\151\x67\x75\x72\141\164\x69\x6f\x6e"))); } }
