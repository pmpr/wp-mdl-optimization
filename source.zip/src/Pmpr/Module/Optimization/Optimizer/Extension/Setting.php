<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\145\156\163\x69\157\156")->gswweykyogmsyawy(__("\x45\x78\164\145\x6e\163\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\165\x6c\x65\163\54\40\143\x6f\166\x65\x72\x73\54\x20\x70\154\165\147\151\x6e\163\x20\141\156\x64\x20\x74\150\x65\155\x65\x73\x20\x43\x6f\156\x66\151\x67\x75\162\141\x74\151\157\156"))); } }
