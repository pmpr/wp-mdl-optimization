<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec8032739             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\145\x6e\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\164\x65\x6e\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\165\154\x65\163\54\40\x63\x6f\166\x65\162\x73\x2c\40\160\x6c\165\x67\151\x6e\x73\x20\141\156\x64\40\x74\x68\145\155\145\x73\x20\103\157\156\146\151\147\x75\162\141\x74\151\157\x6e"))); } }
