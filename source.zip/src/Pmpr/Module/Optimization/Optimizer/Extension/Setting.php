<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668660e287d70             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\x6e\x73\151\157\x6e")->gswweykyogmsyawy(__("\x45\170\x74\x65\156\163\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\165\154\x65\163\x2c\x20\x63\157\166\145\162\x73\54\x20\160\154\x75\147\x69\x6e\x73\x20\141\x6e\x64\40\x74\150\145\x6d\x65\163\x20\103\157\x6e\x66\151\x67\165\162\x61\164\x69\157\156"))); } }
