<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afa619aaca2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\156\163\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\164\x65\156\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\165\x6c\x65\163\x2c\x20\143\x6f\x76\145\x72\x73\54\x20\160\x6c\x75\147\x69\156\x73\x20\141\156\x64\x20\x74\150\x65\x6d\x65\163\40\x43\157\156\x66\151\x67\x75\x72\141\164\x69\157\x6e"))); } }
