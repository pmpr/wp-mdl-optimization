<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22d2c9f327             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\156\x73\151\157\156")->gswweykyogmsyawy(__("\105\170\x74\x65\x6e\x73\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\154\145\x73\54\40\143\x6f\166\x65\x72\x73\54\x20\x70\154\x75\x67\151\156\163\x20\x61\x6e\x64\x20\164\150\145\155\145\x73\40\103\x6f\x6e\146\x69\x67\x75\162\x61\x74\x69\157\x6e"))); } }
