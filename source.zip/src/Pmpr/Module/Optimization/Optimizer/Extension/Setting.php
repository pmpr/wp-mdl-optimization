<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bb05f1e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\156\163\x69\157\156")->gswweykyogmsyawy(__("\105\x78\x74\x65\156\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\x75\x6c\x65\x73\x2c\40\x63\157\166\145\x72\x73\54\x20\160\x6c\x75\x67\151\156\163\40\x61\156\x64\x20\x74\x68\x65\x6d\145\163\x20\103\x6f\x6e\x66\151\147\x75\162\141\x74\x69\157\x6e"))); } }
