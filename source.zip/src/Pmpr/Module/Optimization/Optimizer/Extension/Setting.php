<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69ee00a3ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\x6e\x73\x69\157\156")->gswweykyogmsyawy(__("\x45\170\x74\145\156\163\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\165\x6c\x65\163\54\x20\x63\x6f\x76\145\162\163\x2c\40\160\154\x75\x67\151\156\x73\40\x61\x6e\144\40\x74\150\145\x6d\145\163\40\x43\x6f\156\x66\151\x67\165\x72\x61\x74\x69\157\x6e"))); } }
