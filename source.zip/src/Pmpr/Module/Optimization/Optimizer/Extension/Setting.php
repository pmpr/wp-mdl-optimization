<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29dc7ba6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\145\156\163\151\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\x74\x65\x6e\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\154\145\x73\x2c\40\x63\157\x76\x65\x72\x73\x2c\x20\160\154\165\x67\x69\x6e\x73\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
