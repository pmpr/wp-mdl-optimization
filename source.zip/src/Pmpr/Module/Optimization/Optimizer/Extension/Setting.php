<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663757b0e9f86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\x65\x6e\163\x69\x6f\156")->gswweykyogmsyawy(__("\x45\170\164\145\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\x6c\x65\x73\x2c\x20\143\x6f\166\145\x72\163\x2c\40\x70\x6c\165\x67\x69\156\x73\40\x61\x6e\144\x20\x74\150\x65\x6d\x65\x73\40\x43\x6f\156\x66\151\147\x75\162\x61\164\151\x6f\x6e"))); } }
