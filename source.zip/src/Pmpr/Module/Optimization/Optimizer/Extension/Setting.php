<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350bd82c2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\x6e\163\x69\157\156")->gswweykyogmsyawy(__("\x45\x78\x74\x65\156\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\x6c\145\x73\54\x20\x63\157\166\x65\x72\x73\x2c\x20\160\154\165\x67\151\x6e\x73\x20\x61\156\144\x20\164\150\x65\155\x65\163\40\x43\157\x6e\146\151\147\x75\x72\141\x74\x69\x6f\x6e"))); } }
