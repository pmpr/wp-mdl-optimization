<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24006e45d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\145\x6e\163\x69\157\156")->gswweykyogmsyawy(__("\x45\170\164\145\x6e\x73\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\165\154\145\x73\54\40\143\x6f\x76\x65\x72\163\x2c\40\x70\x6c\165\147\151\156\163\40\141\156\144\x20\x74\x68\145\x6d\x65\x73\x20\x43\157\x6e\146\x69\147\x75\162\141\164\x69\x6f\x6e"))); } }
