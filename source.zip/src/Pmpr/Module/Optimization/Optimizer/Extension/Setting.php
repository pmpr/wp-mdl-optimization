<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af54c961e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\145\156\163\x69\157\x6e")->gswweykyogmsyawy(__("\105\170\x74\x65\x6e\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\x75\x6c\x65\163\x2c\40\x63\x6f\x76\145\x72\163\54\x20\160\154\x75\x67\151\156\163\40\141\156\144\40\x74\150\x65\155\145\x73\40\x43\157\x6e\x66\151\x67\165\162\x61\164\151\x6f\156"))); } }
