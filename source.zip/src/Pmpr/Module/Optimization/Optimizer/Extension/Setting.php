<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c6c5682             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\145\x6e\x73\151\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\170\164\145\156\163\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\165\x6c\x65\163\x2c\40\143\x6f\166\x65\162\x73\x2c\40\x70\x6c\x75\x67\x69\x6e\x73\56\56\56", PR__MDL__OPTIMIZATION))); } }
