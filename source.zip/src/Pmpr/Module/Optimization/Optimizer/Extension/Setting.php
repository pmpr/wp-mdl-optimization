<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7059178ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\156\163\x69\x6f\x6e")->gswweykyogmsyawy(__("\x45\x78\164\145\156\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\x75\154\145\x73\54\x20\x63\157\166\x65\162\163\x2c\40\160\154\x75\x67\x69\x6e\163\40\141\156\144\x20\164\150\145\x6d\x65\163\x20\x43\x6f\x6e\x66\151\147\x75\162\141\164\151\x6f\x6e"))); } }
