<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd21640c7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\x65\x6e\x73\151\157\x6e")->gswweykyogmsyawy(__("\105\170\164\x65\x6e\163\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\x75\154\x65\x73\54\x20\x63\x6f\x76\x65\162\x73\x2c\x20\160\x6c\x75\x67\x69\x6e\163\x20\x61\156\144\40\164\150\x65\x6d\x65\x73\40\x43\x6f\156\146\151\147\x75\162\x61\164\x69\x6f\156"))); } }
