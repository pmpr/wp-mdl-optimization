<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4f986c850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\x65\156\x73\151\157\x6e")->gswweykyogmsyawy(__("\x45\170\164\x65\x6e\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\x6c\x65\x73\54\40\143\x6f\x76\145\162\163\x2c\40\160\154\165\x67\151\156\x73\x20\x61\x6e\x64\x20\164\x68\x65\155\145\x73\40\x43\x6f\156\x66\151\x67\165\162\x61\164\151\x6f\x6e"))); } }
