<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dd893c52c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\145\x6e\x73\151\157\x6e")->gswweykyogmsyawy(__("\x45\x78\164\145\x6e\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\x6c\x65\x73\x2c\40\x63\157\x76\x65\x72\x73\x2c\40\160\154\x75\147\151\156\163\40\141\x6e\x64\40\x74\150\x65\155\x65\x73\x20\x43\157\x6e\146\x69\147\165\162\x61\x74\151\x6f\x6e"))); } }
