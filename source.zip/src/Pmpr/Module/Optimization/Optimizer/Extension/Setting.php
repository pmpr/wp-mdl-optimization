<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22efa3658b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\156\163\151\157\x6e")->gswweykyogmsyawy(__("\x45\170\164\x65\156\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\154\x65\x73\54\x20\x63\x6f\166\145\162\163\x2c\x20\160\154\x75\147\151\x6e\163\40\x61\156\x64\40\164\150\145\x6d\145\x73\40\x43\x6f\x6e\x66\151\x67\x75\162\141\x74\x69\x6f\x6e"))); } }
