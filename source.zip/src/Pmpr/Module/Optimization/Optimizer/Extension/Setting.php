<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cebac3c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\156\x73\151\x6f\156")->gswweykyogmsyawy(__("\105\170\164\145\156\163\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\165\154\x65\x73\x2c\x20\143\x6f\x76\x65\162\x73\x2c\x20\x70\x6c\x75\147\151\156\x73\x20\141\x6e\x64\40\x74\x68\145\x6d\145\163\40\x43\157\156\146\x69\147\x75\162\x61\164\151\157\x6e"))); } }
