<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b73dc7163             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Setting as PluginSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { PluginSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\x6e\163\151\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\170\x74\x65\156\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\x75\154\x65\163\54\40\x63\x6f\x76\x65\x72\163\54\40\160\x6c\165\147\151\x6e\x73\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
