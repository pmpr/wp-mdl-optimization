<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668b0fe6d179             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\145\x6e\x73\x69\157\156")->gswweykyogmsyawy(__("\105\170\164\145\156\x73\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\x6c\x65\x73\x2c\40\x63\x6f\166\x65\162\x73\x2c\x20\160\x6c\165\x67\151\x6e\163\x20\141\x6e\x64\40\x74\x68\145\x6d\145\x73\x20\x43\157\156\146\151\147\165\162\x61\x74\151\x6f\156"))); } }
