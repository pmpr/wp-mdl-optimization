<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf6837cd4a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\x6e\163\x69\157\156")->gswweykyogmsyawy(__("\x45\170\x74\x65\156\163\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\x75\154\x65\x73\x2c\40\x63\x6f\x76\x65\162\163\x2c\40\x70\154\165\x67\151\156\163\x20\141\x6e\x64\40\164\150\145\x6d\x65\163\x20\x43\x6f\156\x66\x69\147\x75\x72\x61\x74\x69\x6f\x6e"))); } }
