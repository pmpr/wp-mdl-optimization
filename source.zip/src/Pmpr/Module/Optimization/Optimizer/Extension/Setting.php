<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f9435286             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\156\163\151\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\x74\145\x6e\163\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\x6c\145\163\x2c\x20\x63\157\166\x65\x72\x73\54\x20\x70\154\x75\x67\151\x6e\x73\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
