<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\145\156\163\x69\x6f\156")->gswweykyogmsyawy(__("\x45\170\164\x65\x6e\163\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\x75\154\145\x73\54\x20\x63\157\166\145\x72\x73\54\x20\x70\x6c\x75\147\x69\156\163\40\x61\156\x64\40\164\x68\145\x6d\145\x73\40\x43\x6f\x6e\146\x69\x67\165\x72\141\x74\151\157\156"))); } }
