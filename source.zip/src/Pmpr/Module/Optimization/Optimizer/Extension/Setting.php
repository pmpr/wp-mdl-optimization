<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635076d1df7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\145\x6e\163\x69\157\x6e")->gswweykyogmsyawy(__("\105\170\164\145\x6e\163\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\154\x65\163\x2c\40\x63\x6f\x76\145\162\x73\x2c\40\x70\154\165\147\151\x6e\x73\x20\141\x6e\x64\40\164\150\145\155\x65\x73\x20\103\157\x6e\x66\151\x67\165\162\x61\x74\151\157\x6e"))); } }
