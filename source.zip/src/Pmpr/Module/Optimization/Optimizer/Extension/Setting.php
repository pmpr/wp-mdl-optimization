<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e6136ef8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\156\163\151\157\x6e")->gswweykyogmsyawy(__("\x45\170\x74\x65\x6e\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\165\154\x65\163\x2c\x20\x63\157\166\x65\162\x73\54\x20\160\154\165\x67\151\x6e\163\x20\x61\156\144\x20\x74\x68\145\x6d\x65\x73\x20\103\157\156\146\x69\x67\165\x72\x61\164\151\157\x6e"))); } }
