<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1e5357c62d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\156\163\151\157\156")->gswweykyogmsyawy(__("\105\170\164\145\156\163\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\154\145\163\54\40\143\x6f\x76\145\x72\x73\54\x20\160\x6c\165\147\151\x6e\163\x20\141\156\x64\40\x74\x68\x65\x6d\145\163\x20\103\157\156\146\x69\147\x75\x72\141\x74\x69\157\156"))); } }
