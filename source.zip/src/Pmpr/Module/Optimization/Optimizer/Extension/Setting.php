<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aeae0c9976             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\x6e\x73\x69\157\x6e")->gswweykyogmsyawy(__("\x45\170\164\x65\156\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\x6c\x65\x73\x2c\40\x63\157\166\x65\x72\163\54\x20\160\154\x75\x67\151\156\x73\40\141\156\x64\x20\x74\x68\145\155\x65\x73\x20\103\x6f\156\146\x69\x67\x75\162\x61\164\151\157\x6e"))); } }
