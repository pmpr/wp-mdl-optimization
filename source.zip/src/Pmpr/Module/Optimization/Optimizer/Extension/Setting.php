<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af79314d69             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\x6e\163\x69\157\x6e")->gswweykyogmsyawy(__("\105\x78\x74\145\156\163\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\154\145\x73\54\x20\143\x6f\x76\x65\x72\163\54\40\x70\154\x75\x67\x69\156\163\x20\141\x6e\x64\x20\x74\x68\x65\x6d\x65\163\40\103\157\x6e\x66\151\x67\165\x72\x61\x74\x69\x6f\156"))); } }
