<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32f1aa2d0a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\x6e\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\x78\164\x65\x6e\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\x75\x6c\x65\163\54\40\x63\x6f\166\x65\162\163\54\x20\160\154\x75\147\151\156\163\x20\x61\x6e\x64\40\164\150\x65\x6d\x65\163\40\103\x6f\x6e\x66\151\x67\x75\162\x61\164\151\157\x6e"))); } }
