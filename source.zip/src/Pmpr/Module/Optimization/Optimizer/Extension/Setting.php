<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c60b0e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Setting as PluginSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { PluginSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\x65\156\163\x69\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\164\x65\x6e\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\x6c\145\163\x2c\x20\x63\x6f\x76\x65\162\163\x2c\40\160\154\x75\x67\151\x6e\163\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
