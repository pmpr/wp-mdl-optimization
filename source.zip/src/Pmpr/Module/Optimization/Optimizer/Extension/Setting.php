<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f44c67227             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\145\x6e\x73\151\x6f\156")->gswweykyogmsyawy(__("\x45\x78\x74\145\x6e\163\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\165\x6c\x65\x73\54\40\143\157\166\145\x72\163\x2c\40\x70\154\x75\x67\151\x6e\163\x20\141\156\x64\x20\164\x68\x65\155\x65\163\x20\103\x6f\156\x66\x69\147\165\x72\141\x74\151\157\156"))); } }
