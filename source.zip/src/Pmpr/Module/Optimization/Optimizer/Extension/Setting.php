<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ada53dffd1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\156\163\x69\157\156")->gswweykyogmsyawy(__("\x45\x78\x74\145\156\163\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\x75\154\x65\x73\x2c\40\143\157\x76\145\x72\x73\54\x20\x70\x6c\165\147\x69\156\x73\40\x61\x6e\144\40\164\x68\145\x6d\x65\x73\40\103\x6f\x6e\146\x69\x67\x75\x72\x61\164\151\x6f\x6e"))); } }
