<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec4797d504             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\145\x6e\163\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\x78\x74\x65\x6e\163\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\165\x6c\145\163\x2c\40\x63\x6f\x76\145\162\x73\54\40\x70\x6c\165\147\x69\x6e\x73\40\x61\x6e\144\40\164\x68\x65\155\145\x73\40\x43\157\156\x66\x69\147\165\162\141\164\151\x6f\156"))); } }
