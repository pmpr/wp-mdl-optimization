<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eafa500a52f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\145\156\x73\151\157\x6e")->gswweykyogmsyawy(__("\x45\x78\x74\x65\156\163\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\x6c\x65\x73\54\40\x63\x6f\166\x65\162\163\x2c\x20\x70\154\x75\x67\x69\x6e\163\x20\x61\156\x64\40\164\x68\145\155\x65\x73\x20\x43\x6f\156\146\151\147\x75\x72\141\x74\151\157\156"))); } }
