<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668724cd3b441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\x65\x6e\163\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\x74\145\156\163\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\x75\x6c\x65\163\54\x20\x63\x6f\x76\x65\x72\x73\54\40\160\154\x75\x67\151\156\x73\40\x61\156\x64\x20\164\150\145\x6d\145\163\40\103\157\156\146\x69\147\x75\x72\141\164\x69\157\x6e"))); } }
