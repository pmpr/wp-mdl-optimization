<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c30d9443ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\x65\156\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\105\x78\164\145\x6e\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\x6c\145\163\x2c\40\x63\157\x76\145\162\x73\x2c\x20\160\x6c\x75\x67\x69\156\163\40\x61\156\144\x20\x74\150\x65\155\145\x73\40\x43\x6f\156\146\151\x67\165\x72\141\164\x69\x6f\x6e"))); } }
