<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689b42493617             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\x65\x6e\x73\151\157\156")->gswweykyogmsyawy(__("\105\170\x74\x65\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\165\154\x65\x73\54\x20\x63\x6f\166\x65\162\163\x2c\x20\160\154\x75\x67\x69\x6e\163\40\141\156\x64\40\x74\150\x65\x6d\145\163\40\x43\157\156\146\x69\x67\x75\x72\x61\164\151\x6f\156"))); } }
