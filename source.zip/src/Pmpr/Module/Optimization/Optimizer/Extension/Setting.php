<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7139a54fa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\156\x73\151\157\156")->gswweykyogmsyawy(__("\x45\x78\164\145\156\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\165\154\x65\163\x2c\40\x63\157\166\145\x72\x73\54\x20\160\x6c\x75\x67\x69\x6e\x73\40\141\x6e\x64\40\164\150\x65\155\x65\163\x20\103\157\x6e\146\x69\147\x75\x72\141\x74\151\157\x6e"))); } }
