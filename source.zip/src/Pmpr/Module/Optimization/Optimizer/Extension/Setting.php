<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580890b0d1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Setting as PluginSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { PluginSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\x65\x6e\163\x69\x6f\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\x74\x65\156\x73\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\x6c\145\163\x2c\x20\x63\x6f\x76\x65\162\x73\x2c\40\160\x6c\x75\147\151\x6e\x73\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
