<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663503140fc0e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\x6e\x73\151\x6f\156")->gswweykyogmsyawy(__("\x45\x78\x74\145\x6e\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\154\145\x73\54\40\143\157\x76\145\x72\163\x2c\40\160\154\x75\147\x69\156\163\x20\x61\156\144\40\x74\x68\145\155\145\163\x20\x43\157\x6e\146\151\147\165\x72\x61\164\151\157\x6e"))); } }
