<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79d4da80             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\x6e\163\x69\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\x74\145\156\163\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\154\x65\163\54\x20\143\x6f\x76\145\x72\163\x2c\x20\160\x6c\x75\147\151\156\163\40\x61\156\144\40\x74\x68\x65\155\x65\163\40\103\157\156\x66\x69\147\x75\162\141\x74\x69\x6f\x6e"))); } }
