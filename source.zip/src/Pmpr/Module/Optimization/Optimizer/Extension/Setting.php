<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1eae63b52e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\x6e\163\x69\157\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\164\x65\x6e\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\165\154\x65\x73\54\40\x63\x6f\x76\145\x72\163\54\40\x70\154\x75\x67\x69\x6e\163\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
