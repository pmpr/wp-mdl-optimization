<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635046c437f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\156\x73\x69\x6f\156")->gswweykyogmsyawy(__("\105\170\164\145\156\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\154\x65\x73\54\40\x63\157\166\x65\x72\163\54\x20\x70\154\x75\147\151\156\x73\40\141\156\x64\x20\x74\x68\145\x6d\145\163\40\x43\157\x6e\146\151\147\165\x72\141\164\151\x6f\156"))); } }
