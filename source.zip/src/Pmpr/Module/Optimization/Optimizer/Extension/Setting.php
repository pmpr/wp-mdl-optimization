<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2182256c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\156\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\x74\145\156\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\154\x65\163\54\x20\143\x6f\x76\145\162\x73\x2c\x20\x70\x6c\165\147\x69\156\163\x20\141\x6e\x64\x20\164\150\145\155\145\x73\40\103\157\156\146\151\x67\x75\162\x61\x74\151\157\156"))); } }
