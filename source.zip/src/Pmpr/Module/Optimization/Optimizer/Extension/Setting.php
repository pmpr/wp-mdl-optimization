<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a54fbc54301             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\x65\156\163\x69\x6f\156")->gswweykyogmsyawy(__("\x45\170\x74\x65\156\163\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\x75\x6c\145\x73\54\x20\x63\157\x76\145\x72\163\x2c\x20\x70\x6c\x75\147\x69\x6e\163\x20\x61\156\144\40\x74\x68\145\x6d\x65\163\x20\103\x6f\156\x66\151\147\165\x72\141\x74\x69\157\156"))); } }
