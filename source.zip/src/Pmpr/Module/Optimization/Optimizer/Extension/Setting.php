<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637dda1d1856             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\156\163\151\x6f\156")->gswweykyogmsyawy(__("\105\x78\x74\x65\156\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\x6c\145\x73\54\40\143\x6f\x76\x65\x72\163\54\40\160\x6c\x75\x67\x69\x6e\163\40\141\x6e\x64\x20\x74\150\x65\x6d\x65\x73\x20\x43\x6f\156\x66\151\147\165\x72\141\164\151\157\x6e"))); } }
