<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668750eb007f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\x65\x6e\x73\x69\157\156")->gswweykyogmsyawy(__("\x45\170\x74\x65\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\154\145\163\54\40\x63\157\166\145\162\163\x2c\x20\160\x6c\x75\x67\x69\156\x73\40\141\156\x64\x20\164\150\x65\155\145\163\40\103\157\x6e\146\x69\x67\x75\162\141\164\151\x6f\156"))); } }
