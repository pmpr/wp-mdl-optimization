<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666957c99839f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\145\x6e\x73\x69\157\156")->gswweykyogmsyawy(__("\105\170\164\x65\156\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\x75\x6c\x65\x73\54\40\143\157\166\x65\162\x73\54\40\x70\x6c\x75\x67\x69\156\x73\x20\x61\156\144\x20\164\150\x65\x6d\145\x73\x20\103\157\x6e\146\x69\147\165\162\x61\x74\151\x6f\x6e"))); } }
