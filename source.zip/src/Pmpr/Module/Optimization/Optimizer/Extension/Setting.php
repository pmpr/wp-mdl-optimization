<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d5dd19f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\x6e\x73\151\157\156")->gswweykyogmsyawy(__("\105\170\x74\x65\156\x73\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\x6c\145\x73\54\40\x63\157\x76\x65\162\x73\x2c\40\160\x6c\x75\x67\x69\156\x73\x20\141\x6e\144\x20\164\150\145\x6d\145\163\40\x43\157\156\146\151\x67\165\162\x61\164\x69\157\x6e"))); } }
