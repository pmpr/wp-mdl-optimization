<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5e4c040             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\x6e\x73\151\157\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\x74\x65\156\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\x6c\x65\x73\54\x20\143\157\166\x65\x72\163\54\40\x70\x6c\165\x67\x69\156\163\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
