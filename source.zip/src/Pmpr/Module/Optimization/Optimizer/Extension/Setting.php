<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c381549fb7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\x6e\x73\x69\157\x6e")->gswweykyogmsyawy(__("\105\170\x74\145\156\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\154\x65\163\x2c\x20\143\x6f\x76\x65\162\x73\x2c\40\160\x6c\x75\x67\151\x6e\x73\x20\x61\156\144\40\x74\150\x65\x6d\145\163\x20\x43\157\x6e\x66\x69\x67\165\162\x61\x74\151\x6f\x6e"))); } }
