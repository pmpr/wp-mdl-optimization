<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef5105e9703             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\145\x6e\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\164\145\156\163\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\154\145\163\54\x20\x63\157\166\145\x72\163\x2c\x20\160\x6c\165\147\151\x6e\163\40\141\156\x64\x20\164\150\x65\x6d\x65\x73\40\x43\x6f\156\146\x69\147\165\162\141\x74\151\157\156"))); } }
