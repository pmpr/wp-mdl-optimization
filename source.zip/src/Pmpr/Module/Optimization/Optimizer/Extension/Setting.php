<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665875e35aad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\x65\x6e\x73\x69\x6f\156")->gswweykyogmsyawy(__("\x45\170\x74\145\x6e\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\x6c\x65\163\54\40\143\157\166\x65\x72\x73\54\40\160\154\165\x67\151\156\163\x20\141\156\x64\40\x74\150\145\x6d\145\163\x20\x43\157\156\146\x69\x67\165\162\141\x74\151\x6f\x6e"))); } }
