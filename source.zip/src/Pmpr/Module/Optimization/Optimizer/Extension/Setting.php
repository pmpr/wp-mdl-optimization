<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb0c5939             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\156\163\x69\x6f\156")->gswweykyogmsyawy(__("\x45\170\164\145\156\163\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\x75\154\x65\163\54\x20\143\x6f\166\145\x72\163\54\40\160\154\165\147\x69\x6e\x73\40\x61\156\144\x20\x74\150\x65\x6d\x65\163\x20\103\x6f\x6e\146\x69\x67\165\162\141\x74\151\x6f\156"))); } }
