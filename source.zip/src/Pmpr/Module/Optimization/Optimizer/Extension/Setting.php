<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1e5ce2c87e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\145\156\163\151\x6f\156")->gswweykyogmsyawy(__("\105\170\164\145\x6e\163\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\165\154\x65\x73\54\40\143\157\166\145\162\x73\54\40\x70\154\165\x67\x69\156\163\x20\x61\x6e\x64\40\x74\x68\x65\155\x65\x73\40\x43\x6f\x6e\146\151\x67\x75\x72\141\164\151\157\156"))); } }
