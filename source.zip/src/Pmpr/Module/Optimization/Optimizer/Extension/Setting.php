<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668709b77727f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\x6e\163\x69\x6f\x6e")->gswweykyogmsyawy(__("\105\170\x74\145\x6e\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\x6c\x65\163\54\40\143\157\x76\145\162\163\54\x20\x70\x6c\165\x67\151\156\x73\x20\141\156\x64\x20\x74\150\145\x6d\145\x73\40\103\x6f\156\146\151\147\165\x72\x61\x74\151\x6f\x6e"))); } }
