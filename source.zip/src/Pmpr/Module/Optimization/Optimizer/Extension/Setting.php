<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ad6e880229             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\156\x73\x69\x6f\156")->gswweykyogmsyawy(__("\105\x78\164\145\x6e\163\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\154\x65\x73\x2c\40\x63\x6f\166\145\x72\x73\54\40\x70\x6c\x75\x67\x69\156\163\40\141\x6e\x64\x20\164\x68\145\155\145\163\x20\x43\x6f\156\146\x69\x67\165\x72\141\164\151\157\156"))); } }
