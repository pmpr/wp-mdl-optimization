<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689580cbf1c8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\x6e\163\x69\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\164\145\x6e\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\x75\154\x65\163\x2c\40\143\157\x76\x65\162\163\54\x20\160\154\x75\x67\151\x6e\x73\x20\141\156\144\x20\164\x68\145\155\x65\163\40\x43\157\x6e\146\x69\x67\165\162\x61\x74\x69\x6f\x6e"))); } }
