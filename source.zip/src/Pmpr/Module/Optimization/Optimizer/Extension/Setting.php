<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2337171efe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\x6e\x73\x69\x6f\156")->gswweykyogmsyawy(__("\105\x78\x74\145\x6e\163\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\x6c\145\x73\x2c\x20\143\x6f\166\x65\x72\x73\x2c\40\x70\154\165\147\x69\x6e\x73\40\x61\x6e\144\x20\x74\150\145\x6d\145\x73\x20\x43\x6f\x6e\x66\151\x67\x75\162\141\164\151\157\156"))); } }
