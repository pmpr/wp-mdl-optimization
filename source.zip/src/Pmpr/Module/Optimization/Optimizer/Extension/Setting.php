<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce68cc41878             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\156\x73\x69\157\156")->gswweykyogmsyawy(__("\x45\x78\x74\x65\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\x75\154\145\163\54\x20\143\x6f\166\x65\x72\163\54\x20\x70\x6c\x75\147\x69\x6e\163\x20\141\x6e\144\x20\x74\150\145\x6d\145\163\40\x43\157\156\146\x69\147\165\162\x61\164\151\157\156"))); } }
