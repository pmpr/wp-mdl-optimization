<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d30394ae64b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\x65\156\163\151\x6f\x6e")->gswweykyogmsyawy(__("\105\170\164\145\x6e\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\165\x6c\145\x73\54\x20\143\x6f\166\x65\x72\163\54\40\x70\x6c\x75\147\151\156\x73\x20\141\156\144\40\x74\x68\x65\155\x65\163\40\103\x6f\x6e\x66\151\x67\165\x72\x61\164\151\x6f\156"))); } }
