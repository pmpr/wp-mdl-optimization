<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2162b04da4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\156\163\x69\x6f\x6e")->gswweykyogmsyawy(__("\x45\170\x74\145\156\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\x75\154\145\x73\54\x20\x63\157\x76\x65\x72\x73\54\40\160\154\x75\x67\x69\156\x73\40\x61\156\144\x20\164\150\x65\155\x65\163\x20\x43\x6f\156\146\151\147\x75\162\141\164\151\x6f\156"))); } }
