<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66788399683ac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\x6e\x73\151\157\x6e")->gswweykyogmsyawy(__("\105\170\x74\145\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\165\154\145\x73\54\x20\143\157\x76\145\162\x73\x2c\x20\x70\154\x75\147\151\x6e\163\x20\141\x6e\x64\40\164\150\145\155\x65\x73\40\x43\x6f\x6e\146\x69\x67\x75\162\x61\x74\x69\157\x6e"))); } }
