<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634ff5a86835             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\156\163\151\157\156")->gswweykyogmsyawy(__("\105\x78\x74\145\156\163\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\154\x65\163\54\x20\x63\x6f\x76\145\x72\x73\54\40\160\x6c\165\x67\x69\156\163\x20\141\156\144\40\164\x68\x65\155\145\163\x20\103\x6f\x6e\146\151\147\x75\x72\x61\x74\151\x6f\156"))); } }
