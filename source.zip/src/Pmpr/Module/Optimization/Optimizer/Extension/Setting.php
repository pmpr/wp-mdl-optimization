<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bec25a4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\145\x6e\x73\151\157\x6e")->gswweykyogmsyawy(__("\x45\x78\x74\145\156\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\165\154\145\163\x2c\40\143\x6f\166\145\x72\x73\54\40\160\154\165\x67\151\x6e\163\40\141\x6e\144\x20\164\x68\x65\x6d\145\x73\x20\103\157\156\146\151\147\x75\162\141\x74\151\157\x6e"))); } }
