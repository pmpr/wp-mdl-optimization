<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668aef2e0bbf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\156\x73\151\157\156")->gswweykyogmsyawy(__("\105\170\164\145\156\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\x75\x6c\x65\163\54\x20\143\x6f\x76\145\162\163\54\40\x70\154\x75\147\x69\156\x73\x20\141\156\144\40\164\x68\x65\155\x65\x73\40\x43\157\156\x66\151\x67\165\x72\141\164\x69\x6f\156"))); } }
