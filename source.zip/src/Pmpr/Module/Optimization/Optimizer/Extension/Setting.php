<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afcef5beb16             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\145\x6e\163\151\x6f\156")->gswweykyogmsyawy(__("\105\170\x74\x65\156\163\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\154\145\x73\x2c\40\x63\x6f\x76\x65\x72\163\54\40\160\154\165\147\151\156\163\40\x61\x6e\144\40\164\150\145\155\x65\163\40\x43\x6f\156\x66\151\x67\x75\x72\x61\x74\x69\157\x6e"))); } }
