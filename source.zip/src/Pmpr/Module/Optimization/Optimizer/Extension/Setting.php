<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132a7dc622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\145\x6e\x73\x69\157\x6e")->gswweykyogmsyawy(__("\105\x78\164\x65\x6e\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\165\154\145\163\54\40\x63\157\166\145\162\163\x2c\x20\160\154\165\x67\151\x6e\163\x20\141\x6e\144\x20\x74\x68\145\x6d\x65\163\40\103\157\x6e\146\x69\x67\x75\x72\x61\164\151\x6f\x6e"))); } }
