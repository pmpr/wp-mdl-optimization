<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708194f632             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\156\x73\x69\x6f\156")->gswweykyogmsyawy(__("\105\x78\x74\145\x6e\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\x75\154\145\x73\x2c\x20\143\x6f\x76\145\162\163\54\40\160\154\165\147\x69\x6e\x73\x20\x61\156\144\x20\164\150\x65\155\145\163\40\103\x6f\156\146\x69\147\165\x72\141\164\x69\157\x6e"))); } }
