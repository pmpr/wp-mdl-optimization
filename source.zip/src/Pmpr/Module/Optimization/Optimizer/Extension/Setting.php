<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2e8b4802f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\145\156\x73\x69\157\x6e")->gswweykyogmsyawy(__("\x45\x78\x74\145\x6e\163\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\165\x6c\145\x73\x2c\40\143\x6f\x76\145\162\x73\x2c\x20\160\154\165\147\151\156\163\x20\x61\156\x64\40\x74\x68\x65\x6d\145\x73\40\103\x6f\x6e\146\151\147\x75\162\x61\x74\151\x6f\x6e"))); } }
