<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed4e3da1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\145\156\163\151\x6f\x6e")->gswweykyogmsyawy(__("\105\x78\164\x65\156\x73\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\165\x6c\145\x73\54\40\x63\x6f\x76\x65\162\x73\54\40\x70\154\165\x67\151\156\163\x20\141\156\144\x20\x74\150\x65\x6d\145\x73\40\103\157\156\x66\151\x67\165\162\x61\x74\x69\x6f\x6e"))); } }
