<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d249276cd51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\156\163\x69\157\156")->gswweykyogmsyawy(__("\105\170\164\x65\x6e\x73\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\x6c\x65\163\54\40\143\157\x76\x65\162\x73\x2c\40\x70\154\x75\x67\151\156\163\40\141\156\144\x20\164\150\x65\x6d\x65\x73\x20\103\157\x6e\x66\x69\147\x75\x72\141\164\151\x6f\x6e"))); } }
