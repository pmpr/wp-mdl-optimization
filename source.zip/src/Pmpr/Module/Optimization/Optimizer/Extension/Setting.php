<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3161a77b51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\156\163\151\157\156")->gswweykyogmsyawy(__("\105\x78\x74\x65\156\163\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\x75\154\145\163\54\40\143\157\x76\x65\162\163\x2c\x20\160\154\165\147\x69\156\163\x20\x61\156\144\40\x74\150\x65\155\x65\163\x20\x43\x6f\156\x66\x69\x67\165\x72\141\x74\x69\157\156"))); } }
