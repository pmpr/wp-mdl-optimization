<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2393d5ec4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\156\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\105\x78\x74\x65\x6e\x73\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\x6c\145\x73\54\x20\x63\x6f\166\x65\x72\163\54\x20\x70\x6c\x75\x67\x69\156\x73\x20\x61\156\144\40\x74\x68\145\x6d\145\x73\x20\x43\157\x6e\146\151\147\x75\162\141\x74\x69\157\x6e"))); } }
