<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f51179ea7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\145\156\x73\x69\157\x6e")->gswweykyogmsyawy(__("\x45\x78\x74\145\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\165\x6c\145\x73\54\40\143\157\x76\x65\162\163\54\x20\160\x6c\x75\x67\x69\156\x73\40\141\156\x64\x20\x74\150\x65\155\x65\x73\40\103\x6f\x6e\146\x69\147\165\162\141\164\151\157\156"))); } }
