<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666978e4a7c7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\x6e\x73\151\x6f\156")->gswweykyogmsyawy(__("\x45\170\164\x65\x6e\163\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\154\x65\x73\x2c\40\143\x6f\166\145\162\163\x2c\40\160\154\x75\x67\151\x6e\x73\x20\141\156\x64\x20\164\x68\145\x6d\x65\163\x20\103\157\156\146\x69\x67\x75\x72\x61\x74\x69\157\156"))); } }
