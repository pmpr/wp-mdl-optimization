<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22e0b4cda5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\156\x73\x69\157\156")->gswweykyogmsyawy(__("\105\170\164\145\x6e\163\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\165\x6c\x65\163\54\40\x63\x6f\166\x65\162\x73\54\40\160\x6c\x75\147\151\x6e\163\40\141\x6e\x64\x20\164\150\145\155\145\163\x20\103\x6f\x6e\x66\151\x67\165\x72\x61\164\151\157\x6e"))); } }
