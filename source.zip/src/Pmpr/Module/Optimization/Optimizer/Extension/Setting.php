<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13791817e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\145\x6e\x73\151\157\156")->gswweykyogmsyawy(__("\105\170\164\145\156\163\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\x75\154\145\163\54\x20\143\157\x76\145\x72\x73\54\40\x70\154\x75\147\x69\x6e\163\x20\x61\156\x64\40\164\x68\145\155\x65\163\40\103\x6f\156\146\151\147\x75\x72\x61\164\x69\x6f\x6e"))); } }
