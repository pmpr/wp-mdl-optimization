<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69a35d5c5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\145\x6e\x73\151\157\156")->gswweykyogmsyawy(__("\105\170\164\145\156\163\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\165\x6c\x65\x73\x2c\x20\x63\x6f\166\x65\162\163\x2c\40\160\x6c\165\147\151\x6e\x73\x20\x61\x6e\144\40\x74\x68\x65\155\x65\163\x20\x43\157\156\x66\x69\x67\165\162\141\164\151\157\x6e"))); } }
