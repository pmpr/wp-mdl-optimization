<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637d2bee1dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\x6e\163\151\x6f\156")->gswweykyogmsyawy(__("\105\x78\164\145\156\163\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\154\x65\x73\54\40\143\157\166\145\162\163\x2c\40\160\x6c\165\147\x69\156\x73\40\x61\x6e\144\40\164\150\x65\155\x65\163\x20\103\x6f\x6e\146\151\x67\x75\162\x61\x74\151\x6f\156"))); } }
