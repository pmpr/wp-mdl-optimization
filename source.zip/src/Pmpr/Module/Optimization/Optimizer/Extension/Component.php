<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132a7dc622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\162\137\x63\x6f\x6d\160\x6f\x6e\145\x6e\x74\137\x63\x68\141\156\147\145\x64", [$this, "\155\145\x6b\153\167\x6d\141\x63\163\x79\157\x75\161\171\165\x6d"]); $this->waqewsckuayqguos("\163\x65\164\164\x69\x6e\147\x5f\x6f\160\164\151\x6f\x6e\x73\137\163\x61\x76\145\144", [$this, "\155\145\x6b\153\x77\x6d\141\x63\163\x79\x6f\x75\x71\171\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
