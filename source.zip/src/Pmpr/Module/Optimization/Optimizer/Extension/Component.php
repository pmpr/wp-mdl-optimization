<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2393d5ec4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\160\x72\x5f\143\x6f\x6d\160\157\156\x65\156\x74\137\143\x68\x61\156\147\145\144", [$this, "\x6d\x65\153\153\167\x6d\x61\143\x73\171\157\165\x71\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\164\x74\151\156\147\137\157\x70\164\x69\157\x6e\163\137\x73\141\x76\145\x64", [$this, "\155\x65\153\153\x77\155\141\x63\163\171\x6f\x75\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
