<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6e608ebb7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\x72\137\x63\157\155\x70\157\x6e\x65\156\164\137\x63\150\141\156\147\145\x64", [$this, "\x6d\x65\153\x6b\167\155\141\143\163\171\157\x75\x71\x79\165\155"]); $this->waqewsckuayqguos("\163\x65\164\x74\151\156\x67\x5f\157\x70\164\x69\x6f\156\x73\137\163\141\x76\x65\144", [$this, "\x6d\145\153\153\x77\155\x61\x63\163\x79\157\x75\x71\171\165\155"]); } public function mekkwmacsyouqyum() { } }
