<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4f986c850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\137\143\157\155\x70\157\156\145\x6e\x74\x5f\x63\150\x61\156\147\145\144", [$this, "\x6d\145\153\x6b\x77\x6d\141\x63\x73\171\157\165\161\x79\165\x6d"]); $this->waqewsckuayqguos("\163\145\164\164\151\x6e\147\x5f\157\160\164\151\157\156\x73\x5f\x73\x61\x76\x65\144", [$this, "\x6d\x65\153\153\x77\155\x61\143\163\171\x6f\x75\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
