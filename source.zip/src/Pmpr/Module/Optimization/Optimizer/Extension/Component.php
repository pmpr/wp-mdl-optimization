<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69ee00a3ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\x72\x5f\x63\x6f\x6d\x70\157\x6e\x65\156\164\137\143\x68\141\156\147\x65\144", [$this, "\x6d\x65\153\153\167\155\x61\x63\x73\x79\x6f\x75\x71\171\x75\155"]); $this->waqewsckuayqguos("\163\x65\x74\164\151\x6e\x67\x5f\157\x70\x74\x69\x6f\x6e\163\x5f\x73\x61\166\x65\x64", [$this, "\x6d\x65\x6b\x6b\167\155\141\x63\x73\x79\157\165\161\x79\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\x70\165\162\147\x65\137\x63\141\143\150\x65"); } }
