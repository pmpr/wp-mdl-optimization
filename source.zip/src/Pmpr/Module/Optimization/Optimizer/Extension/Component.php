<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16a5cc8402             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\143\x6f\x6d\160\x6f\x6e\145\x6e\x74\x5f\143\x68\141\156\147\145\x64", [$this, "\155\x65\x6b\153\x77\155\141\x63\x73\x79\x6f\165\161\x79\165\155"]); $this->waqewsckuayqguos("\x73\x65\x74\x74\151\156\147\x5f\x6f\160\x74\151\x6f\x6e\163\137\163\141\166\145\x64", [$this, "\x6d\145\x6b\x6b\x77\155\141\143\163\171\157\165\x71\x79\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\145\137\x63\141\x63\x68\145"); } }
