<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819c784426             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\162\x5f\143\x6f\x6d\160\x6f\x6e\x65\156\x74\x5f\x63\x68\141\x6e\x67\x65\144", [$this, "\x6d\145\153\153\x77\x6d\x61\143\163\171\x6f\165\x71\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\x74\x69\156\x67\x5f\157\x70\164\x69\x6f\156\x73\137\163\141\x76\145\144", [$this, "\x6d\145\153\153\x77\x6d\141\x63\163\171\x6f\x75\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\x75\x72\x67\x65\137\x68\164\x6d\x6c\x5f\143\141\143\150\145"); } }
