<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb243a19822             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\x5f\143\x6f\155\x70\x6f\x6e\x65\156\164\137\143\150\141\156\147\x65\144", [$this, "\x6d\145\x6b\153\167\x6d\141\143\163\x79\x6f\x75\161\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\145\164\164\x69\156\147\x5f\157\160\164\151\157\156\x73\137\x73\x61\x76\x65\144", [$this, "\x6d\x65\x6b\x6b\x77\155\141\143\163\x79\157\x75\x71\x79\165\x6d"]); } public function mekkwmacsyouqyum() { } }
