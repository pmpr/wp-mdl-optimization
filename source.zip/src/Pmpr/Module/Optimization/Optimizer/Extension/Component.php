<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a608b965f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\137\x63\157\x6d\160\157\x6e\x65\x6e\x74\137\x63\x68\141\156\x67\145\x64", [$this, "\x6d\145\153\153\x77\155\x61\143\163\171\x6f\165\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\164\164\151\156\x67\x5f\x6f\x70\164\151\x6f\x6e\x73\x5f\x73\141\166\145\144", [$this, "\x6d\145\x6b\x6b\167\155\x61\x63\x73\x79\x6f\165\161\171\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\145\137\143\x61\143\150\145"); } }
