<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25d3ac530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\x5f\143\x6f\155\160\157\156\x65\156\164\x5f\143\150\x61\156\147\x65\144", [$this, "\155\145\153\153\167\x6d\x61\x63\163\x79\157\165\161\x79\165\x6d"]); $this->waqewsckuayqguos("\163\145\164\164\x69\156\x67\137\157\160\x74\x69\x6f\156\x73\137\163\x61\x76\145\x64", [$this, "\155\x65\153\153\x77\x6d\x61\x63\x73\171\157\165\161\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
