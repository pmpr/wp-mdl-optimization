<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4181e072c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\x5f\143\157\x6d\160\157\x6e\x65\156\x74\137\143\x68\141\x6e\x67\x65\x64", [$this, "\x6d\x65\153\x6b\x77\155\141\x63\x73\171\x6f\165\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\x65\164\164\151\156\x67\x5f\157\x70\164\x69\157\156\x73\137\x73\141\166\145\144", [$this, "\x6d\x65\153\x6b\167\x6d\141\x63\x73\171\157\x75\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\160\x75\x72\147\x65\137\143\x61\x63\150\145"); } }
