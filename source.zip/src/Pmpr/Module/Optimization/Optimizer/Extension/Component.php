<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d230b1b85af             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\143\157\155\160\157\156\x65\x6e\x74\137\143\150\x61\x6e\147\145\x64", [$this, "\x6d\x65\x6b\153\x77\x6d\141\143\163\x79\157\165\161\171\165\155"]); $this->waqewsckuayqguos("\163\145\x74\x74\x69\156\x67\137\x6f\160\164\151\157\x6e\x73\137\163\x61\166\145\144", [$this, "\x6d\145\x6b\153\x77\155\141\143\x73\x79\x6f\165\161\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
