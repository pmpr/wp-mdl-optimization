<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3161a77b51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\x72\x5f\143\x6f\155\160\x6f\x6e\145\x6e\164\137\x63\150\141\x6e\x67\145\144", [$this, "\x6d\x65\x6b\x6b\167\x6d\141\143\163\171\x6f\x75\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\163\145\164\164\151\156\x67\x5f\x6f\x70\x74\151\157\156\x73\x5f\163\141\x76\145\144", [$this, "\155\145\x6b\153\167\x6d\x61\x63\163\x79\x6f\x75\161\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
