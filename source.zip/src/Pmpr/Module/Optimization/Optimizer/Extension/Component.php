<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1de2caabf8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\137\x63\157\x6d\160\157\156\145\156\x74\137\143\x68\141\156\x67\145\144", [$this, "\155\x65\x6b\x6b\x77\x6d\x61\x63\163\171\x6f\x75\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\x74\151\x6e\147\x5f\157\160\164\151\157\x6e\x73\137\163\141\x76\x65\144", [$this, "\x6d\x65\153\x6b\167\x6d\141\143\163\171\x6f\x75\161\x79\165\x6d"]); } public function mekkwmacsyouqyum() { } }
