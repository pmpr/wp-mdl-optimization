<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd253c8f77d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\x72\137\x63\157\155\160\157\156\x65\156\x74\137\143\x68\141\x6e\147\145\144", [$this, "\155\145\153\x6b\167\x6d\x61\143\163\171\x6f\165\x71\x79\165\155"]); $this->waqewsckuayqguos("\163\145\164\164\x69\156\x67\137\157\x70\x74\151\157\156\163\137\x73\x61\x76\145\x64", [$this, "\x6d\x65\x6b\x6b\167\x6d\141\143\163\171\x6f\165\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
