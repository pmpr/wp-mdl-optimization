<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1e5357c62d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\x5f\x63\x6f\x6d\160\157\156\x65\x6e\164\x5f\143\x68\141\156\x67\145\x64", [$this, "\x6d\145\153\x6b\167\x6d\x61\x63\x73\x79\x6f\x75\x71\171\165\x6d"]); $this->waqewsckuayqguos("\x73\x65\164\164\151\x6e\147\137\157\x70\x74\151\157\156\163\137\x73\x61\166\145\144", [$this, "\x6d\x65\153\x6b\167\155\141\143\163\171\x6f\x75\161\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
