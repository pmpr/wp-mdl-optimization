<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31f6c057e7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\137\x63\157\155\x70\x6f\156\x65\x6e\x74\137\x63\150\x61\x6e\147\x65\144", [$this, "\x6d\x65\x6b\x6b\167\x6d\x61\x63\163\171\157\165\x71\171\165\155"]); $this->waqewsckuayqguos("\163\x65\x74\164\x69\x6e\x67\x5f\157\160\x74\x69\157\156\x73\137\163\141\166\145\x64", [$this, "\155\x65\x6b\153\x77\155\141\143\x73\x79\x6f\x75\x71\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
