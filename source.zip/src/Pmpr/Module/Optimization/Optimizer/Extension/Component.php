<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf6837cd4a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\x5f\x63\157\x6d\160\157\x6e\x65\x6e\164\x5f\x63\150\141\x6e\x67\x65\144", [$this, "\155\145\153\153\x77\155\141\x63\x73\x79\157\165\x71\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\x74\x74\x69\156\147\137\x6f\x70\x74\151\x6f\156\163\137\x73\141\x76\145\144", [$this, "\x6d\145\153\x6b\167\x6d\x61\x63\163\x79\x6f\x75\161\x79\165\x6d"]); } public function mekkwmacsyouqyum() { } }
