<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afcef5beb16             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\137\143\x6f\x6d\160\157\x6e\x65\156\164\137\143\x68\141\x6e\147\145\144", [$this, "\x6d\145\x6b\153\x77\x6d\x61\x63\163\x79\157\x75\x71\171\165\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\164\x69\156\x67\137\157\160\164\x69\x6f\x6e\x73\137\x73\141\166\145\x64", [$this, "\155\145\x6b\153\x77\155\x61\143\x73\171\157\165\x71\x79\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\160\165\x72\147\145\x5f\x63\x61\x63\150\145"); } }
