<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e6136ef8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\137\143\157\155\x70\x6f\156\145\156\164\137\x63\150\141\x6e\x67\x65\x64", [$this, "\155\x65\x6b\x6b\167\x6d\x61\143\163\171\157\165\161\x79\165\x6d"]); $this->waqewsckuayqguos("\163\x65\x74\x74\x69\156\147\x5f\x6f\x70\x74\151\157\x6e\163\x5f\163\x61\x76\x65\144", [$this, "\x6d\x65\x6b\153\x77\155\141\x63\163\x79\157\x75\x71\x79\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\x70\x75\x72\147\x65\x5f\x63\x61\x63\150\x65"); } }
