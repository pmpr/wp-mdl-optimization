<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d5dd19f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\143\x6f\155\160\x6f\x6e\145\156\164\x5f\x63\x68\x61\x6e\x67\145\x64", [$this, "\155\x65\153\x6b\167\155\141\143\163\171\157\x75\x71\171\165\x6d"]); $this->waqewsckuayqguos("\x73\x65\x74\x74\151\x6e\147\137\157\160\x74\151\x6f\x6e\163\137\163\141\x76\x65\144", [$this, "\155\x65\153\x6b\x77\155\x61\143\163\x79\x6f\x75\x71\171\165\155"]); } public function mekkwmacsyouqyum() { } }
