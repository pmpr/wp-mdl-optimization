<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a5875d8609d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\x5f\143\x6f\x6d\x70\x6f\156\x65\156\x74\x5f\x63\150\x61\156\x67\x65\x64", [$this, "\155\x65\153\x6b\167\x6d\141\x63\x73\x79\157\x75\161\171\x75\155"]); $this->waqewsckuayqguos("\163\x65\x74\x74\x69\156\x67\x5f\x6f\160\x74\151\157\156\x73\137\163\141\x76\145\x64", [$this, "\155\x65\153\x6b\167\x6d\x61\x63\163\x79\157\165\x71\x79\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\160\x75\162\147\145\137\x63\x61\x63\150\x65"); } }
