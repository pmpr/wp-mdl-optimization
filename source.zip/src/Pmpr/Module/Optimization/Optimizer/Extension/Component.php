<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a6a10b62e31             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\x5f\143\x6f\155\160\x6f\x6e\145\156\x74\137\x63\x68\x61\156\x67\145\144", [$this, "\155\x65\x6b\153\167\x6d\x61\143\x73\x79\157\165\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\163\145\x74\164\151\x6e\147\137\x6f\160\164\151\x6f\x6e\163\x5f\163\x61\x76\x65\x64", [$this, "\155\145\153\x6b\167\x6d\x61\143\x73\x79\x6f\165\161\171\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\x70\165\162\x67\145\137\x63\x61\143\150\145"); } }
