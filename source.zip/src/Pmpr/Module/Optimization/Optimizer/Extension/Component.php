<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22e0b4cda5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\143\x6f\x6d\160\157\x6e\145\x6e\164\137\x63\x68\x61\x6e\147\145\x64", [$this, "\x6d\145\153\153\167\155\141\x63\163\171\157\165\x71\x79\165\155"]); $this->waqewsckuayqguos("\163\x65\164\x74\x69\x6e\147\137\157\160\164\x69\x6f\156\x73\137\163\141\166\145\144", [$this, "\155\145\x6b\x6b\167\x6d\141\x63\x73\171\x6f\165\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
