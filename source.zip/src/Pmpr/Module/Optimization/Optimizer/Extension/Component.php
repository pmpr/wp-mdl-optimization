<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f17f3222             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\137\143\x6f\155\x70\157\x6e\x65\156\164\x5f\143\x68\x61\x6e\147\145\144", [$this, "\x6d\x65\153\153\x77\155\x61\143\163\x79\157\x75\x71\x79\165\155"]); $this->waqewsckuayqguos("\x73\x65\164\x74\x69\156\x67\137\x6f\160\164\x69\x6f\x6e\x73\137\163\141\166\145\144", [$this, "\155\145\153\x6b\167\155\141\x63\x73\171\x6f\165\161\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
