<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b61878830b2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\x5f\143\x6f\155\x70\157\156\145\x6e\164\x5f\x63\x68\141\156\147\145\x64", [$this, "\155\x65\153\153\x77\x6d\141\x63\163\x79\x6f\x75\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\x65\164\164\151\156\147\137\157\x70\164\x69\x6f\x6e\x73\137\163\x61\166\x65\x64", [$this, "\155\145\153\x6b\x77\155\x61\x63\x73\171\x6f\165\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\160\x75\x72\147\145\137\143\x61\x63\x68\x65"); } }
