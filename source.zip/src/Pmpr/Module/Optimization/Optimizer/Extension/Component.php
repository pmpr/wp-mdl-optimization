<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8e1ec93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\143\x6f\x6d\160\157\156\x65\156\164\x5f\x63\x68\x61\x6e\x67\x65\x64", [$this, "\155\x65\x6b\153\x77\155\x61\x63\x73\x79\x6f\165\161\171\165\x6d"]); $this->waqewsckuayqguos("\163\x65\x74\x74\x69\x6e\147\137\157\160\164\151\157\x6e\163\137\163\141\166\145\144", [$this, "\x6d\x65\153\x6b\x77\155\141\143\x73\171\157\165\x71\x79\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\x75\162\147\x65\137\x68\x74\155\x6c\x5f\143\141\x63\x68\145"); } }
