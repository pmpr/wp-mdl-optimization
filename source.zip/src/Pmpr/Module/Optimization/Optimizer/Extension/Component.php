<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758115135c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\143\157\155\x70\157\156\x65\156\164\x5f\x63\x68\141\x6e\147\x65\x64", [$this, "\x6d\x65\153\x6b\167\x6d\141\x63\163\x79\157\165\161\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\164\151\x6e\147\137\x6f\x70\x74\151\157\156\x73\137\163\x61\x76\x65\x64", [$this, "\155\145\153\153\167\x6d\141\143\163\x79\157\165\161\171\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\x65\137\150\x74\x6d\154\137\143\141\x63\150\x65"); } }
