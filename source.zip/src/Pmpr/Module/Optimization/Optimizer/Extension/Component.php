<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357314a443             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\137\x63\157\155\160\157\156\145\156\164\x5f\x63\150\141\156\147\145\144", [$this, "\155\x65\153\x6b\167\x6d\141\143\163\x79\157\x75\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\x6e\x67\x5f\x6f\x70\164\151\x6f\x6e\x73\x5f\x73\x61\166\x65\144", [$this, "\155\145\x6b\153\167\x6d\x61\143\x73\x79\157\x75\x71\171\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\145\137\x68\164\155\154\x5f\x63\x61\x63\x68\145"); } }
