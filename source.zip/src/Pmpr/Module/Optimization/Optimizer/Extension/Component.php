<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22d2c9f327             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\137\x63\x6f\155\160\157\x6e\145\x6e\x74\x5f\x63\150\x61\x6e\147\x65\144", [$this, "\155\145\153\x6b\x77\155\141\x63\163\x79\x6f\165\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\x6e\147\x5f\157\160\x74\x69\157\x6e\163\137\x73\x61\x76\145\144", [$this, "\155\145\x6b\x6b\x77\x6d\141\x63\x73\171\x6f\x75\x71\171\165\155"]); } public function mekkwmacsyouqyum() { } }
