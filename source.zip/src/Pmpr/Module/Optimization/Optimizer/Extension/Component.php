<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d30394ae64b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\143\x6f\x6d\160\157\156\x65\x6e\x74\137\x63\150\141\x6e\147\x65\x64", [$this, "\155\x65\x6b\x6b\x77\155\141\143\x73\x79\x6f\x75\161\171\165\155"]); $this->waqewsckuayqguos("\163\x65\164\x74\151\156\147\137\157\160\x74\x69\x6f\x6e\x73\137\163\141\166\145\144", [$this, "\155\145\x6b\153\x77\155\x61\143\163\171\x6f\165\x71\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
