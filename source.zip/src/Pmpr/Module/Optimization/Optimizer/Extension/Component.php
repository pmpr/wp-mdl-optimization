<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce68cc41878             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\137\x63\x6f\x6d\160\x6f\x6e\x65\x6e\164\x5f\143\150\141\156\x67\x65\144", [$this, "\x6d\x65\153\153\167\x6d\141\x63\x73\171\157\165\161\171\165\155"]); $this->waqewsckuayqguos("\163\145\164\x74\x69\156\x67\x5f\157\x70\164\x69\x6f\156\x73\x5f\x73\141\166\x65\x64", [$this, "\155\x65\x6b\153\x77\155\141\x63\x73\171\157\x75\161\171\165\155"]); } public function mekkwmacsyouqyum() { } }
