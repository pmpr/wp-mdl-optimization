<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22efa3658b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\x5f\x63\x6f\x6d\x70\x6f\x6e\x65\x6e\x74\x5f\x63\150\141\156\147\x65\x64", [$this, "\x6d\145\x6b\153\x77\155\141\x63\163\171\157\165\161\x79\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\164\x69\156\x67\x5f\157\160\x74\151\x6f\x6e\x73\x5f\163\x61\166\145\x64", [$this, "\155\145\153\153\x77\x6d\141\143\x73\171\157\x75\161\171\165\155"]); } public function mekkwmacsyouqyum() { } }
