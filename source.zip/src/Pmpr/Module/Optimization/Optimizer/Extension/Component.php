<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a555dadc1bf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\137\143\x6f\x6d\x70\157\x6e\145\156\x74\x5f\143\150\141\156\147\x65\144", [$this, "\x6d\x65\153\x6b\x77\x6d\141\143\x73\171\x6f\x75\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\163\x65\164\x74\x69\156\147\x5f\x6f\160\x74\x69\157\156\163\x5f\163\141\x76\x65\x64", [$this, "\155\145\x6b\153\167\155\x61\143\163\171\x6f\165\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\160\x75\162\x67\145\137\143\141\x63\x68\145"); } }
