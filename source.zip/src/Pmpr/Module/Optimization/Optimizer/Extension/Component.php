<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6347bb78c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\x5f\143\157\155\160\157\156\x65\x6e\x74\137\143\150\141\x6e\147\x65\x64", [$this, "\155\x65\x6b\153\167\x6d\141\x63\x73\x79\x6f\165\161\171\x75\155"]); $this->waqewsckuayqguos("\163\x65\164\164\x69\x6e\x67\137\157\160\164\151\157\x6e\x73\x5f\x73\141\x76\x65\x64", [$this, "\155\145\153\x6b\x77\155\141\x63\x73\x79\x6f\165\x71\171\165\155"]); } public function mekkwmacsyouqyum() { } }
