<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae90c7cdea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\x5f\143\x6f\155\160\157\156\145\x6e\164\137\143\150\141\156\x67\x65\x64", [$this, "\155\145\x6b\153\x77\155\141\x63\x73\171\x6f\x75\161\171\165\155"]); $this->waqewsckuayqguos("\163\x65\164\164\151\156\147\137\x6f\160\164\x69\x6f\156\163\x5f\163\141\166\145\144", [$this, "\x6d\145\153\153\167\x6d\141\x63\163\171\x6f\x75\x71\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
