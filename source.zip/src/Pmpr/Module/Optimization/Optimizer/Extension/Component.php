<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c4e0adc06c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\x72\x5f\x63\157\155\x70\x6f\x6e\145\x6e\x74\137\143\x68\x61\x6e\147\145\144", [$this, "\155\145\153\x6b\167\155\x61\x63\163\x79\157\165\x71\171\x75\x6d"]); $this->waqewsckuayqguos("\163\x65\164\164\x69\156\x67\x5f\157\160\x74\x69\157\x6e\x73\x5f\x73\x61\x76\145\144", [$this, "\x6d\x65\x6b\153\167\155\141\x63\x73\171\x6f\x75\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { } }
