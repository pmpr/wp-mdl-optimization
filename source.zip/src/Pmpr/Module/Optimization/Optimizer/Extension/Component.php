<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c783a6833             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\x72\137\143\157\155\160\x6f\156\x65\x6e\164\137\143\150\141\156\x67\145\144", [$this, "\155\x65\153\x6b\x77\155\141\x63\x73\171\x6f\165\161\171\x75\155"]); $this->waqewsckuayqguos("\x73\x65\x74\164\151\x6e\147\137\157\160\x74\x69\157\156\163\x5f\x73\141\166\x65\144", [$this, "\x6d\x65\153\x6b\x77\155\x61\x63\163\x79\x6f\165\161\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
