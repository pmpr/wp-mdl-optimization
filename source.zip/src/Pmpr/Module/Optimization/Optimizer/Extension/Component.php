<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5704a7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\x5f\x63\x6f\155\x70\x6f\x6e\x65\156\164\x5f\x63\x68\141\x6e\147\145\144", [$this, "\x6d\x65\153\153\x77\x6d\x61\143\x73\171\157\x75\161\171\165\x6d"]); $this->waqewsckuayqguos("\x73\x65\x74\x74\x69\x6e\147\137\x6f\x70\x74\151\x6f\156\163\137\163\141\x76\x65\144", [$this, "\x6d\x65\x6b\153\x77\155\141\x63\163\x79\157\165\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
