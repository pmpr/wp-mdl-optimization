<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32325cda1b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\x5f\x63\157\155\x70\x6f\x6e\145\x6e\x74\137\143\x68\141\x6e\x67\145\x64", [$this, "\155\x65\153\153\x77\155\141\143\x73\171\157\165\x71\171\x75\155"]); $this->waqewsckuayqguos("\x73\145\x74\x74\x69\156\147\137\157\x70\164\x69\x6f\x6e\x73\x5f\x73\x61\166\x65\x64", [$this, "\155\145\153\153\167\155\141\x63\163\171\157\165\161\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
