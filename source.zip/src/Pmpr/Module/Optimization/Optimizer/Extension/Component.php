<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22bfe246e3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\x5f\x63\157\155\160\157\x6e\145\x6e\164\x5f\143\x68\141\x6e\x67\x65\144", [$this, "\x6d\145\153\153\167\155\141\143\x73\x79\157\165\161\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\x74\x69\156\147\137\x6f\x70\x74\151\x6f\156\163\x5f\x73\141\x76\x65\x64", [$this, "\x6d\145\x6b\153\x77\x6d\141\143\x73\171\x6f\165\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
