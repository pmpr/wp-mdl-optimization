<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d316fa74495             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\x63\x6f\155\160\157\156\145\x6e\164\137\x63\150\141\156\147\145\x64", [$this, "\x6d\145\x6b\x6b\167\155\141\143\163\171\x6f\165\x71\171\165\155"]); $this->waqewsckuayqguos("\x73\x65\164\x74\151\x6e\147\x5f\157\x70\x74\x69\x6f\x6e\x73\137\x73\141\166\x65\144", [$this, "\x6d\x65\153\153\167\x6d\141\x63\163\x79\x6f\165\161\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
