<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b40b3181dac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\162\137\x63\x6f\x6d\160\x6f\156\145\x6e\x74\137\143\x68\x61\156\x67\145\x64", [$this, "\155\145\153\x6b\x77\x6d\x61\x63\x73\171\157\165\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\163\x65\164\x74\x69\x6e\x67\x5f\157\x70\x74\151\x6f\156\163\137\163\141\166\x65\144", [$this, "\155\145\153\x6b\x77\x6d\x61\x63\x73\x79\x6f\165\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\x70\x75\162\147\145\137\143\x61\143\x68\x65"); } }
