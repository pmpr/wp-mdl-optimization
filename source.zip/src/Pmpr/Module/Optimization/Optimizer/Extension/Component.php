<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf88a1c26f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\160\162\x5f\143\157\x6d\x70\x6f\156\145\x6e\164\x5f\x63\150\x61\156\x67\145\144", [$this, "\x6d\145\153\153\167\x6d\141\143\x73\x79\x6f\165\161\171\x75\155"]); $this->waqewsckuayqguos("\x73\145\x74\x74\151\x6e\x67\137\157\160\164\x69\157\156\x73\x5f\x73\x61\x76\145\x64", [$this, "\155\145\x6b\x6b\167\155\141\x63\163\171\157\x75\161\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
