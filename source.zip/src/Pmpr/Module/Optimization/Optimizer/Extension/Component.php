<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a697384             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\162\137\143\x6f\155\160\157\x6e\x65\x6e\164\137\x63\150\141\x6e\x67\145\x64", [$this, "\x6d\x65\153\x6b\167\155\141\x63\x73\x79\157\x75\161\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\164\164\151\156\x67\x5f\x6f\160\x74\x69\157\156\163\x5f\x73\x61\x76\x65\x64", [$this, "\155\x65\153\153\167\x6d\141\x63\163\x79\x6f\165\x71\x79\165\x6d"]); } public function mekkwmacsyouqyum() { } }
