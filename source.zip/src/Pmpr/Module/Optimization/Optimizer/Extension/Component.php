<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd21640c7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\x5f\x63\157\x6d\160\x6f\156\145\156\164\x5f\x63\150\141\x6e\147\145\144", [$this, "\x6d\x65\153\x6b\167\155\x61\143\163\x79\157\x75\x71\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\164\151\156\147\x5f\157\160\164\x69\x6f\156\x73\x5f\x73\x61\166\145\144", [$this, "\x6d\145\x6b\153\x77\155\x61\x63\x73\171\x6f\x75\161\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
