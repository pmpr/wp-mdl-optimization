<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f9435286             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\162\x5f\143\157\x6d\160\157\156\x65\x6e\164\x5f\x63\150\141\156\x67\145\144", [$this, "\x6d\x65\x6b\153\x77\x6d\141\x63\163\171\157\x75\x71\x79\165\155"]); $this->waqewsckuayqguos("\x73\x65\164\x74\151\156\x67\x5f\x6f\x70\164\x69\x6f\156\x73\x5f\x73\x61\166\145\x64", [$this, "\x6d\145\x6b\153\167\155\x61\143\163\x79\157\x75\161\x79\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\x65\x5f\x68\x74\155\x6c\x5f\x63\141\143\x68\x65"); } }
