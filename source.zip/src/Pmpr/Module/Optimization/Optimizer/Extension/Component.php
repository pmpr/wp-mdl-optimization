<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69a35d5c5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\137\x63\x6f\x6d\x70\x6f\x6e\x65\x6e\164\x5f\143\150\141\x6e\147\145\144", [$this, "\155\145\x6b\x6b\167\155\141\143\163\171\x6f\x75\161\171\165\x6d"]); $this->waqewsckuayqguos("\163\145\164\164\x69\x6e\147\137\x6f\160\164\151\x6f\156\x73\x5f\163\141\166\x65\x64", [$this, "\155\145\153\153\167\155\141\143\x73\171\x6f\x75\x71\x79\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\160\165\x72\x67\145\137\143\x61\143\x68\x65"); } }
