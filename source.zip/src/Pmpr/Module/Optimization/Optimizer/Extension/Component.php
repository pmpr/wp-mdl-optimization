<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d240adc3ee3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\137\x63\157\x6d\160\x6f\156\x65\x6e\x74\x5f\143\x68\x61\x6e\147\145\x64", [$this, "\155\x65\153\x6b\167\x6d\141\x63\x73\x79\x6f\x75\x71\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\164\x74\151\x6e\x67\x5f\x6f\160\164\151\157\156\x73\137\x73\141\166\145\144", [$this, "\155\x65\153\153\167\x6d\x61\143\x73\171\157\x75\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { } }
