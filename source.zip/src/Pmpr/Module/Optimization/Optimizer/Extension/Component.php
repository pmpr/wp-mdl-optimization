<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\162\137\143\x6f\x6d\x70\157\x6e\x65\156\x74\x5f\x63\x68\x61\156\x67\x65\x64", [$this, "\x6d\x65\x6b\153\x77\x6d\141\x63\163\x79\157\x75\x71\171\x75\155"]); $this->waqewsckuayqguos("\163\145\x74\x74\151\x6e\x67\137\x6f\160\164\x69\x6f\x6e\163\137\163\141\166\145\144", [$this, "\x6d\x65\x6b\x6b\167\155\141\143\163\x79\157\x75\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
