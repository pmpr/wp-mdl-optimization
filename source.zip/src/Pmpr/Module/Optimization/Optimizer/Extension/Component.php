<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7059178ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\137\143\157\x6d\160\x6f\156\x65\156\x74\137\x63\x68\x61\156\x67\x65\x64", [$this, "\x6d\145\153\x6b\x77\x6d\141\143\163\x79\157\x75\161\171\x75\155"]); $this->waqewsckuayqguos("\163\x65\164\x74\x69\156\x67\137\x6f\x70\164\x69\157\x6e\x73\137\x73\x61\x76\145\144", [$this, "\x6d\145\x6b\153\167\x6d\x61\143\163\171\157\165\161\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
