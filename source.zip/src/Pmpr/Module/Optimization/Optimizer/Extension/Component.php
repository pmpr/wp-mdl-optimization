<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d249276cd51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\x5f\x63\x6f\155\160\x6f\156\x65\x6e\164\x5f\143\150\141\156\147\x65\144", [$this, "\155\145\x6b\153\167\x6d\141\x63\163\171\157\x75\x71\171\x75\155"]); $this->waqewsckuayqguos("\163\145\164\x74\151\x6e\147\x5f\157\160\x74\x69\157\x6e\x73\x5f\x73\141\166\x65\x64", [$this, "\155\145\153\x6b\167\155\x61\x63\x73\171\157\165\161\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
