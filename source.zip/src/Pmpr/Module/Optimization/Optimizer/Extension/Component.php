<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16dc16c38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\x72\x5f\143\157\155\x70\157\156\145\156\x74\x5f\143\x68\x61\x6e\147\x65\144", [$this, "\x6d\x65\153\153\167\155\x61\x63\x73\171\x6f\165\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\164\151\x6e\147\137\157\x70\x74\x69\x6f\x6e\163\x5f\163\141\166\145\144", [$this, "\155\145\153\153\x77\155\x61\143\x73\171\x6f\x75\161\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
