<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4159a97563             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\x5f\143\157\155\x70\157\156\x65\x6e\x74\x5f\x63\x68\141\x6e\147\145\144", [$this, "\x6d\x65\153\x6b\167\155\x61\x63\x73\x79\157\x75\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\164\164\x69\156\147\x5f\157\160\164\x69\x6f\156\163\137\x73\141\x76\x65\x64", [$this, "\155\x65\x6b\153\167\155\141\143\163\x79\x6f\x75\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\160\x75\162\147\x65\x5f\x63\141\x63\150\x65"); } }
