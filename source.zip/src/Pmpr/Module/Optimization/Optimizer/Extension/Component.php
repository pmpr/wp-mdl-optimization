<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2ec2cd5b75             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\x63\x6f\x6d\160\157\156\145\x6e\x74\137\143\150\141\156\x67\x65\x64", [$this, "\x6d\x65\153\x6b\x77\155\x61\x63\163\171\x6f\165\161\x79\165\155"]); $this->waqewsckuayqguos("\163\x65\x74\x74\151\x6e\147\x5f\157\160\164\x69\157\x6e\x73\x5f\x73\141\166\145\144", [$this, "\155\x65\153\x6b\167\155\141\x63\163\x79\157\x75\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
