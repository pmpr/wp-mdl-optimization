<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90c227ba3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\162\x5f\143\x6f\x6d\160\x6f\156\x65\x6e\x74\137\x63\x68\x61\156\x67\x65\144", [$this, "\x6d\145\x6b\153\167\155\x61\143\163\171\157\165\x71\171\165\155"]); $this->waqewsckuayqguos("\163\145\x74\x74\x69\x6e\x67\137\157\160\x74\151\157\x6e\x73\137\163\x61\x76\145\x64", [$this, "\x6d\x65\x6b\153\167\x6d\141\143\x73\x79\x6f\165\161\171\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\x70\165\x72\147\x65\137\x63\141\x63\150\x65"); } }
