<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b5148c02d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\162\137\143\x6f\155\x70\x6f\x6e\x65\156\x74\137\x63\150\x61\x6e\147\145\x64", [$this, "\x6d\145\153\x6b\x77\x6d\141\143\163\171\157\x75\161\x79\165\155"]); $this->waqewsckuayqguos("\163\x65\164\164\x69\x6e\x67\x5f\x6f\x70\x74\x69\157\156\163\x5f\163\141\x76\x65\144", [$this, "\x6d\x65\153\x6b\x77\x6d\141\x63\x73\x79\x6f\x75\161\171\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\145\x5f\x63\x61\143\x68\145"); } }
