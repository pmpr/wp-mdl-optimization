<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69f59378cd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\162\x5f\143\157\155\x70\157\x6e\145\x6e\x74\x5f\x63\150\141\x6e\147\145\144", [$this, "\155\x65\x6b\153\x77\155\x61\x63\163\171\x6f\x75\161\171\165\155"]); $this->waqewsckuayqguos("\163\145\164\164\x69\156\x67\137\157\x70\164\151\157\x6e\163\137\163\141\x76\145\144", [$this, "\155\x65\x6b\153\167\x6d\x61\143\x73\171\x6f\165\161\171\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\x70\165\x72\x67\x65\137\x63\141\143\150\145"); } }
