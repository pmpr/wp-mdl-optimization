<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508f721bbb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\x63\157\x6d\160\157\156\x65\156\x74\137\x63\x68\141\156\x67\x65\x64", [$this, "\x6d\x65\x6b\153\167\x6d\x61\x63\163\x79\x6f\165\161\171\x75\x6d"]); $this->waqewsckuayqguos("\163\x65\164\164\151\156\x67\137\x6f\x70\x74\x69\157\x6e\x73\x5f\x73\141\166\145\x64", [$this, "\x6d\x65\153\153\167\155\x61\x63\x73\x79\157\x75\x71\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
