<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58598b21ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\162\x5f\143\x6f\155\x70\x6f\x6e\145\156\x74\x5f\x63\150\141\156\147\145\144", [$this, "\x6d\145\153\153\x77\x6d\141\143\x73\x79\157\165\161\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\156\x67\x5f\157\160\164\x69\157\156\163\x5f\x73\141\166\x65\x64", [$this, "\x6d\x65\x6b\153\167\155\x61\x63\163\171\x6f\165\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(self::kgswyesggeyekgmg . "\x70\165\162\x67\x65\137\x63\x61\x63\150\x65"); } }
