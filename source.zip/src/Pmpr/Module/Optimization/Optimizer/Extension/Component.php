<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1342843d30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\x5f\143\x6f\155\x70\157\x6e\145\x6e\x74\137\x63\150\x61\156\147\145\x64", [$this, "\155\x65\x6b\x6b\x77\155\x61\143\x73\171\x6f\165\161\x79\165\155"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\x6e\147\137\x6f\x70\164\x69\x6f\156\163\137\163\141\x76\x65\x64", [$this, "\155\x65\x6b\153\167\x6d\141\x63\x73\171\157\165\161\x79\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\162\147\145\137\x63\x61\x63\150\x65"); } }
