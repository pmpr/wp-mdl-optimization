<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c60b0e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\137\x63\x6f\x6d\160\x6f\x6e\145\x6e\164\137\x63\150\141\x6e\147\145\144", [$this, "\155\x65\153\153\167\155\x61\x63\163\x79\157\165\161\171\165\x6d"]); $this->waqewsckuayqguos("\163\x65\x74\x74\151\156\x67\137\157\x70\x74\151\157\x6e\163\x5f\163\x61\166\145\x64", [$this, "\155\x65\x6b\x6b\x77\155\141\x63\x73\x79\157\x75\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\145\137\x68\164\155\154\137\143\141\x63\x68\145"); } }
