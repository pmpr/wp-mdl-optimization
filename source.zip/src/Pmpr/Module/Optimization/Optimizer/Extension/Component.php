<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a869bef5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\x72\x5f\143\157\155\x70\157\x6e\145\x6e\x74\137\x63\x68\x61\156\x67\x65\144", [$this, "\155\145\153\153\167\x6d\141\x63\163\x79\x6f\165\161\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\145\164\164\x69\156\147\x5f\x6f\160\164\151\x6f\x6e\163\137\163\x61\166\x65\x64", [$this, "\x6d\x65\153\153\x77\x6d\141\x63\163\171\x6f\165\x71\x79\x75\155"]); } public function mekkwmacsyouqyum() { } }
