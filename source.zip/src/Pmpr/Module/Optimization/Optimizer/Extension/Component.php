<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31ce4ed382             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\x5f\x63\x6f\155\x70\157\156\x65\156\x74\137\x63\150\x61\x6e\x67\x65\x64", [$this, "\x6d\x65\x6b\x6b\x77\x6d\x61\x63\x73\171\x6f\x75\161\171\x75\155"]); $this->waqewsckuayqguos("\x73\x65\x74\x74\151\156\147\137\157\x70\164\151\157\156\163\x5f\163\x61\x76\x65\x64", [$this, "\155\145\153\x6b\x77\x6d\x61\143\163\171\157\165\x71\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
