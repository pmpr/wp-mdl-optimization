<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4c4bca826             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\x5f\143\x6f\155\x70\157\x6e\145\156\164\137\x63\150\141\x6e\147\145\x64", [$this, "\155\145\153\x6b\x77\155\x61\143\163\171\157\165\x71\x79\165\155"]); $this->waqewsckuayqguos("\x73\x65\164\164\151\x6e\x67\x5f\157\x70\x74\151\x6f\x6e\163\137\x73\x61\166\145\144", [$this, "\155\145\153\x6b\x77\155\x61\143\163\171\157\165\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
