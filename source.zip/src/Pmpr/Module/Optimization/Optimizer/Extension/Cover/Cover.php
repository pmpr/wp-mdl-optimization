<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fc96ddb33             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Cover; use Pmpr\Module\Optimization\Container; class Cover extends Container { public function mameiwsayuyquoeq() { } }
