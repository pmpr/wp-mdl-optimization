<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668b0fe6d179             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Cover; class Cover extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
