<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Cover; class Cover extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
