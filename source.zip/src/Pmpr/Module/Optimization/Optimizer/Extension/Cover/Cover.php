<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6884aa2f148f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Cover; use Pmpr\Module\Optimization\Container; class Cover extends Container { public function mameiwsayuyquoeq() { } }
