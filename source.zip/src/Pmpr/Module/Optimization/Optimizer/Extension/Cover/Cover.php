<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6d38ae4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Cover; class Cover extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
