<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf88a1c26f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimizer\Extension\Cover\Cover; use Pmpr\Module\Optimization\Optimizer\Extension\Module\Module; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Plugin; use Pmpr\Module\Optimization\Optimizer\Extension\Theme\Theme; class Extension extends Common { public function mameiwsayuyquoeq() { Cover::symcgieuakksimmu(); Theme::symcgieuakksimmu(); Module::symcgieuakksimmu(); Plugin::symcgieuakksimmu(); Component::symcgieuakksimmu(); } }
