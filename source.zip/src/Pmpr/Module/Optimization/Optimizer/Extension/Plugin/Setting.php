<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c60b0e8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\Elementor\Setting as ElementorSetting; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\x65\170\164\145\x6e\x73\x69\157\156"; parent::ikcgmcycisiccyuc(); } public function mameiwsayuyquoeq() { ElementorSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\x70\x6c\x75\147\x69\156")->gswweykyogmsyawy(__("\x50\154\x75\147\151\x6e\x73", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)); } }
