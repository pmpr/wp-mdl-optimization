<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a6435d7a95c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\CDN; use Pmpr\Module\Optimization\Container; class CDN extends Container { public function mameiwsayuyquoeq() { } }
