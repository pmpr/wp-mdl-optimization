<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637d2bee1dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Woocommerce; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common; class Woocommerce extends Common { }
