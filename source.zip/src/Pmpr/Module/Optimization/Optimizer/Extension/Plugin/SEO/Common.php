<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c783a6833             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\SEO; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common as BaseClass; abstract class Common extends BaseClass { }
