<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689b42493617             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\SEO; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common as BaseClass; abstract class Common extends BaseClass { }
