<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663503140fc0e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Elementor; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common; class Elementor extends Common { }
