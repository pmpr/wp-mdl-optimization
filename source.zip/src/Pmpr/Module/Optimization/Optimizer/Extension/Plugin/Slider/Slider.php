<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1e5ce2c87e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Slider; class Slider extends Common { public function mameiwsayuyquoeq() { $cekyiayaygawemyq = $this->caokeucsksukesyo()->essaugkeosgskqme(); if (!$cekyiayaygawemyq->ggocakcisguuokai("\162\x65\166\163\x6c\x69\144\145\162\57\x72\145\166\163\154\x69\144\x65\162\x2e\x70\x68\x70")) { goto yqagomygmeoecwey; } SliderRevolution::symcgieuakksimmu(); yqagomygmeoecwey: } }
