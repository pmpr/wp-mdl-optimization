<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5704a7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Slider; class Slider extends Common { public function mameiwsayuyquoeq() { $cekyiayaygawemyq = $this->caokeucsksukesyo()->essaugkeosgskqme(); if (!$cekyiayaygawemyq->ggocakcisguuokai("\162\145\x76\163\154\x69\x64\145\x72\x2f\x72\145\x76\x73\154\x69\144\145\162\56\160\150\x70")) { goto yqagomygmeoecwey; } SliderRevolution::symcgieuakksimmu(); yqagomygmeoecwey: } }
