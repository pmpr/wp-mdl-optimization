<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d316fa74495             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common as BaseClass; abstract class Common extends BaseClass { }
