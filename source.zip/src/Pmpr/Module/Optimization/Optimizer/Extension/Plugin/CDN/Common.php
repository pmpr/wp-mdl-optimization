<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666978e4a7c7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\CDN; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common as BaseClass; abstract class Common extends BaseClass { }
