<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b3f9de7f0df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\CDN; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common as BaseClass; abstract class Common extends BaseClass { }
