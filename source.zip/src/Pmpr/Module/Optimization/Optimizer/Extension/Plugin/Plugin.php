<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637dda1d1856             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; class Plugin extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
