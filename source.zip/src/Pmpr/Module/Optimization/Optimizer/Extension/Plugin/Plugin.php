<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d230b1b85af             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\CDN\CDN; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Ecommerce\Ecommerce; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\I18N\I18N; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\PageBuilder; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\SEO\SEO; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Slider\Slider; class Plugin extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); CDN::symcgieuakksimmu(); SEO::symcgieuakksimmu(); I18N::symcgieuakksimmu(); Slider::symcgieuakksimmu(); Ecommerce::symcgieuakksimmu(); PageBuilder::symcgieuakksimmu(); } }
