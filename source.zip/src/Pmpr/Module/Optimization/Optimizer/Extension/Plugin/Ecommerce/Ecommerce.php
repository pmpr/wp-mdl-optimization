<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29dc7ba6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Ecommerce; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common; class Ecommerce extends Common { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto yqaacqqyisoewkqq; } Woocommerce::symcgieuakksimmu(); yqaacqqyisoewkqq: } }
