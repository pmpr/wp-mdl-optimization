<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a48905c3fc4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML\Preload; use Pmpr\Module\Optimization\Optimizer\Cache\HTML\Common as BaseClass; abstract class Common extends BaseClass { public function oesmaaouikgqagga(string $eeamcawaiqocomwy) : bool { return false; } }
