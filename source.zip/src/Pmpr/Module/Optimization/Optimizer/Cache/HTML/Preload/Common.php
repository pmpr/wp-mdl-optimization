<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML\Preload; use Pmpr\Module\Optimization\Optimizer\Cache\HTML\Common as BaseClass; abstract class Common extends BaseClass { public function oesmaaouikgqagga(string $eeamcawaiqocomwy) : bool { return false; } }
