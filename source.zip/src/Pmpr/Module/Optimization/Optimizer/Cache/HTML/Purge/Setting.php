<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22d2c9f327             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML\Purge; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { public function ikcgmcycisiccyuc() { $this->segment = "\x68\x74\155\x6c\137\x63\x61\143\x68\145"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x70\165\162\x67\145")->gswweykyogmsyawy(__("\120\165\x72\x67\145\40\105\x6c\145\x63\164\x65\144\40\120\x61\x67\145\x27\x73\x20\103\141\x63\x68\145", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::wuyemouocmmciyca)); } }
