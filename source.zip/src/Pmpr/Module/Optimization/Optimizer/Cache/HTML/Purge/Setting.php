<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24a7c00a49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML\Purge; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { public function ikcgmcycisiccyuc() { $this->segment = "\150\x74\155\x6c\x5f\143\x61\143\150\145"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\160\165\162\147\145")->gswweykyogmsyawy(__("\x50\x75\162\147\145\40\105\x6c\x65\x63\164\145\x64\40\120\141\147\x65\47\x73\40\x43\x61\x63\150\x65", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::wuyemouocmmciyca)); } }
