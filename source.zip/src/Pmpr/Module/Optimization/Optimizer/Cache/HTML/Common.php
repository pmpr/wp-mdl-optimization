<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML; use Pmpr\Module\Optimization\Optimizer\Cache\Common as BaseClass; abstract class Common extends BaseClass { public function gusmkkagsgyegacm($eeamcawaiqocomwy) : string { $wkcwykowmmmwioqs = $this->aisuyoiqugewaocg($eeamcawaiqocomwy); return "{$wkcwykowmmmwioqs}\56\x68\x74\x6d\154"; } public function ysuiqkgycmagqqyu(?string $eeamcawaiqocomwy) : bool { return $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk()->exists($this->cckisoakyqqgywey($eeamcawaiqocomwy)); } public function cckisoakyqqgywey($eeamcawaiqocomwy) : string { return "{$this->gskqygiceygcguyo()}\x2f{$this->gusmkkagsgyegacm($eeamcawaiqocomwy)}"; } public function gskqygiceygcguyo() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::ucgeywccqcsggsyw, ''); } public function smemquqkamygequg() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::gyiksueiaeykqaqq, ''); } }
