<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637dda1d1856             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML; use Pmpr\Module\Optimization\Optimizer\Cache\Common as BaseClass; abstract class Common extends BaseClass { public function gusmkkagsgyegacm($eeamcawaiqocomwy) : string { $wkcwykowmmmwioqs = $this->aisuyoiqugewaocg($eeamcawaiqocomwy); return "{$wkcwykowmmmwioqs}\x2e\x68\164\x6d\154"; } public function ysuiqkgycmagqqyu(string $eeamcawaiqocomwy) : bool { return $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk()->exists($this->cckisoakyqqgywey($eeamcawaiqocomwy)); } public function cckisoakyqqgywey($eeamcawaiqocomwy) : string { return "{$this->gskqygiceygcguyo()}\57{$this->gusmkkagsgyegacm($eeamcawaiqocomwy)}"; } public function gskqygiceygcguyo() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::ucgeywccqcsggsyw, ''); } public function smemquqkamygequg() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::gyiksueiaeykqaqq, ''); } }
