<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f17f3222             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Common as BaseClass; abstract class Common extends BaseClass { }
