<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7139a54fa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search; class Search extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
