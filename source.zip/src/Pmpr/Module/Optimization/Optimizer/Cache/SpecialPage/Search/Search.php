<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25d3ac530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search; class Search extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
