<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d5dd19f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\144\166\141\156\x63\x65\x64\x2d\x34\x30\x34\56\x70\150\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\146\x69\x6c\x65\x70\x61\164\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
