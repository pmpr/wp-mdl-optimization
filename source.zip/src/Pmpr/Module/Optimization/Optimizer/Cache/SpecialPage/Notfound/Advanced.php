<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5d8f13cb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\x64\166\141\x6e\143\145\x64\55\x34\x30\64\x2e\160\150\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\x66\151\154\145\160\x61\x74\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
