<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4159a97563             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\x64\x76\x61\x6e\x63\145\144\x2d\x34\60\64\56\x70\x68\x70"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\x66\x69\x6c\145\160\141\x74\150" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
