<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b9397c5c62b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\x61\144\x76\x61\156\x63\x65\x64\x2d\64\60\64\56\160\x68\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\146\151\x6c\x65\x70\x61\164\150" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
