<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7059178ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\x64\x76\x61\x6e\143\145\x64\x2d\64\x30\x34\56\160\150\x70"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(Constants::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\x66\151\154\145\160\x61\x74\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
