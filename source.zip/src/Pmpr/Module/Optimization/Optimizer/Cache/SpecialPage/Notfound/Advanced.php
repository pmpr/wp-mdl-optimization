<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b40b3181dac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\x61\x64\x76\141\x6e\x63\x65\x64\x2d\64\60\64\56\x70\x68\x70"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\x66\x69\154\x65\x70\x61\164\150" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
