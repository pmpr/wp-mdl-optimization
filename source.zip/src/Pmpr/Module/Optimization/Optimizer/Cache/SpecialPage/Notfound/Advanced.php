<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba5a468b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\x61\x64\x76\141\x6e\x63\145\144\55\64\60\x34\56\x70\x68\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::ikimkawumgqsuaaa); } public function gayqqwwuycceosii() : array { return ["\x66\151\154\x65\x70\x61\x74\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
