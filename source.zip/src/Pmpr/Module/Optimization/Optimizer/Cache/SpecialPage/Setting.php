<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fa68d1c92             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search\Setting as SearchSetting; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound\Setting as NotfoundSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { SearchSetting::symcgieuakksimmu(); NotfoundSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\151\x61\x6c\x5f\x70\141\x67\x65\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\143\x69\x61\154\40\x50\x61\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\x72\x63\x68\x2c\40\x34\60\x34\x20\141\156\x64\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
