<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf6837cd4a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\x65\x63\151\141\154\x5f\160\x61\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\x63\151\141\154\x20\120\x61\147\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\162\x63\x68\54\x20\64\60\64\x20\x61\156\144\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
