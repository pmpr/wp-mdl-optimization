<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69ee00a3ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\151\x61\x6c\x5f\160\141\147\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\x63\151\141\154\x20\120\x61\x67\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\141\162\143\150\x2c\40\64\60\x34\40\x61\x6e\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
