<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c10d873e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\x65\x63\x69\141\154\137\160\141\x67\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\x63\x69\141\x6c\40\120\141\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\162\x63\150\x2c\x20\64\60\64\40\141\x6e\144\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
