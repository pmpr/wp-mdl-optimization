<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32f1aa2d0a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\x63\x69\141\154\137\160\141\x67\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\143\151\x61\154\40\120\x61\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\x72\x63\x68\x2c\40\64\60\x34\40\x61\156\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
