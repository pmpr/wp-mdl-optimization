<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79d4da80             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\143\x69\x61\x6c\137\x70\x61\x67\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\145\x63\151\x61\154\x20\120\141\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\162\x63\150\54\40\x34\60\x34\x20\x61\156\x64\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
