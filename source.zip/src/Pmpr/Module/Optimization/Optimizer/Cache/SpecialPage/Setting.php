<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56de52d1c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\x63\x69\141\154\x5f\160\141\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\x65\x63\151\141\154\40\x50\141\147\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\x61\162\143\x68\54\x20\x34\x30\x34\40\x61\156\144\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
