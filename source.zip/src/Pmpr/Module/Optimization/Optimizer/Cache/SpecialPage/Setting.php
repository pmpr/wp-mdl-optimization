<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16a5cc8402             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\x65\143\151\141\154\x5f\160\x61\147\x65\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\x65\143\151\141\x6c\40\x50\141\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\x72\143\150\x2c\40\64\60\x34\40\141\156\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
