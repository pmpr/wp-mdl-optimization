<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69b17b7795             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\x65\143\x69\x61\154\137\x70\141\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\143\151\x61\154\40\x50\x61\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\x61\162\143\x68\54\x20\64\60\64\x20\141\156\144\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
