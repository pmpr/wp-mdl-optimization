<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8e1ec93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search\Setting as SearchSetting; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound\Setting as NotfoundSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { SearchSetting::symcgieuakksimmu(); NotfoundSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\143\151\x61\154\x5f\x70\141\x67\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\151\141\154\40\120\141\x67\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\x61\x72\x63\150\54\40\64\60\64\x20\x61\156\x64\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
