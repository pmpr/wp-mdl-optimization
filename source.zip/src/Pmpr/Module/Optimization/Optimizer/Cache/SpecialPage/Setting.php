<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d249276cd51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\x65\x63\151\141\154\137\x70\x61\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\143\x69\141\154\40\x50\x61\147\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\141\x72\x63\150\x2c\x20\x34\60\x34\x20\141\156\x64\40\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
