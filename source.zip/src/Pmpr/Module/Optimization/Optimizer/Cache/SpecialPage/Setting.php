<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132a7dc622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\x65\x63\151\x61\154\x5f\x70\141\147\x65\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\145\x63\x69\141\x6c\40\x50\x61\x67\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\162\x63\x68\54\x20\64\x30\64\x20\x61\156\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
