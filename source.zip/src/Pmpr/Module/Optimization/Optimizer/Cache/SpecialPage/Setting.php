<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7139a54fa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\143\x69\141\x6c\137\160\141\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\143\x69\x61\154\x20\120\x61\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\x72\x63\150\54\x20\x34\60\64\40\141\156\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
