<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4f986c850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\151\141\x6c\137\160\x61\147\x65\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\145\x63\x69\141\x6c\40\x50\141\x67\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\141\x72\143\x68\x2c\40\64\60\64\x20\141\x6e\x64\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
