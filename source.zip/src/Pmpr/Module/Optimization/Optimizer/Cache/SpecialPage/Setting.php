<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ea6553f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\151\x61\154\137\x70\x61\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\145\x63\x69\141\154\40\x50\141\x67\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\x61\x72\143\x68\54\x20\x34\60\x34\40\141\156\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
