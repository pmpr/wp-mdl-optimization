<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2182256c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\x65\143\151\x61\x6c\137\x70\x61\147\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\x65\143\x69\141\154\40\120\141\x67\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\162\x63\150\54\x20\x34\x30\64\40\x61\x6e\x64\40\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
