<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24006e45d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\143\151\141\x6c\x5f\x70\x61\x67\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\x63\151\141\x6c\x20\x50\141\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\x61\162\143\150\54\40\64\x30\64\x20\x61\x6e\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
