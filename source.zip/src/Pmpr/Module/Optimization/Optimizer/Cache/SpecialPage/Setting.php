<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0900f0e3e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\x63\x69\x61\x6c\x5f\x70\x61\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\x63\x69\x61\x6c\x20\x50\x61\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\162\x63\x68\x2c\x20\64\x30\64\40\141\x6e\144\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
