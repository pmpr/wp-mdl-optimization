<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4181e072c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\x63\151\141\154\x5f\160\141\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\x63\151\141\154\40\120\x61\x67\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\x61\162\143\x68\54\x20\x34\60\x34\40\141\x6e\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
