<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dc2456c625             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Queue; class Process extends Queue { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\166\x69\162\164\165\x61\154\137\x62\x72\x6f\167\163\x65\162"; } public function mkgmgessyuewwswa($cqgoimumaewouews, $sameaqkagyqomooq) : int { $ksaameoqigiaoigg = 0; if ($this->ewgessyekekkocey($sameaqkagyqomooq)) { goto uegouoiuyoqkcscg; } $ksaameoqigiaoigg = $this->ksicwcssyugsigka(time() + (int) $cqgoimumaewouews, self::skcaqcukeyugwmke, [$sameaqkagyqomooq]); uegouoiuyoqkcscg: return $ksaameoqigiaoigg; } public function ewgessyekekkocey($sameaqkagyqomooq) : bool { return $this->exists([self::cmooywkooekaakwk => self::skcaqcukeyugwmke, self::okeuagwgwkmiokac => [$sameaqkagyqomooq], self::ciywsqoeiymemsys => self::sgoswgskyiiwkyuo]); } }
