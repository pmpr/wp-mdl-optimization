<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686a1be47069             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Queue; class Process extends Queue { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\166\x69\162\x74\165\x61\x6c\137\x62\x72\157\x77\x73\x65\x72"; } public function mkgmgessyuewwswa($cqgoimumaewouews, $sameaqkagyqomooq) : int { $ksaameoqigiaoigg = 0; if ($this->ewgessyekekkocey($sameaqkagyqomooq)) { goto wgiygcmqaokywuqa; } $ksaameoqigiaoigg = $this->ksicwcssyugsigka(time() + (int) $cqgoimumaewouews, self::skcaqcukeyugwmke, [$sameaqkagyqomooq]); wgiygcmqaokywuqa: return $ksaameoqigiaoigg; } public function ewgessyekekkocey($sameaqkagyqomooq) : bool { return $this->exists([self::cmooywkooekaakwk => self::skcaqcukeyugwmke, self::okeuagwgwkmiokac => [$sameaqkagyqomooq], self::ciywsqoeiymemsys => self::sgoswgskyiiwkyuo]); } }
