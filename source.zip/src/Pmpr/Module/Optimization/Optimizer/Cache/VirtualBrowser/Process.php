<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668709b77727f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Queue; class Process extends Queue { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\166\151\162\x74\x75\x61\x6c\x5f\142\162\157\x77\163\145\x72"; } public function mkgmgessyuewwswa($cqgoimumaewouews, $sameaqkagyqomooq) : int { $ksaameoqigiaoigg = 0; if ($this->ewgessyekekkocey($sameaqkagyqomooq)) { goto wgiygcmqaokywuqa; } $ksaameoqigiaoigg = $this->ksicwcssyugsigka(time() + (int) $cqgoimumaewouews, self::skcaqcukeyugwmke, [$sameaqkagyqomooq]); wgiygcmqaokywuqa: return $ksaameoqigiaoigg; } public function ewgessyekekkocey($sameaqkagyqomooq) : bool { return $this->exists([self::cmooywkooekaakwk => self::skcaqcukeyugwmke, self::okeuagwgwkmiokac => [$sameaqkagyqomooq], self::ciywsqoeiymemsys => self::sgoswgskyiiwkyuo]); } }
