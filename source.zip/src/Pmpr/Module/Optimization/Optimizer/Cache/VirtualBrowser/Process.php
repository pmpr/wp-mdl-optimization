<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634ff5a86835             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Queue; class Process extends Queue { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\166\x69\x72\164\x75\x61\x6c\137\142\x72\157\167\163\x65\162"; } public function mkgmgessyuewwswa($cqgoimumaewouews, $sameaqkagyqomooq) : int { $ksaameoqigiaoigg = 0; if ($this->ewgessyekekkocey($sameaqkagyqomooq)) { goto auaywaskqooasiuq; } $ksaameoqigiaoigg = $this->ksicwcssyugsigka(time() + (int) $cqgoimumaewouews, self::skcaqcukeyugwmke, [$sameaqkagyqomooq]); auaywaskqooasiuq: return $ksaameoqigiaoigg; } public function ewgessyekekkocey($sameaqkagyqomooq) : bool { return $this->exists([self::cmooywkooekaakwk => self::skcaqcukeyugwmke, self::okeuagwgwkmiokac => [$sameaqkagyqomooq], self::ciywsqoeiymemsys => self::sgoswgskyiiwkyuo]); } }
