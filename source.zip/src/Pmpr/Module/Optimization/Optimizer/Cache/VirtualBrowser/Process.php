<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f091293fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Queue; class Process extends Queue { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x76\x69\162\x74\x75\141\x6c\137\142\x72\157\x77\163\x65\162"; } public function mkgmgessyuewwswa($cqgoimumaewouews, $sameaqkagyqomooq) : int { $ksaameoqigiaoigg = 0; if ($this->ewgessyekekkocey($sameaqkagyqomooq)) { goto wgiygcmqaokywuqa; } $ksaameoqigiaoigg = $this->ksicwcssyugsigka(time() + (int) $cqgoimumaewouews, self::skcaqcukeyugwmke, [$sameaqkagyqomooq]); wgiygcmqaokywuqa: return $ksaameoqigiaoigg; } public function ewgessyekekkocey($sameaqkagyqomooq) : bool { return $this->exists([self::cmooywkooekaakwk => self::skcaqcukeyugwmke, self::okeuagwgwkmiokac => [$sameaqkagyqomooq], self::ciywsqoeiymemsys => self::sgoswgskyiiwkyuo]); } }
