<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba5a468b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser\Purge; use Pmpr\Module\Optimization\Optimizer\Cache\Purge\Purge as BaseClass; class Purge extends BaseClass { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto iauwuugggmegwisk; } Ajax::symcgieuakksimmu(); iauwuugggmegwisk: } public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
