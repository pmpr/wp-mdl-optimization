<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d23d0b3ad57             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser\Purge; use Pmpr\Module\Optimization\Optimizer\Cache\Purge\Purge as BaseClass; class Purge extends BaseClass { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto qccmuwiwykuegoga; } Ajax::symcgieuakksimmu(); qccmuwiwykuegoga: } public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
