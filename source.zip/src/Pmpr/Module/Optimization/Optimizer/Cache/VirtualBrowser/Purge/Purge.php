<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69f59378cd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser\Purge; use Pmpr\Module\Optimization\Optimizer\Cache\Purge\Purge as BaseClass; class Purge extends BaseClass { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto mssaawaiaimogowg; } Ajax::symcgieuakksimmu(); mssaawaiaimogowg: } public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
