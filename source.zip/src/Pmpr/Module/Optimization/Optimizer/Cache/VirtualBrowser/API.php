<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\x6f\160\164\151\x6d\x69\172\141\164\x69\157\156"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\x2f\x61\x64\144\55\152\x6f\x62", [self::kugiewcgiawaeiaq => [self::auqoykcmsiauccao => $eeamcawaiqocomwy, self::aciemiuuwgysykom => $this->eegcqkwceasicmek(), self::myikkigscysoykgy => $ccowyogiqwikkkie]], self::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto uiqycwuommmmuowy; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); uiqycwuommmmuowy: return $sogksuscggsicmac; } }
