<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665872dfe6b03             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\160\164\x69\155\x69\172\141\164\x69\157\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57{$this->gueasuouwqysmomu()}\x2f\141\144\144\55\152\x6f\142", [self::kugiewcgiawaeiaq => [self::auqoykcmsiauccao => $eeamcawaiqocomwy, self::aciemiuuwgysykom => $this->eegcqkwceasicmek(), self::myikkigscysoykgy => $ccowyogiqwikkkie]], self::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto isgwkwacoyimiauk; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); isgwkwacoyimiauk: return $sogksuscggsicmac; } }
