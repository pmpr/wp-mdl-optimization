<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69f59378cd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\x6f\x70\164\x69\155\x69\x7a\x61\164\x69\157\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\57\x61\144\144\55\x6a\157\142", [self::kugiewcgiawaeiaq => [self::auqoykcmsiauccao => $eeamcawaiqocomwy, self::aciemiuuwgysykom => $this->eegcqkwceasicmek(), self::myikkigscysoykgy => $ccowyogiqwikkkie]], self::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto ccyiggckemwgooco; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); ccyiggckemwgooco: return $sogksuscggsicmac; } }
