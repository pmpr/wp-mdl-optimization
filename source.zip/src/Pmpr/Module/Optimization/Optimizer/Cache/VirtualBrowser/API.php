<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dc2456c625             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\x70\164\151\155\x69\x7a\141\164\151\x6f\156"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\57\141\144\x64\x2d\152\157\x62", [self::kugiewcgiawaeiaq => [self::auqoykcmsiauccao => $eeamcawaiqocomwy, self::aciemiuuwgysykom => $this->eegcqkwceasicmek(), self::myikkigscysoykgy => $ccowyogiqwikkkie]], self::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto isgwkwacoyimiauk; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); isgwkwacoyimiauk: return $sogksuscggsicmac; } }
