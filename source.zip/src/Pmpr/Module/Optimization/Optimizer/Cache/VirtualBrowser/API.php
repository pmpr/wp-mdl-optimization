<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4c4bca826             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\x6f\160\x74\151\155\151\172\141\164\151\x6f\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\x2f\141\x64\x64\55\152\x6f\142", [self::kugiewcgiawaeiaq => [Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->eegcqkwceasicmek(), Constants::myikkigscysoykgy => $ccowyogiqwikkkie, "\162\145\x73\157\154\x75\164\151\x6f\x6e\x73" => $umkiakawyaakcsqm]], Constants::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto aqigiwmamkowomiw; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); aqigiwmamkowomiw: return $sogksuscggsicmac; } }
