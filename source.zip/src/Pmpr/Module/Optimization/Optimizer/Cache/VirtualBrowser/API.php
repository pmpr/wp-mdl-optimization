<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819c784426             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; use WP_Error; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\x6f\160\x74\151\155\x69\172\x61\164\x69\157\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\x2f\141\x64\144\55\152\157\142", [self::kugiewcgiawaeiaq => ["\162\145\x73\x6f\154\165\x74\151\x6f\156\x73" => $umkiakawyaakcsqm, Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->caokeucsksukesyo()->cqusmgskowmesgcg()->ooouaomcuuakuaii()]], Constants::mswoacegomcucaik); if (!is_wp_error($sogksuscggsicmac)) { $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); } return $sogksuscggsicmac; } }
