<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663755093ace2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\x6f\x70\x74\151\x6d\x69\172\141\x74\x69\157\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57{$this->gueasuouwqysmomu()}\57\x61\144\x64\55\x6a\157\x62", [self::kugiewcgiawaeiaq => [self::auqoykcmsiauccao => $eeamcawaiqocomwy, self::aciemiuuwgysykom => $this->eegcqkwceasicmek(), self::myikkigscysoykgy => $ccowyogiqwikkkie]], self::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto ekmogkwmcqsykgsq; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue, []); ekmogkwmcqsykgsq: return $sogksuscggsicmac; } }
