<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f091293fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Optimizer\Cache\Common as BaseClass; abstract class Common extends BaseClass { public function gusmkkagsgyegacm($sameaqkagyqomooq) : string { return "{$sameaqkagyqomooq}\56\150\x74\x6d\x6c"; } public function ysuiqkgycmagqqyu($sameaqkagyqomooq) : bool { return $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk()->exists($this->cckisoakyqqgywey($sameaqkagyqomooq)); } public function cckisoakyqqgywey($sameaqkagyqomooq) : string { return "{$this->gskqygiceygcguyo()}\57{$this->gusmkkagsgyegacm($sameaqkagyqomooq)}"; } public function gskqygiceygcguyo() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::cmiuooquqeyoccay, ''); } }
