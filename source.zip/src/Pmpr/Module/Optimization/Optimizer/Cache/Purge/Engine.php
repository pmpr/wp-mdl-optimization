<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1de2caabf8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\Purge; abstract class Engine extends Common { public function caoeosiqwyaauaio(string $mkomwsiykqigmqca) : bool { $miiyyswuessymmwe = $this->caokeucsksukesyo()->iuekyyeesukysksy(); $iiaumsgauuyeqksw = $miiyyswuessymmwe->kcciqwskewsuaemk(); return !$iiaumsgauuyeqksw->exists($mkomwsiykqigmqca) || $iiaumsgauuyeqksw->remove($mkomwsiykqigmqca); } public abstract function gimogqqgyqwiwsmi() : bool; public abstract function qsiwaqwsyasqsqcq(...$ywmkwiwkosakssii) : bool; public abstract function sksuceuccwmiokoe($ccamueccusigaaio) : bool; }
