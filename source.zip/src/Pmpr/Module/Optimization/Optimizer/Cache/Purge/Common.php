<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6888e9a081754             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\Purge; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Traits\HelperTrait; abstract class Common extends Container { use HelperTrait; }
