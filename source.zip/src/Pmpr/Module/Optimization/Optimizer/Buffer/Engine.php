<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b20910f9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; abstract class Engine extends Container { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\142\x75\146\146\145\x72\137\160\x72\x6f\143\x65\x73\x73"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\x2f\74\41\x2d\55\x28\x2e\x2a\51\55\55\x3e\57\125\151\x73", '', $sociqikgoyemqaac); } }
