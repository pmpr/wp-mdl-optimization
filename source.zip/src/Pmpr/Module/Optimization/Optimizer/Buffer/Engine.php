<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758115135c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; abstract class Engine extends Container { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\x62\165\x66\146\145\x72\x5f\x70\162\157\143\x65\x73\163"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\x2f\x3c\x21\55\55\x28\56\x2a\51\x2d\55\x3e\x2f\x55\151\163", '', $sociqikgoyemqaac); } }
