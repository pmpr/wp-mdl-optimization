<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4c57cf814             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Optimizer\Common; abstract class Engine extends Common { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\142\x75\x66\146\145\162\x5f\x70\162\x6f\x63\145\163\x73"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\x2f\74\x21\x2d\55\50\56\52\51\55\55\x3e\x2f\x55\151\163", '', $sociqikgoyemqaac); } }
