<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a869bef5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Optimizer\Common; abstract class Engine extends Common { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\x62\x75\146\146\145\162\x5f\x70\162\x6f\x63\x65\x73\163"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\x2f\74\x21\x2d\x2d\x28\x2e\x2a\51\55\x2d\x3e\57\125\151\x73", '', $sociqikgoyemqaac); } }
