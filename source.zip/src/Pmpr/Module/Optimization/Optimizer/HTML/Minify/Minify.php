<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13791817e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; class Minify extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto wsqoskqgyooqeyga; } HTML::symcgieuakksimmu(); Style::symcgieuakksimmu(); Script::symcgieuakksimmu(); goto uekkkmwciocmosgg; wsqoskqgyooqeyga: Setting::symcgieuakksimmu(); uekkkmwciocmosgg: } }
