<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4c57cf814             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; class Minify extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto egmocemomockemia; } HTML::symcgieuakksimmu(); Style::symcgieuakksimmu(); Script::symcgieuakksimmu(); goto gemwkqocygssmequ; egmocemomockemia: Setting::symcgieuakksimmu(); gemwkqocygssmequ: } }
