<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa800b89726             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; class Minify extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto eymiqwsygoowowuu; } HTML::symcgieuakksimmu(); Style::symcgieuakksimmu(); Script::symcgieuakksimmu(); goto keqagmaiqqsgkmso; eymiqwsygoowowuu: Setting::symcgieuakksimmu(); keqagmaiqqsgkmso: } }
