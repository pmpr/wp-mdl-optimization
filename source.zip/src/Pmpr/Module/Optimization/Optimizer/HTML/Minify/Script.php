<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7059178ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; use Pmpr\Common\Foundation\Interfaces\Constants; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = Constants::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\160\137\141\144\144\137\x69\156\x6c\151\x6e\x65\137\x73\143\x72\x69\160\164\137\144\141\x74\141", [$this, "\x6f\x6b\165\x67\165\x79\x61\143\x67\147\163\x61\147\x65\x71\161"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\163\x63\162\151\160\164"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
