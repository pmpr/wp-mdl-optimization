<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819c784426             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; use Pmpr\Common\Foundation\Interfaces\Constants; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = Constants::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\160\x5f\141\x64\144\137\x69\156\x6c\x69\156\145\137\x73\143\x72\x69\x70\x74\x5f\x64\x61\164\141", [$this, "\x6f\153\165\x67\x75\171\141\x63\147\147\x73\141\147\x65\161\x71"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\x73\143\162\151\x70\x74"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
