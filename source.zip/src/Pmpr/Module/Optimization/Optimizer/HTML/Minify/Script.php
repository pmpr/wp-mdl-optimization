<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ada53dffd1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = self::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x70\x5f\141\x64\x64\137\x69\x6e\154\151\x6e\145\x5f\x73\143\x72\151\x70\x74\x5f\144\141\x74\x61", [$this, "\x6f\x6b\x75\x67\x75\171\x61\143\x67\x67\163\x61\147\145\x71\161"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\163\x63\162\151\160\x74"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
