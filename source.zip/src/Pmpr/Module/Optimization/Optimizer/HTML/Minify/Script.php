<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bec25a4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = self::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x70\x5f\141\x64\x64\x5f\151\x6e\154\151\x6e\145\x5f\x73\143\162\151\x70\164\x5f\144\141\164\141", [$this, "\157\153\165\147\165\x79\141\143\x67\147\x73\x61\147\145\x71\161"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\x73\143\162\x69\160\x74"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
