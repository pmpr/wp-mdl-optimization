<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665f4289276f4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = self::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x70\x5f\141\144\144\x5f\151\156\x6c\x69\156\x65\137\x73\143\x72\151\160\x74\x5f\144\141\x74\141", [$this, "\x6f\x6b\x75\147\x75\171\x61\x63\147\147\x73\141\147\x65\161\x71"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\163\143\x72\151\x70\164"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
