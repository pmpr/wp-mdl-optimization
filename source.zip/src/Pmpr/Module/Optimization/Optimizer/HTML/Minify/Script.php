<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668aef2e0bbf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = self::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\160\137\x61\x64\144\x5f\x69\x6e\x6c\x69\x6e\145\137\x73\143\162\151\x70\x74\x5f\144\141\x74\x61", [$this, "\157\x6b\x75\147\165\171\141\143\147\x67\x73\141\147\145\161\x71"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\163\x63\162\x69\x70\x74"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
