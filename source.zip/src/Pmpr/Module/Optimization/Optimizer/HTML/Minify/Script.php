<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1de2caabf8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; use Pmpr\Common\Foundation\Interfaces\Constants; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = Constants::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\160\137\x61\144\144\x5f\151\x6e\154\x69\156\x65\x5f\x73\143\162\151\x70\164\x5f\x64\x61\164\141", [$this, "\157\153\165\147\165\171\x61\x63\x67\x67\x73\141\x67\145\161\x71"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\x73\x63\162\151\160\x74"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
