<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66369e99bb80d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = self::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\160\137\x61\x64\x64\x5f\x69\x6e\154\x69\156\145\x5f\x73\143\x72\151\160\164\x5f\x64\141\x74\x61", [$this, "\x6f\153\165\x67\x75\x79\x61\143\x67\147\163\x61\147\145\x71\x71"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\x73\x63\x72\151\x70\164"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
