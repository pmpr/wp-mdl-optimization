<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aeb001123c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\124\x4d\x4c\x20\x4d\x61\156\141\x67\x65\155\145\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\x61\x6e\165\x70\x2c\x20\115\151\156\x69\146\x79\40\x61\156\x64\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
