<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f163107a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\x4d\x4c\x20\x4d\141\156\x61\x67\x65\155\x65\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\141\156\165\160\54\x20\x4d\151\156\151\146\171\40\141\156\144\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
