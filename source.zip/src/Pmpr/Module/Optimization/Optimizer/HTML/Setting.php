<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb243a19822             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\x4d\x4c\40\115\x61\156\141\147\145\x6d\145\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\x65\x61\x6e\x75\x70\54\x20\x4d\151\156\x69\146\x79\x20\141\156\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
