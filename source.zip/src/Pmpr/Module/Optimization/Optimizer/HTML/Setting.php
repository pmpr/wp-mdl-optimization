<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2ce1dff84             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\x54\x4d\x4c\x20\x4d\x61\x6e\141\x67\x65\x6d\x65\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\x65\x61\x6e\165\160\54\x20\x4d\151\x6e\x69\x66\171\x20\x61\x6e\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
