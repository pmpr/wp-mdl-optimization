<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a608b965f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\115\x4c\x20\115\x61\x6e\x61\x67\145\155\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\145\141\x6e\x75\x70\54\x20\115\x69\x6e\151\146\x79\x20\x61\156\x64\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
