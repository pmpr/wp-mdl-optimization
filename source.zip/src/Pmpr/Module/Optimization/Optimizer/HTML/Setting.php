<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f091293fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\x4d\114\x20\115\141\x6e\141\147\x65\155\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\145\x61\156\x75\160\x2c\x20\x4d\151\x6e\x69\146\171\40\141\x6e\x64\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
