<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69ee00a3ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\115\114\x20\115\141\156\141\x67\x65\155\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\x61\x6e\x75\160\54\40\x4d\x69\156\x69\146\171\x20\141\x6e\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
