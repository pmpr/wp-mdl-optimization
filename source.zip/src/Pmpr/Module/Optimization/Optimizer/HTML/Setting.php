<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\115\114\40\115\141\156\141\147\145\x6d\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\141\156\x75\x70\x2c\40\x4d\151\156\x69\x66\x79\40\141\156\144\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
