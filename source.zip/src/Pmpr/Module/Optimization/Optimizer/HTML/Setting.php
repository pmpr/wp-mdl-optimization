<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d83d7f69c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\x54\115\114\x20\x4d\141\x6e\x61\147\145\155\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\x61\x6e\x75\160\54\x20\x4d\x69\156\x69\146\x79\x20\x61\x6e\144\x20\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
