<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dd893c52c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\124\115\x4c\40\x4d\x61\x6e\x61\x67\145\155\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\141\x6e\165\x70\x2c\40\115\x69\x6e\151\x66\171\40\x61\156\x64\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
