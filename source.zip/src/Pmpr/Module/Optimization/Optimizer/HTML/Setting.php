<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afa619aaca2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\x54\115\x4c\x20\x4d\x61\x6e\141\x67\145\155\x65\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\x65\141\x6e\165\x70\54\x20\115\151\x6e\151\x66\x79\40\141\156\x64\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
