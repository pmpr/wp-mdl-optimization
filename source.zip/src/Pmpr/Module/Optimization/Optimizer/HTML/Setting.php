<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663698627f721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\115\114\x20\x4d\141\156\141\x67\x65\155\145\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\141\156\165\x70\x2c\x20\115\151\156\151\x66\171\40\x61\156\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
