<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687508050272             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\x4d\114\40\x4d\141\156\x61\x67\x65\155\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\145\x61\x6e\165\160\54\40\115\x69\156\151\146\x79\40\x61\156\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
