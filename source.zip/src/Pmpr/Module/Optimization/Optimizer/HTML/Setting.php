<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af79314d69             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\x4d\x4c\40\x4d\141\x6e\x61\147\145\155\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\141\156\165\x70\x2c\40\115\x69\x6e\x69\x66\x79\40\141\x6e\x64\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
