<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2db183c14             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\115\114\40\x4d\x61\156\141\x67\x65\x6d\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\141\156\165\160\x2c\40\x4d\151\x6e\x69\146\x79\x20\141\x6e\144\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
