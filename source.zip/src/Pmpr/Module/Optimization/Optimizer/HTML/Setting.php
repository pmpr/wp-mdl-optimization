<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668709b77727f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\115\114\x20\x4d\141\156\141\147\x65\x6d\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\x61\156\165\160\x2c\40\x4d\x69\x6e\x69\x66\171\40\x61\156\x64\40\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
