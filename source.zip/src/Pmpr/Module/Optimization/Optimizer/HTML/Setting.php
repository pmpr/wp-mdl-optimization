<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8b6b9a73             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\x4d\x4c\40\115\141\156\x61\x67\145\155\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\x65\141\x6e\165\160\54\40\115\151\156\151\x66\x79\40\141\x6e\x64\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
