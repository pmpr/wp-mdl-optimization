<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c5745b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\x4d\x4c\x20\x4d\141\x6e\141\147\145\155\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\x61\x6e\165\x70\54\40\x4d\x69\156\151\146\171\x20\141\156\144\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
