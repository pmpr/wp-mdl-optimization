<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\124\x4d\x4c\40\x4d\x61\156\141\147\145\x6d\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\141\x6e\x75\160\x2c\40\115\151\156\x69\146\171\40\141\156\144\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
