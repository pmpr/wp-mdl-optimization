<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66369e99bb80d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\x4d\x4c\40\x4d\141\156\141\147\x65\x6d\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\x65\x61\x6e\x75\x70\x2c\40\115\151\x6e\x69\146\171\x20\141\156\x64\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
