<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1de2caabf8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\124\115\x4c\40\x4d\141\x6e\141\147\145\x6d\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\145\x61\x6e\x75\160\54\x20\115\x69\156\151\146\x79\40\141\x6e\x64\x20\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
