<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af54c961e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\x4d\x4c\40\x4d\x61\156\141\147\145\x6d\x65\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\141\x6e\x75\160\54\40\x4d\151\156\x69\x66\x79\x20\141\156\x64\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
