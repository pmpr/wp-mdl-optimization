<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a54fbc54301             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\124\115\114\x20\115\141\x6e\x61\x67\145\155\x65\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\x61\x6e\x75\160\54\x20\115\x69\156\x69\146\171\40\x61\156\x64\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
