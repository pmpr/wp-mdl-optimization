<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4f986c850             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\x4d\x4c\40\x4d\141\x6e\141\147\145\x6d\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\141\156\165\160\x2c\x20\x4d\151\x6e\151\x66\171\x20\141\156\x64\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
