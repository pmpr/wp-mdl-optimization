<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec4797d504             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\115\x4c\x20\115\x61\x6e\x61\147\x65\155\145\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\x61\x6e\x75\x70\x2c\x20\x4d\151\x6e\x69\x66\x79\40\x61\156\x64\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
