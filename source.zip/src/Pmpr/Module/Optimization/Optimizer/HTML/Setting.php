<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6d38ae4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\x4d\x4c\x20\115\141\x6e\x61\147\145\x6d\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\x65\141\156\x75\160\54\40\x4d\151\156\x69\x66\171\x20\x61\x6e\x64\x20\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
