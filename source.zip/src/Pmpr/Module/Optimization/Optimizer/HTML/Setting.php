<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2182256c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\x4d\x4c\40\x4d\141\156\141\x67\145\x6d\x65\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\x61\x6e\x75\x70\x2c\40\x4d\151\x6e\151\146\171\40\141\156\x64\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
