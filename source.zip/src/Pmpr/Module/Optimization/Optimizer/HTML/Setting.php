<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\124\115\x4c\40\x4d\141\x6e\x61\x67\145\155\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\x65\141\x6e\165\160\54\40\115\151\156\151\x66\x79\x20\x61\x6e\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
