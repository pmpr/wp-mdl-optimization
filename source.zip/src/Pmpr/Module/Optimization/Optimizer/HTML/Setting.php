<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\x54\115\114\x20\115\x61\x6e\x61\x67\x65\155\x65\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\145\x61\x6e\165\x70\x2c\x20\x4d\151\x6e\151\146\171\40\x61\156\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
