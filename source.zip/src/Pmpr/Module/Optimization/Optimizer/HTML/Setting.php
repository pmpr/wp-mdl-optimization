<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d3aa9dad2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\115\x4c\x20\115\x61\x6e\x61\147\x65\x6d\x65\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\x61\156\165\x70\x2c\x20\x4d\151\156\151\x66\x79\40\x61\156\144\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
