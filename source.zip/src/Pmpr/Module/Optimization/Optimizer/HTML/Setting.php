<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ea6553f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\115\x4c\40\x4d\141\x6e\x61\x67\x65\155\x65\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\145\x61\156\165\160\54\40\115\x69\156\151\146\171\x20\141\x6e\x64\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
