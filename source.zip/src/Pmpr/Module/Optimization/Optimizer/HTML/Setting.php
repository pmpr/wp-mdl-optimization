<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663757b0e9f86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\115\x4c\40\115\141\156\141\x67\145\x6d\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\x65\x61\x6e\165\160\54\40\x4d\151\156\151\146\x79\40\141\156\x64\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
