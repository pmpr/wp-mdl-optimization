<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668664c7535d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\x4d\114\40\115\x61\156\141\147\145\x6d\145\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\x65\x61\x6e\x75\x70\54\40\x4d\151\x6e\151\146\x79\x20\141\156\x64\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
