<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4c4bca826             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\x4d\114\x20\x4d\x61\x6e\141\x67\145\155\x65\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\141\156\165\160\54\40\115\x69\156\x69\x66\x79\x20\x61\x6e\x64\x20\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
