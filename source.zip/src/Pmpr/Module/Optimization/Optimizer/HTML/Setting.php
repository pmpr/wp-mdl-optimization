<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635076d1df7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\x48\124\115\114\x20\x4d\141\x6e\x61\x67\x65\x6d\145\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\141\156\x75\x70\x2c\x20\115\x69\156\151\146\171\40\141\x6e\144\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
