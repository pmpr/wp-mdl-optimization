<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada83915b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\x54\115\114\x20\x4d\x61\156\x61\x67\145\155\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\x65\x61\x6e\x75\x70\x2c\x20\x4d\x69\x6e\151\146\171\x20\141\156\144\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
