<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce68cc41878             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\x4d\114\x20\x4d\141\156\x61\147\x65\155\145\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\x65\141\x6e\165\x70\54\x20\115\x69\156\x69\146\171\40\x61\156\x64\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
