<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58598b21ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\115\x4c\40\x4d\x61\x6e\x61\x67\x65\155\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\145\141\156\x75\160\x2c\x20\x4d\151\x6e\151\146\x79\40\x61\x6e\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
