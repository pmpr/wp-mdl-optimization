<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24006e45d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\x4d\114\x20\x4d\141\156\141\147\145\x6d\x65\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\145\x61\156\x75\x70\54\40\115\151\156\151\x66\x79\x20\x61\156\144\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
