<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d5dd19f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\x4d\x4c\40\x4d\141\156\141\x67\x65\x6d\145\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\x61\x6e\x75\160\x2c\40\115\151\156\x69\146\x79\40\141\x6e\x64\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
