<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec8032739             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\x54\115\x4c\40\x4d\x61\156\x61\x67\x65\155\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\141\x6e\165\160\54\40\115\x69\156\151\x66\x79\x20\x61\156\144\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
