<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668724cd3b441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(self::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::ycwuwkomomgswcgg)->gswweykyogmsyawy(__("\110\124\115\x4c\x20\115\141\156\x61\147\x65\155\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\141\156\165\x70\x2c\40\x4d\151\156\x69\146\171\40\x61\156\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
