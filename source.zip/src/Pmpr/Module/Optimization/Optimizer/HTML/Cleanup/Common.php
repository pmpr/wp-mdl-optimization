<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24a7c00a49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; use Pmpr\Module\Optimization\Optimizer\HTML\Common as BaseClass; abstract class Common extends BaseClass { }
