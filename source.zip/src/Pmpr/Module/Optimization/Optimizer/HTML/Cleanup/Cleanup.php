<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec0900f0e3e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; class Cleanup extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ossyqogewmggmaoc; } Engine::symcgieuakksimmu(); goto ggkoiouwecyiosym; ossyqogewmggmaoc: Setting::symcgieuakksimmu(); ggkoiouwecyiosym: } }
