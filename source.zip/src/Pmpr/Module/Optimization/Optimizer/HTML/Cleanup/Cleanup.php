<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4e02be33a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; class Cleanup extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ossyqogewmggmaoc; } Engine::symcgieuakksimmu(); goto ggkoiouwecyiosym; ossyqogewmggmaoc: Setting::symcgieuakksimmu(); ggkoiouwecyiosym: } }
