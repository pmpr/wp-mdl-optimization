<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5e4c040             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; class Cleanup extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ikeyoyoigsuouokm; } Engine::symcgieuakksimmu(); goto eecgougegqassgyq; ikeyoyoigsuouokm: Setting::symcgieuakksimmu(); eecgougegqassgyq: } }
