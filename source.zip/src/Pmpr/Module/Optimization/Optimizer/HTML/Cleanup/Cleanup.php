<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f43f6aa4f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; class Cleanup extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
