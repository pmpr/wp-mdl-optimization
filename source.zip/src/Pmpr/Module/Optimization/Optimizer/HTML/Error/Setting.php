<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e1693fe2664             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Error; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const iymiuemmsoemggic = 'console_error_'; const qoyskaoaaakosmaq = self::iymiuemmsoemggic . 'add_blank_favicon'; public function ikcgmcycisiccyuc() { $this->segment = Constants::gsqoooskigukokks; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam('errors')->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__('Errors', PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__('Solving problems that can have a negative effect on the performance of your site.', PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::uiqeguumaekoqoeo)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::qoyskaoaaakosmaq)->gswweykyogmsyawy(__('Add Blank Favicon', PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__('If your site dont have a favicon, this option add a blank favicon to header to prevent Missing Favicon or 404 error.', PR__MDL__OPTIMIZATION)))); } }
