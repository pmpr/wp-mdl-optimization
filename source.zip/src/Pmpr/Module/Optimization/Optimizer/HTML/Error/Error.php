<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d240adc3ee3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Error; class Error extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
