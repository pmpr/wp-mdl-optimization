<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4181e072c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Error; use Pmpr\Module\Optimization\Optimizer\HTML\Common as BaseClass; abstract class Common extends BaseClass { }
