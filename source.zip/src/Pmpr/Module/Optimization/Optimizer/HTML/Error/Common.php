<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708194f632             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Error; use Pmpr\Module\Optimization\Optimizer\HTML\Common as BaseClass; abstract class Common extends BaseClass { }
