<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22e0b4cda5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto usyckeewsgwaysam; } Engine::symcgieuakksimmu(); usyckeewsgwaysam: if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto gicuuwuuuwumyooa; } Setting::symcgieuakksimmu(); gicuuwuuuwumyooa: } }
