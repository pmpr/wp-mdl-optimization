<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1e5ce2c87e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto mkgmaguyswskyioa; } Engine::symcgieuakksimmu(); mkgmaguyswskyioa: if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto skwusmoyomgqkimm; } Setting::symcgieuakksimmu(); skwusmoyomgqkimm: } }
