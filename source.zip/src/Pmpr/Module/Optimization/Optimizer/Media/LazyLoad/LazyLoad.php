<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668709b77727f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto icumkkykaoqycqqu; } Engine::symcgieuakksimmu(); icumkkykaoqycqqu: Setting::symcgieuakksimmu(); } }
