<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24a7c00a49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto ismeikacqqyqcmqe; } Engine::symcgieuakksimmu(); ismeikacqqyqcmqe: if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto qsokkkyoackoycie; } Setting::symcgieuakksimmu(); qsokkkyoackoycie: } }
