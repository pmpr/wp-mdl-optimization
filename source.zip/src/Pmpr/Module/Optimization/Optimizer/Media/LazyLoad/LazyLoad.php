<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69b17b7795             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto gooqkmwgsmseuiwq; } Engine::symcgieuakksimmu(); gooqkmwgsmseuiwq: Setting::symcgieuakksimmu(); } }
