<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf8fcabf8fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto awaqksikyomsuaeo; } Engine::symcgieuakksimmu(); awaqksikyomsuaeo: if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto cuommomwmsackoqc; } Setting::symcgieuakksimmu(); cuommomwmsackoqc: } }
