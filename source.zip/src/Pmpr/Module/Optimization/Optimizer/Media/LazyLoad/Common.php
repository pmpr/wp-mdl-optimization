<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; use Pmpr\Module\Optimization\Optimizer\Media\Common as BaseClass; abstract class Common extends BaseClass { }
