<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29dc7ba6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; use Pmpr\Module\Optimization\Optimizer\Media\Common as BaseClass; abstract class Common extends BaseClass { }
