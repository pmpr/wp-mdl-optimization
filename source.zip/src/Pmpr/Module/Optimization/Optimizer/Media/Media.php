<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d316fa74495             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Module\Optimization\Optimizer\Media\ImageDimension\ImageDimension; use Pmpr\Module\Optimization\Optimizer\Media\LazyLoad\LazyLoad; class Media extends Common { public function mameiwsayuyquoeq() { ImageDimension::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto yqcusaeysomccaok; } Setting::symcgieuakksimmu(); yqcusaeysomccaok: } }
