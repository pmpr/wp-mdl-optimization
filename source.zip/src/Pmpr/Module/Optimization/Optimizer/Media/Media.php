<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b26fd5a00e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimizer\Media\ImageDimension\ImageDimension; use Pmpr\Module\Optimization\Optimizer\Media\LazyLoad\LazyLoad; use Pmpr\Module\Optimization\Optimizer\Media\LazyLoad\Setting as LazyLoadSetting; use Pmpr\Module\Optimization\Optimizer\Media\ImageDimension\Setting as ImageDimensionSetting; class Media extends Container { public function mameiwsayuyquoeq() { if ($this->weysguygiseoukqw(LazyLoadSetting::owqmaigscwikmwgg)) { LazyLoad::symcgieuakksimmu(); } if ($this->weysguygiseoukqw(ImageDimensionSetting::issekcywqmgcacqc)) { ImageDimension::symcgieuakksimmu(); } } }
