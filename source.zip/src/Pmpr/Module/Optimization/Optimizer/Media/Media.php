<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4159a97563             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Module\Optimization\Optimizer\Media\ImageDimension\ImageDimension; use Pmpr\Module\Optimization\Optimizer\Media\LazyLoad\LazyLoad; class Media extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); LazyLoad::symcgieuakksimmu(); ImageDimension::symcgieuakksimmu(); } }
