<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\171\x5f\x6c\157\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\x61\155\145\x5f\141\156\144\137\x76\151\144\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\155\x69\172\x65\x20\x69\155\141\x67\145\x2c\40\166\151\144\x65\x20\141\156\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
