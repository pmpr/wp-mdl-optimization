<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd253c8f77d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\x7a\x79\137\x6c\157\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\x6d\145\x5f\141\156\x64\x5f\166\x69\144\145\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\151\155\151\x7a\145\x20\x69\x6d\141\x67\145\x2c\40\166\x69\144\145\40\141\x6e\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
