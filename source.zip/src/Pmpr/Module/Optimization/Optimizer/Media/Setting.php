<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6654cb65a9906             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\172\171\x5f\x6c\x6f\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\141\155\145\x5f\x61\x6e\x64\137\x76\151\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\151\155\x69\x7a\145\40\151\x6d\141\x67\145\54\40\166\x69\x64\x65\x20\141\156\x64\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
