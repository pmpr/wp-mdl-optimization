<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a6a10b62e31             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\171\x5f\x6c\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\141\x6d\145\137\141\156\x64\x5f\166\x69\144\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\151\155\x69\172\x65\x20\151\155\141\x67\x65\54\x20\x76\x69\x64\145\40\141\156\x64\40\56\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
