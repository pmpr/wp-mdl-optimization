<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1de2caabf8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\171\x5f\154\157\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\x61\155\x65\x5f\141\156\x64\137\x76\151\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\151\155\151\x7a\x65\x20\151\x6d\141\147\145\x2c\x20\x76\151\144\145\40\x61\x6e\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
