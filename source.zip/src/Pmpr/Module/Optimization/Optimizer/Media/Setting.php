<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd21640c7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\171\x5f\154\157\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\141\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\x61\x6d\x65\137\x61\156\144\x5f\x76\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\151\155\151\x7a\x65\40\151\x6d\141\147\x65\54\x20\166\151\x64\x65\40\141\x6e\x64\40\56\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
