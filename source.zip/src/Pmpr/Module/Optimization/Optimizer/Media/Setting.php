<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a697384             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\x79\137\x6c\157\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\141\155\x65\137\141\156\144\x5f\166\151\144\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\164\x69\155\151\x7a\x65\x20\x69\155\141\147\x65\54\x20\166\151\x64\x65\40\x61\156\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
