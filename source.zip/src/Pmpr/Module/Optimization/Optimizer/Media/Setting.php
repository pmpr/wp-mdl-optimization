<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15ea6553f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\x79\x5f\154\157\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\155\x65\x5f\141\x6e\144\x5f\x76\151\x64\x65\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\x6d\x69\172\145\40\x69\155\x61\147\x65\x2c\x20\x76\x69\144\x65\x20\141\x6e\x64\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
