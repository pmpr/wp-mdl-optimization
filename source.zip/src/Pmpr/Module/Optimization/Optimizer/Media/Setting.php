<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665afacdd5cec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\x79\137\154\x6f\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\x61\x6d\145\137\x61\156\x64\137\166\x69\x64\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\151\x6d\x69\x7a\x65\40\151\155\x61\147\145\x2c\40\166\151\144\145\x20\141\156\144\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
