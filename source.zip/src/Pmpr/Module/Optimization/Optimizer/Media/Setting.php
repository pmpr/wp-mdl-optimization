<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5e4c040             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\171\x5f\154\x6f\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\x61\155\x65\x5f\141\156\x64\137\166\151\x64\x65\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\x69\x6d\x69\x7a\x65\x20\x69\x6d\141\147\145\54\40\x76\151\144\x65\40\141\x6e\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
