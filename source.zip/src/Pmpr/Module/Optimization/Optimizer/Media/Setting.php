<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2182256c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\x7a\x79\x5f\x6c\157\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\x72\x61\155\x65\137\x61\x6e\144\137\166\x69\x64\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\151\155\151\172\145\x20\151\155\141\x67\x65\x2c\x20\166\x69\144\145\40\x61\x6e\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
