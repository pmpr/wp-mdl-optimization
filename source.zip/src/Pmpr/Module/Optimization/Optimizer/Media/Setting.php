<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66872493a1a65             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\x79\137\154\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\141\155\145\x5f\141\x6e\x64\137\x76\151\x64\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\151\x6d\x69\x7a\x65\40\151\x6d\141\147\x65\54\40\x76\151\144\145\x20\x61\x6e\144\x20\56\x2e\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
