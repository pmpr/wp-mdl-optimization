<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a555dadc1bf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\151\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\137\154\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\x6d\x65\137\x61\156\x64\137\166\151\144\x65\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\155\x69\x7a\145\40\x69\x6d\141\147\x65\54\x20\x76\151\x64\x65\x20\x61\x6e\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
