<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668b0fe6d179             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\144\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\x79\137\154\157\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\141\155\x65\x5f\141\x6e\x64\137\x76\x69\144\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\164\x69\155\x69\x7a\145\x20\x69\x6d\x61\147\x65\54\x20\x76\x69\144\145\x20\141\x6e\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
