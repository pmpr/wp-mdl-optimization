<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2e8b4802f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\x7a\171\x5f\154\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\141\x67\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\155\145\137\x61\x6e\x64\137\166\x69\144\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\164\x69\x6d\151\x7a\145\x20\x69\x6d\141\x67\x65\54\40\x76\151\144\x65\x20\141\x6e\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
