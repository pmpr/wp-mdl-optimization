<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69a35d5c5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\x79\137\x6c\157\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\x61\x6d\x65\137\x61\x6e\144\137\166\151\x64\x65\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\155\x69\x7a\145\40\151\x6d\x61\147\145\x2c\x20\166\x69\144\x65\x20\141\156\x64\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
