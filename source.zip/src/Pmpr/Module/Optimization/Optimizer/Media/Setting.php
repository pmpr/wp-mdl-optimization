<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708194f632             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\171\x5f\x6c\157\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\141\x6d\145\137\x61\x6e\144\137\166\x69\x64\145\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\x6d\151\x7a\145\x20\151\155\141\x67\145\54\x20\x76\x69\144\145\x20\141\156\x64\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
