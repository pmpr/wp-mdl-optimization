<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f17f3222             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\x79\137\154\x6f\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\141\x6d\145\x5f\x61\156\144\x5f\x76\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\151\x6d\151\x7a\x65\40\151\x6d\x61\147\145\54\40\x76\x69\x64\145\40\x61\156\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
