<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689b42493617             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\x7a\x79\x5f\x6c\157\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\x61\x6d\x65\137\x61\x6e\144\x5f\166\x69\144\x65\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\x6d\151\x7a\x65\x20\x69\x6d\x61\147\x65\54\40\x76\151\x64\145\x20\141\x6e\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
