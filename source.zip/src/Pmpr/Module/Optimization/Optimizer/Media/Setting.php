<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16dc16c38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\x7a\x79\x5f\154\157\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\x61\155\x65\137\x61\x6e\144\x5f\166\151\x64\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\x69\155\x69\x7a\145\x20\x69\x6d\141\147\x65\54\40\x76\151\x64\x65\40\141\156\144\40\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
