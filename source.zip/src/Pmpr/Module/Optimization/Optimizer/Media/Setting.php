<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d240adc3ee3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\137\154\157\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\x61\x6d\x65\137\141\x6e\x64\x5f\166\x69\144\145\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\151\x6d\151\172\x65\x20\151\155\141\x67\145\x2c\40\166\151\x64\145\40\141\x6e\x64\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
