<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686866696d41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\x7a\x79\137\x6c\x6f\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\x6d\145\x5f\x61\x6e\144\x5f\166\151\x64\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\x64\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\144\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\155\151\x7a\x65\x20\x69\x6d\141\147\x65\x2c\x20\166\151\x64\145\40\141\156\144\40\56\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
