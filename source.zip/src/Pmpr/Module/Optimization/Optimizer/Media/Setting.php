<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4c4bca826             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\x79\x5f\154\157\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\x72\x61\155\x65\137\x61\156\144\137\166\151\x64\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\x69\x6d\151\172\145\40\x69\155\141\x67\x65\x2c\40\x76\x69\144\x65\40\x61\156\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
