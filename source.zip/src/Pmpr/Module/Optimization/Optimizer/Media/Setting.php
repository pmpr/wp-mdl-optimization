<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af1935df9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\x79\x5f\154\157\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\141\x6d\x65\137\141\156\x64\137\166\151\x64\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\151\x6d\x69\172\145\40\151\155\x61\147\x65\x2c\40\x76\x69\x64\x65\x20\x61\156\x64\40\x2e\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
