<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29dc7ba6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\x79\137\154\157\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\141\x6d\145\x5f\141\x6e\144\x5f\166\151\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\151\155\x69\x7a\145\40\x69\155\141\147\145\54\40\166\x69\144\145\40\x61\156\144\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
