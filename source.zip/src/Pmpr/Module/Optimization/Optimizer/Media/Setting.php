<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c6c5682             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\171\137\154\x6f\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\141\x6d\145\137\141\x6e\144\x5f\x76\x69\x64\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\155\x69\x7a\145\x20\x69\155\141\x67\145\x2c\x20\x76\x69\144\145\40\141\156\144\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
