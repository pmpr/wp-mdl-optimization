<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d3aa9dad2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\171\137\x6c\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\x61\155\145\x5f\x61\156\144\137\166\151\144\x65\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\x69\155\x69\172\x65\x20\151\155\x61\147\x65\54\40\166\x69\x64\145\x20\x61\156\x64\x20\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
