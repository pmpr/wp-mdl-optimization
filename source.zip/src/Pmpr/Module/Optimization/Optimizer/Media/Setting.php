<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c30d9443ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\x5f\154\157\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\155\145\x5f\x61\x6e\x64\137\166\151\144\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\155\151\x7a\x65\x20\x69\x6d\141\147\145\54\x20\x76\x69\x64\145\40\x61\156\x64\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
