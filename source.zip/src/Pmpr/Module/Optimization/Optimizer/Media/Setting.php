<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668709b77727f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\151\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\x79\x5f\x6c\x6f\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\x67\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\x61\155\145\x5f\141\156\144\137\x76\151\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\151\155\x69\172\145\x20\x69\155\x61\147\x65\54\x20\166\151\144\145\40\x61\x6e\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
