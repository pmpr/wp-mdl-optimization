<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4c57cf814             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\x79\x5f\154\x6f\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\141\x6d\145\137\x61\x6e\144\x5f\x76\151\144\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\x69\155\151\x7a\145\40\151\155\141\147\145\x2c\x20\x76\151\144\145\40\x61\x6e\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
