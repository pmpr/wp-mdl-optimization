<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665872dfe6b03             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\x79\137\154\157\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\141\x6d\145\x5f\141\156\144\x5f\166\151\144\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\151\x6d\151\172\x65\x20\x69\x6d\x61\147\145\x2c\40\x76\x69\x64\145\x20\x61\x6e\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
