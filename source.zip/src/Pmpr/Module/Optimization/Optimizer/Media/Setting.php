<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\172\171\137\x6c\157\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\141\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\155\145\x5f\x61\156\x64\137\166\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\x6d\151\x7a\145\40\x69\155\x61\147\145\54\40\x76\x69\144\x65\40\141\156\x64\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
