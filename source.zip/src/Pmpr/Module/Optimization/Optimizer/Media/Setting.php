<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b5148c02d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\172\171\137\x6c\157\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\x6d\x65\x5f\x61\x6e\144\x5f\x76\151\144\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\155\x69\x7a\x65\x20\x69\x6d\141\147\145\x2c\40\x76\151\x64\x65\40\x61\x6e\x64\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
