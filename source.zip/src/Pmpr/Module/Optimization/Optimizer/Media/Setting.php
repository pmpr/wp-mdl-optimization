<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf88a1c26f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\x69\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\x79\x5f\x6c\157\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\x61\155\145\x5f\141\156\x64\137\166\151\x64\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\155\151\x7a\145\x20\x69\x6d\x61\x67\x65\x2c\x20\166\x69\144\145\40\x61\x6e\144\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
