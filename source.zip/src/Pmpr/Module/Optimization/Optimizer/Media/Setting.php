<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aec46370c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\171\137\154\157\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\141\155\145\137\x61\156\x64\x5f\x76\151\144\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\151\155\x69\172\145\40\x69\155\141\x67\x65\54\40\x76\x69\144\145\40\x61\156\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
