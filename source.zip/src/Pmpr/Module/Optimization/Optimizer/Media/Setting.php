<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635076d1df7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\x79\137\x6c\x6f\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\x61\x6d\x65\137\141\156\x64\x5f\x76\x69\x64\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\155\x69\x7a\145\40\x69\x6d\141\147\145\x2c\40\166\151\144\145\40\141\x6e\x64\40\56\56\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
