<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af54c961e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\x69\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\x5f\154\157\x61\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\141\x6d\x65\x5f\x61\156\144\137\166\x69\144\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\x69\155\x69\x7a\145\x20\x69\x6d\141\x67\145\54\40\166\x69\144\x65\x20\x61\x6e\144\40\x2e\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
