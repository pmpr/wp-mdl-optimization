<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c4e0adc06c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\x79\x5f\154\x6f\x61\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\141\155\x65\137\141\156\144\137\x76\151\x64\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\151\155\x69\172\145\x20\x69\155\141\147\x65\x2c\40\x76\x69\144\x65\x20\x61\156\x64\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
