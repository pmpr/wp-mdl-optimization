<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c5745b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\171\x5f\154\157\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\x61\x6d\x65\x5f\141\156\x64\x5f\166\x69\144\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\x6d\151\x7a\x65\x20\x69\155\x61\147\145\54\x20\166\151\144\x65\x20\x61\x6e\144\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
