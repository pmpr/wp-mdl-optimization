<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1e5ce2c87e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\144\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\171\x5f\154\x6f\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\x61\155\145\x5f\141\x6e\x64\137\x76\x69\x64\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\x69\155\151\x7a\x65\40\x69\155\x61\x67\145\x2c\40\x76\x69\x64\145\40\x61\x6e\x64\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
