<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5d8f13cb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\x79\x5f\154\x6f\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\x61\155\x65\x5f\x61\156\144\x5f\166\x69\x64\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\x69\155\x69\172\x65\40\x69\x6d\141\147\145\x2c\x20\166\151\x64\x65\40\x61\156\x64\x20\56\x2e\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
