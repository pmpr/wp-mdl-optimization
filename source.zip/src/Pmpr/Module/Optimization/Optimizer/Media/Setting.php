<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa800b89726             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\151\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\x5f\x6c\x6f\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\141\155\x65\137\x61\x6e\x64\x5f\166\151\144\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\x69\x6d\x69\172\x65\x20\x69\155\141\147\x65\x2c\x20\166\151\x64\x65\x20\141\x6e\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
