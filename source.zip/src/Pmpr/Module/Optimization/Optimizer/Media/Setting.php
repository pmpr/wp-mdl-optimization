<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eafa500a52f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\137\x6c\x6f\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\141\x6d\145\x5f\x61\156\x64\137\166\151\x64\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\x69\155\x69\172\145\40\151\x6d\x61\x67\145\x2c\40\166\x69\x64\x65\40\141\x6e\x64\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
