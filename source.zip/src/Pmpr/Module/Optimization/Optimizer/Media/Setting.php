<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132a7dc622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\x79\137\x6c\157\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\x61\x6d\145\x5f\141\156\144\x5f\x76\151\x64\x65\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\x69\x6d\x69\172\x65\x20\x69\155\x61\x67\145\x2c\x20\x76\151\x64\145\40\141\156\x64\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
