<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3161a77b51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\x69\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\x79\x5f\154\157\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\x61\x6d\145\137\x61\x6e\144\x5f\x76\x69\144\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\151\x6d\x69\172\x65\40\151\155\141\147\x65\x2c\40\x76\x69\x64\145\x20\141\x6e\144\40\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
