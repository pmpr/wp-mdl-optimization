<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6347bb78c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\171\x5f\x6c\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\x61\155\x65\x5f\141\x6e\x64\x5f\166\x69\144\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\155\151\172\145\40\151\155\x61\147\145\54\x20\x76\151\x64\x65\x20\141\x6e\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
