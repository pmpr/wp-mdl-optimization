<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada83915b0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\x79\x5f\x6c\157\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\141\155\145\137\141\156\x64\x5f\166\151\144\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\151\155\151\x7a\x65\x20\x69\x6d\x61\147\x65\54\40\x76\x69\144\x65\x20\141\x6e\x64\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
