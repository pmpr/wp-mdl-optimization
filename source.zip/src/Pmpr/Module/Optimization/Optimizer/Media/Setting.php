<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aff7366c1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\144\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\x5f\154\x6f\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\x72\x61\155\145\137\x61\x6e\x64\137\x76\x69\x64\145\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\x64\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\x69\155\x69\172\145\40\x69\x6d\x61\x67\145\x2c\40\x76\151\x64\x65\40\x61\x6e\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
