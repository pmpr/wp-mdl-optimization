<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ad9ca28a94             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\171\x5f\154\x6f\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\x72\x61\155\145\137\x61\x6e\x64\x5f\166\x69\144\x65\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\151\155\151\172\145\x20\151\x6d\141\147\x65\54\40\x76\x69\144\x65\x20\141\x6e\144\40\56\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
