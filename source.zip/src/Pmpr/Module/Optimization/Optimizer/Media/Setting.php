<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b61878830b2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\171\137\154\157\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\141\155\x65\137\x61\156\x64\137\x76\151\144\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\x69\155\151\x7a\x65\x20\151\x6d\141\x67\x65\x2c\40\x76\x69\144\145\40\x61\x6e\144\40\56\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
