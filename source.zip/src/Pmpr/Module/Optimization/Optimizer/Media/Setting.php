<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\151\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\x7a\x79\x5f\x6c\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\x61\x6d\x65\137\141\156\x64\x5f\166\x69\x64\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\151\x6d\x69\x7a\145\40\151\x6d\141\x67\x65\54\40\x76\151\x64\145\x20\141\156\144\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
