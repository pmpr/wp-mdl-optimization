<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\151\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\172\171\137\x6c\157\x61\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\x61\x6d\145\137\x61\156\144\x5f\166\x69\144\x65\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\151\155\x69\x7a\x65\x20\x69\155\141\147\145\x2c\40\x76\x69\144\145\x20\x61\156\144\40\56\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
