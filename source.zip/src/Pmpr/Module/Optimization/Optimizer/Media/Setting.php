<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668724cd3b441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\171\x5f\154\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\141\x6d\145\x5f\141\156\144\x5f\166\151\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\x69\x6d\151\172\x65\40\x69\155\141\x67\x65\x2c\x20\x76\x69\x64\x65\40\141\x6e\144\x20\56\x2e\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
