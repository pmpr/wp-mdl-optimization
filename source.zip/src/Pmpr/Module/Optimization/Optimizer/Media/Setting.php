<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24006e45d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\171\137\154\157\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\x61\x6d\x65\137\141\156\144\x5f\166\151\x64\x65\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\x69\x6d\151\172\x65\40\151\x6d\x61\x67\145\54\40\166\x69\x64\145\x20\141\x6e\x64\40\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
