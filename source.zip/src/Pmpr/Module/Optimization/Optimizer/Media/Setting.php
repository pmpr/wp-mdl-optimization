<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400e520636             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\137\x6c\x6f\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\141\155\145\x5f\x61\x6e\x64\137\166\x69\x64\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\x69\x6d\x69\x7a\145\40\151\155\x61\x67\145\54\40\x76\151\144\x65\40\141\x6e\x64\40\x2e\56\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
