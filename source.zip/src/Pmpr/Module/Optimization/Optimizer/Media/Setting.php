<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668660e287d70             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\x79\137\x6c\x6f\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\x61\x6d\145\137\141\156\144\137\166\151\144\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\151\155\151\x7a\145\40\151\155\141\147\145\54\40\166\151\x64\145\x20\141\x6e\144\x20\56\x2e\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
