<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d22efa3658b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\171\137\154\x6f\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\141\x67\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\141\155\145\x5f\141\156\x64\137\166\x69\x64\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\164\151\x6d\x69\x7a\145\x20\x69\x6d\x61\147\x65\x2c\x20\x76\151\x64\145\x20\x61\156\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
