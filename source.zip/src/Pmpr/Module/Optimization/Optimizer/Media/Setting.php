<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ada53dffd1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\151\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\x5f\154\157\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\141\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\x72\141\x6d\x65\x5f\x61\156\144\x5f\166\151\144\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\x69\155\x69\172\x65\x20\151\x6d\141\147\145\x2c\x20\166\x69\144\x65\40\141\156\144\40\56\x2e\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::wikgqsqysyuoykse)); } }
