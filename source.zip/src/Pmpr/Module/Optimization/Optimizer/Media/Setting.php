<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afcef5beb16             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\171\x5f\x6c\x6f\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\x72\141\155\145\x5f\141\x6e\x64\x5f\166\151\144\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\x69\x6d\151\172\145\x20\151\x6d\x61\147\x65\54\40\166\x69\144\x65\40\x61\x6e\x64\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
