<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25d3ac530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\137\x6c\157\x61\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\x61\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\x61\155\x65\x5f\141\x6e\144\137\166\x69\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\151\x6d\x69\x7a\145\x20\151\155\141\147\145\x2c\40\x76\151\x64\x65\40\x61\156\x64\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
