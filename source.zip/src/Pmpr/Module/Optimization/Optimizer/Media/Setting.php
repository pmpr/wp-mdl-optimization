<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba5a468b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\151\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\171\x5f\x6c\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\141\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\x66\162\141\x6d\145\137\x61\x6e\144\x5f\x76\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\x64\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\151\155\151\172\145\40\151\155\141\147\145\x2c\x20\x76\x69\x64\145\40\x61\156\x64\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))->cuomeiwckekemywm($this->symouyowemaacayu(), self::smkwuwawwaqyimcq, false)); } }
