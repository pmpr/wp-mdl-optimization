<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665afacdd5cec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; use Pmpr\Module\Optimization\Optimizer\Media\Common as BaseClass; abstract class Common extends BaseClass { }
