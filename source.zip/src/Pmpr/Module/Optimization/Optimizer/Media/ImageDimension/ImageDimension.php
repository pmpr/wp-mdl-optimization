<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6658781c3e0dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); if (!($this->weysguygiseoukqw(Setting::issekcywqmgcacqc) && $this->ocysssyiuaueqiei())) { goto wcugqegqsuuuwqao; } Engine::symcgieuakksimmu(); wcugqegqsuuuwqao: } }
