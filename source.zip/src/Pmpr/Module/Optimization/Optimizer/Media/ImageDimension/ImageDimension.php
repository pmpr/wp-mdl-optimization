<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); if (!($this->weysguygiseoukqw(Setting::issekcywqmgcacqc) && $this->ocysssyiuaueqiei())) { goto sicgyiyiocyygkoc; } Engine::symcgieuakksimmu(); sicgyiyiocyygkoc: } }
