<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dc2456c625             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); if (!($this->weysguygiseoukqw(Setting::issekcywqmgcacqc) && $this->ocysssyiuaueqiei())) { goto wcugqegqsuuuwqao; } Engine::symcgieuakksimmu(); wcugqegqsuuuwqao: } }
