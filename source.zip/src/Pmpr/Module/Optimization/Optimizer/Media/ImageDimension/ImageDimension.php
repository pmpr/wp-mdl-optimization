<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4181e072c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); if (!($this->weysguygiseoukqw(Setting::issekcywqmgcacqc) && $this->ocysssyiuaueqiei())) { goto kgmeiwiakwicgkkk; } Engine::symcgieuakksimmu(); kgmeiwiakwicgkkk: } }
