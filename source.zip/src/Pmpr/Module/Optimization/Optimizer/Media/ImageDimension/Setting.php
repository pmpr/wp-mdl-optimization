<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689e7e085e417             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const issekcywqmgcacqc = 'media_image_dimensions'; public function ikcgmcycisiccyuc() { $this->segment = 'media'; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->kwkugmqouisgkqig($uuyucgkyusckoaeq->ycgeeoiieoiakgam('image_dimensions')->saemoowcasogykak(IconInterface::qkcuqsauwouaeqeg)->gswweykyogmsyawy(__('Imag Dimensions', PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__('Add missing width and height attributes to images. Helps prevent layout shifts(CLS) and improve the reading experience for your visitors.', PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($uuyucgkyusckoaeq->wcwmusaouiqaqeww(self::issekcywqmgcacqc)->gswweykyogmsyawy(__('Add Missing Image Dimensions', PR__MDL__OPTIMIZATION)))); } }
