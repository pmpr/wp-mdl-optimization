<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15f89bee20             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Module\Optimization\Optimizer\Common as BaseClass; abstract class Common extends BaseClass { }
