<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cba0bde7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound\Notfound; use Pmpr\Module\Optimization\Optimizer\SpecialPage\Search\Search; class SpecialPage extends Common { public function mameiwsayuyquoeq() { Search::symcgieuakksimmu(); Setting::symcgieuakksimmu(); Notfound::symcgieuakksimmu(); } }
