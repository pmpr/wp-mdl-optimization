<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cebac3c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Search; class Search extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
