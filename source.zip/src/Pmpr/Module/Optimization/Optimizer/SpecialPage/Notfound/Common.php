<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668664c7535d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\SpecialPage\Common as BaseClass; abstract class Common extends BaseClass { const yciuqmyagwugyggw = "\156\157\164\146\x6f\165\x6e\x64\137\146\151\154\x65\x5f\156\141\x6d\x65"; }
