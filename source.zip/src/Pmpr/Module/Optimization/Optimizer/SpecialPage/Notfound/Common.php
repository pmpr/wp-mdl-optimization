<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\SpecialPage\Common as BaseClass; abstract class Common extends BaseClass { const yciuqmyagwugyggw = "\156\157\x74\x66\157\x75\x6e\x64\x5f\x66\x69\154\145\137\x6e\141\155\x65"; }
