<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66375048491fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\SpecialPage\Common as BaseClass; abstract class Common extends BaseClass { const yciuqmyagwugyggw = "\156\157\164\146\157\x75\x6e\144\x5f\146\151\x6c\x65\137\x6e\x61\155\x65"; }
