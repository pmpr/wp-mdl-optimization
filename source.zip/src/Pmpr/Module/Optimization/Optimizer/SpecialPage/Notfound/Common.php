<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637389418f87             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\SpecialPage\Common as BaseClass; abstract class Common extends BaseClass { const yciuqmyagwugyggw = "\x6e\157\164\146\x6f\x75\x6e\x64\137\x66\151\x6c\x65\x5f\156\x61\155\145"; }
