<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663698627f721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\144\166\141\x6e\143\x65\144\x2d\64\x30\x34\56\160\150\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::ikimkawumgqsuaaa); } public function gayqqwwuycceosii() : array { return ["\x66\151\x6c\x65\x70\141\164\150" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
