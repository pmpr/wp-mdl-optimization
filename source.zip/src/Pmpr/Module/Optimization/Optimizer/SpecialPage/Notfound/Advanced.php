<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ad6e880229             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\x61\x64\x76\141\x6e\x63\145\x64\55\64\60\x34\x2e\x70\150\x70"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::ikimkawumgqsuaaa); } public function gayqqwwuycceosii() : array { return ["\x66\x69\154\145\160\141\164\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
