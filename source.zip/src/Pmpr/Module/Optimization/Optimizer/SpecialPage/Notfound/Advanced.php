<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af79314d69             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\x61\x64\166\x61\x6e\143\145\x64\x2d\x34\x30\64\x2e\160\x68\x70"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::ikimkawumgqsuaaa); } public function gayqqwwuycceosii() : array { return ["\x66\x69\154\x65\x70\x61\x74\150" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
