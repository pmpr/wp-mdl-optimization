<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\x61\144\166\141\x6e\143\x65\x64\55\x34\60\x34\56\x70\150\x70"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::ikimkawumgqsuaaa); } public function gayqqwwuycceosii() : array { return ["\146\151\x6c\x65\160\141\x74\150" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
