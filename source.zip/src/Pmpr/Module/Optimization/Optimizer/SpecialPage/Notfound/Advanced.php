<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6d38ae4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage\Notfound; use Pmpr\Module\Optimization\Optimizer\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\144\x76\x61\156\143\145\x64\x2d\x34\x30\x34\x2e\x70\150\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(self::ikimkawumgqsuaaa); } public function gayqqwwuycceosii() : array { return ["\x66\x69\x6c\x65\x70\141\164\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
