<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\143\x69\141\154\x5f\x70\141\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\145\143\x69\141\x6c\40\x50\x61\x67\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\141\162\x63\x68\x2c\x20\64\60\64\40\141\156\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
