<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666957c99839f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\143\151\141\154\x5f\160\141\147\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\143\x69\141\x6c\x20\120\141\x67\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\162\x63\150\x2c\x20\64\x30\x34\40\141\156\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
