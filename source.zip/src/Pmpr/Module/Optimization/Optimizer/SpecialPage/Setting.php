<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\143\x69\141\154\x5f\x70\141\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\143\151\x61\x6c\40\120\x61\x67\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\162\143\150\54\x20\x34\60\64\x20\x61\156\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
