<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66697656b7da9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\x65\x63\151\x61\154\x5f\x70\x61\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\x63\151\x61\x6c\40\120\141\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\162\x63\150\54\40\64\x30\64\x20\x61\156\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
