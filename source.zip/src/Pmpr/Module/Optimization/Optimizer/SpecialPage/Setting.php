<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f091293fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\151\x61\x6c\137\x70\141\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\143\x69\x61\154\x20\x50\141\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\x72\143\150\54\40\x34\60\64\x20\x61\156\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
