<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665f4289276f4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\x63\151\141\x6c\137\160\141\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\x63\151\141\x6c\x20\120\x61\x67\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\x61\x72\x63\150\x2c\40\x34\x30\64\x20\141\156\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
