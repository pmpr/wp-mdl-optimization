<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663503140fc0e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\143\151\141\x6c\x5f\x70\x61\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\143\151\141\154\x20\x50\141\x67\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\141\x72\143\150\54\40\x34\60\x34\x20\141\x6e\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
