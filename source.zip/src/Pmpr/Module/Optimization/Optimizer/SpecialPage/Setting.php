<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668724cd3b441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\x63\x69\x61\154\x5f\160\141\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\x65\x63\151\x61\x6c\x20\x50\141\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\162\x63\x68\x2c\x20\64\x30\x34\x20\141\x6e\144\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
