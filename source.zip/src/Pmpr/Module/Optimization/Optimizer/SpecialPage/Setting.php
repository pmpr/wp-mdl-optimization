<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2ce1dff84             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\143\x69\141\x6c\137\160\x61\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\x63\x69\x61\154\x20\120\141\147\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\162\x63\150\54\40\x34\x30\64\40\x61\x6e\144\40\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
