<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f163107a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\151\x61\154\137\160\141\147\x65\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\151\x61\154\40\120\141\x67\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\141\x72\143\150\x2c\x20\x34\60\x34\40\x61\156\144\40\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
