<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             664697c805b60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\151\141\154\137\x70\x61\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\145\143\x69\x61\154\x20\x50\141\x67\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\x61\162\143\150\x2c\40\64\60\x34\40\x61\x6e\x64\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
