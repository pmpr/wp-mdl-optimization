<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668660e287d70             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\145\x63\x69\141\x6c\x5f\x70\x61\147\x65\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\x65\x63\151\141\x6c\40\120\x61\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\x72\x63\x68\54\40\x34\x30\x34\x20\x61\156\x64\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
