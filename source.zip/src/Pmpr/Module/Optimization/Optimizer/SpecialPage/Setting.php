<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2db183c14             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\145\143\x69\x61\x6c\x5f\x70\141\147\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\x65\143\151\141\x6c\40\x50\x61\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\x61\x72\x63\150\54\x20\64\x30\x34\x20\141\156\x64\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
