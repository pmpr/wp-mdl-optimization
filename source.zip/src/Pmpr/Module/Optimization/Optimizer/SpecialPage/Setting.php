<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689580cbf1c8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\x65\143\x69\141\x6c\x5f\x70\141\147\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\145\x63\x69\x61\154\x20\x50\x61\147\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\x61\162\143\150\x2c\40\64\x30\64\40\141\x6e\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
