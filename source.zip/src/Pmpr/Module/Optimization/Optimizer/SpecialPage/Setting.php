<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663757b0e9f86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\x63\x69\x61\154\137\x70\141\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\x63\x69\x61\x6c\x20\120\141\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\x61\x72\x63\150\54\40\64\60\x34\x20\141\156\x64\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
