<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ada53dffd1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\143\151\x61\154\137\160\x61\147\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\145\143\x69\x61\154\40\x50\141\147\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\141\x72\143\x68\54\40\x34\x30\x34\x20\x61\x6e\144\x20\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
