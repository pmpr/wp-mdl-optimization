<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af54c961e2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\145\143\x69\141\154\137\x70\141\x67\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\145\x63\151\x61\x6c\x20\120\x61\x67\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\x61\x72\143\x68\54\40\x34\60\64\40\x61\156\144\40\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
