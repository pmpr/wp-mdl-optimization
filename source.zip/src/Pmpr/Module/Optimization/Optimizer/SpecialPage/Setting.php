<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f51179ea7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\x65\143\x69\141\154\137\160\141\x67\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\x69\141\x6c\x20\x50\x61\x67\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\162\x63\150\x2c\x20\x34\x30\x34\40\x61\x6e\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
