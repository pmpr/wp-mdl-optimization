<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd253c8f77d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Defer; use Pmpr\Module\Optimization\Optimizer\Asset\Common as BaseClass; abstract class Common extends BaseClass { }
