<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7139a54fa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Defer; use Pmpr\Module\Optimization\Optimizer\Asset\Common as BaseClass; abstract class Common extends BaseClass { }
