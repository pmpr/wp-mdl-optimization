<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66869afc6c108             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Defer; class Defer extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
