<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58598b21ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Defer; class Defer extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
