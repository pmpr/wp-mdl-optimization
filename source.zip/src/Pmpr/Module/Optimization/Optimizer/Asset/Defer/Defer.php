<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663506337ce5d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Defer; class Defer extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
