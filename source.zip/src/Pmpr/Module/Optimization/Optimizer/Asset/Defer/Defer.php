<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2ec2cd5b75             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Defer; class Defer extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
