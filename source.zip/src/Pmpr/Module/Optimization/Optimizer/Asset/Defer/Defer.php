<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686f091293fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Defer; class Defer extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
