<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Delay; class Delay extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
