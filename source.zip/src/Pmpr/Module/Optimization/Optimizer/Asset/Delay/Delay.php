<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2182256c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Delay; class Delay extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
