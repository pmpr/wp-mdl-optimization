<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6658781c3e0dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Delay; class Delay extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
