<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             664697c805b60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Delay; class Delay extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
