<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Delay; class Delay extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
