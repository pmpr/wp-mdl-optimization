<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32325cda1b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Delay; use Pmpr\Module\Optimization\Optimizer\Asset\Common as BaseClass; abstract class Common extends BaseClass { }
