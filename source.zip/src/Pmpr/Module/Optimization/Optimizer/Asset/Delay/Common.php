<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cebac3c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Delay; use Pmpr\Module\Optimization\Optimizer\Asset\Common as BaseClass; abstract class Common extends BaseClass { }
