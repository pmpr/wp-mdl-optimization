<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afa619aaca2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Optimizer\Asset\Critical\Critical; use Pmpr\Module\Optimization\Optimizer\Asset\Defer\Defer; use Pmpr\Module\Optimization\Optimizer\Asset\Delay\Delay; use Pmpr\Module\Optimization\Optimizer\Asset\Font\Font; class Asset extends Common { public function mameiwsayuyquoeq() { Font::symcgieuakksimmu(); Delay::symcgieuakksimmu(); Defer::symcgieuakksimmu(); Setting::symcgieuakksimmu(); Preload::symcgieuakksimmu(); Critical::symcgieuakksimmu(); } }
