<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79d4da80             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Optimizer\Asset\Critical\Critical; use Pmpr\Module\Optimization\Optimizer\Asset\Defer\Defer; use Pmpr\Module\Optimization\Optimizer\Asset\Delay\Delay; class Asset extends Common { public function mameiwsayuyquoeq() { Delay::symcgieuakksimmu(); Defer::symcgieuakksimmu(); Setting::symcgieuakksimmu(); Preload::symcgieuakksimmu(); Critical::symcgieuakksimmu(); } }
