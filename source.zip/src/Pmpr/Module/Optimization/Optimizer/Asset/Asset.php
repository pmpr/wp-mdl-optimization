<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b5148c02d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; class Asset extends Common { public function mameiwsayuyquoeq() { CriticalCSS::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto wcmksyiisiciasko; } Setting::symcgieuakksimmu(); goto augyqmcwawmsykme; wcmksyiisiciasko: Preload::symcgieuakksimmu(); switch ($this->weysguygiseoukqw(Setting::acmmwemggiumsoyo)) { case Setting::gwgekowoowwyuuia: case Setting::oqiaceqksggqgoww: Delay::symcgieuakksimmu(); goto oegcoaeyokkgoqyg; case Setting::suqaaeokeaqayoyk: Defer::symcgieuakksimmu(); goto oegcoaeyokkgoqyg; } euuoiciaiieoqyws: oegcoaeyokkgoqyg: augyqmcwawmsykme: } }
