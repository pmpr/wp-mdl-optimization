<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1e5357c62d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Critical; use Pmpr\Module\Optimization\Optimizer\Asset\Common as BaseClass; abstract class Common extends BaseClass { }
