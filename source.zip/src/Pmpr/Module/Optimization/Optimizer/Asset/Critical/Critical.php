<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b40b3181dac             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Critical; class Critical extends Common { public function mameiwsayuyquoeq() { Style::symcgieuakksimmu(); } }
