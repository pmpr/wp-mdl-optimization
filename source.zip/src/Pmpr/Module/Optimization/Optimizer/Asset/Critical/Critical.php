<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d230b1b85af             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Critical; class Critical extends Common { public function mameiwsayuyquoeq() { Style::symcgieuakksimmu(); } }
