<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c508f721bbb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Critical; class Critical extends Common { public function mameiwsayuyquoeq() { Style::symcgieuakksimmu(); } }
