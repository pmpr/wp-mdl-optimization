<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635046c437f5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; class Preload extends BufferEngine { public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\x63\151\155\165\151\171\x61\x65\163\155\x73\x79\x75\x75\141\x75"], 0); } public function cimuiyaesmsyuuau($moooemyaqewumiay) { if (!($ascuieeescesuoow = $this->ocksiywmkyaqseou(self::kgswyesggeyekgmg . "\x61\x73\x73\x65\x74\137\x70\162\145\x6c\x6f\141\x64\x5f\151\x74\x65\x6d\x73", []))) { goto sikckcmeiwmyakeu; } $nsmgceoqaqogqmuw = implode('', $ascuieeescesuoow); $moooemyaqewumiay = preg_replace("\43\x3c\x2f\164\x69\x74\x6c\145\x3e\x23\151\125", "\74\x2f\x74\151\164\x6c\x65\x3e{$nsmgceoqaqogqmuw}", $moooemyaqewumiay, 1); sikckcmeiwmyakeu: return $moooemyaqewumiay; } }
