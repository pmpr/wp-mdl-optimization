<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; class Preload extends BufferEngine { public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\143\x69\x6d\165\151\x79\x61\145\x73\155\x73\171\165\165\141\x75"], 0); } public function cimuiyaesmsyuuau($moooemyaqewumiay) { if (!($ascuieeescesuoow = $this->ocksiywmkyaqseou(self::kgswyesggeyekgmg . "\x61\x73\163\145\164\x5f\160\x72\145\154\x6f\141\x64\x5f\x69\164\x65\155\x73", []))) { goto sikckcmeiwmyakeu; } $nsmgceoqaqogqmuw = implode('', $ascuieeescesuoow); $moooemyaqewumiay = preg_replace("\x23\x3c\57\x74\x69\x74\x6c\x65\76\43\151\125", "\74\57\164\x69\164\x6c\145\76{$nsmgceoqaqogqmuw}", $moooemyaqewumiay, 1); sikckcmeiwmyakeu: return $moooemyaqewumiay; } }
