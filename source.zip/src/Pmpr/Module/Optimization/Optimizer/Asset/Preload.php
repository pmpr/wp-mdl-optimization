<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350bd82c2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; class Preload extends BufferEngine { public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\x63\151\x6d\x75\151\x79\x61\x65\163\x6d\x73\x79\165\x75\141\165"], 0); } public function cimuiyaesmsyuuau($moooemyaqewumiay) { if (!($ascuieeescesuoow = $this->ocksiywmkyaqseou(self::kgswyesggeyekgmg . "\141\x73\x73\145\164\137\160\162\145\x6c\157\141\144\137\x69\x74\145\155\x73", []))) { goto sikckcmeiwmyakeu; } $nsmgceoqaqogqmuw = implode('', $ascuieeescesuoow); $moooemyaqewumiay = preg_replace("\43\x3c\57\164\151\164\x6c\145\76\43\151\125", "\74\57\x74\x69\164\154\x65\x3e{$nsmgceoqaqogqmuw}", $moooemyaqewumiay, 1); sikckcmeiwmyakeu: return $moooemyaqewumiay; } }
