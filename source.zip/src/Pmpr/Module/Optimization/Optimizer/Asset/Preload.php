<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6635076d1df7d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; class Preload extends BufferEngine { public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\143\151\x6d\x75\x69\x79\x61\x65\163\155\163\171\165\x75\x61\165"], 0); } public function cimuiyaesmsyuuau($moooemyaqewumiay) { if (!($ascuieeescesuoow = $this->ocksiywmkyaqseou(self::kgswyesggeyekgmg . "\x61\163\x73\145\x74\x5f\x70\x72\145\x6c\157\x61\144\137\151\164\145\x6d\163", []))) { goto sikckcmeiwmyakeu; } $nsmgceoqaqogqmuw = implode('', $ascuieeescesuoow); $moooemyaqewumiay = preg_replace("\43\x3c\57\164\x69\x74\x6c\145\x3e\43\x69\125", "\x3c\x2f\164\151\164\154\x65\76{$nsmgceoqaqogqmuw}", $moooemyaqewumiay, 1); sikckcmeiwmyakeu: return $moooemyaqewumiay; } }
