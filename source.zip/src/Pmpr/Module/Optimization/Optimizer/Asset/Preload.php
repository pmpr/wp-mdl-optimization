<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663503140fc0e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; class Preload extends BufferEngine { public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\x63\x69\155\x75\x69\x79\x61\x65\x73\155\x73\x79\x75\x75\141\x75"], 0); } public function cimuiyaesmsyuuau($moooemyaqewumiay) { if (!($ascuieeescesuoow = $this->ocksiywmkyaqseou(self::kgswyesggeyekgmg . "\141\x73\163\x65\x74\x5f\160\x72\x65\154\157\x61\144\x5f\x69\164\x65\155\163", []))) { goto sikckcmeiwmyakeu; } $nsmgceoqaqogqmuw = implode('', $ascuieeescesuoow); $moooemyaqewumiay = preg_replace("\x23\74\x2f\164\x69\x74\154\x65\76\x23\x69\x55", "\x3c\x2f\x74\151\x74\x6c\x65\76{$nsmgceoqaqogqmuw}", $moooemyaqewumiay, 1); sikckcmeiwmyakeu: return $moooemyaqewumiay; } }
