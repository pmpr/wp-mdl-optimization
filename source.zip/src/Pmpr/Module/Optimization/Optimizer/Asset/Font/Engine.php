<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6d38ae4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Font; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; class Engine extends BufferEngine { }
