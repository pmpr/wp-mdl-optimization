<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69ee00a3ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Font; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; class Engine extends BufferEngine { use PageManagerEngineTrait; public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\x73\x61\151\x75\x71\163\143\153\x6f\171\x77\155\x79\143\151\x6f"], 0); } public function saiuqsckoywmycio(?string $moooemyaqewumiay) : ?string { $ikckcymqyiwygqsk = $this->wkagassgcaqeosio()->gokaoakuqescuuye(); if (!(!empty($ikckcymqyiwygqsk[self::okmiyqowuqogaiiy]) && (!isset($ikckcymqyiwygqsk["\151\155\x67"]) || !$ikckcymqyiwygqsk["\151\155\x67"]))) { goto uagsgicwwcakecwq; } $smuykqsageuocuos = $this->caokeucsksukesyo()->gkksucgseqqemesc(); if (!$smuykqsageuocuos->has($moooemyaqewumiay, $ikckcymqyiwygqsk[self::okmiyqowuqogaiiy])) { goto kcqueaewmayywqeq; } $moooemyaqewumiay = $smuykqsageuocuos->igmaewykumgwoaoy($moooemyaqewumiay, [$ikckcymqyiwygqsk[self::okmiyqowuqogaiiy] => ["\163\164\x79\x6c\145" => "\146\x6f\156\164\55\x66\x61\x6d\151\x6c\x79\72\x20\151\156\151\164\x69\x61\x6c\x3b"]]); kcqueaewmayywqeq: uagsgicwwcakecwq: return $moooemyaqewumiay; } }
