<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69b17b7795             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Font; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; class Engine extends BufferEngine { use PageManagerEngineTrait; public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\163\141\151\165\161\163\143\x6b\x6f\x79\x77\x6d\x79\x63\x69\157"], 0); } public function saiuqsckoywmycio(?string $moooemyaqewumiay) : ?string { $ikckcymqyiwygqsk = $this->wkagassgcaqeosio()->gokaoakuqescuuye(); if (!(!empty($ikckcymqyiwygqsk[self::okmiyqowuqogaiiy]) && (!isset($ikckcymqyiwygqsk["\x69\x6d\147"]) || !$ikckcymqyiwygqsk["\x69\x6d\147"]))) { goto uagsgicwwcakecwq; } $smuykqsageuocuos = $this->caokeucsksukesyo()->gkksucgseqqemesc(); if (!$smuykqsageuocuos->has($moooemyaqewumiay, $ikckcymqyiwygqsk[self::okmiyqowuqogaiiy])) { goto kcqueaewmayywqeq; } $moooemyaqewumiay = $smuykqsageuocuos->igmaewykumgwoaoy($moooemyaqewumiay, [$ikckcymqyiwygqsk[self::okmiyqowuqogaiiy] => ["\x73\x74\x79\154\x65" => "\x66\157\x6e\164\55\x66\141\155\x69\154\171\72\40\x69\x6e\x69\164\151\x61\154\73"]]); kcqueaewmayywqeq: uagsgicwwcakecwq: return $moooemyaqewumiay; } }
