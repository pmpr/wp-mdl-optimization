<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a68e6136ef8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Font; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; class Engine extends BufferEngine { use PageManagerEngineTrait; public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\163\x61\x69\165\x71\163\x63\x6b\x6f\171\x77\x6d\x79\143\151\x6f"], 0); } public function saiuqsckoywmycio(?string $moooemyaqewumiay) : ?string { $ikckcymqyiwygqsk = $this->wkagassgcaqeosio()->gokaoakuqescuuye(); if (!(!empty($ikckcymqyiwygqsk[self::okmiyqowuqogaiiy]) && (!isset($ikckcymqyiwygqsk["\x69\155\x67"]) || !$ikckcymqyiwygqsk["\151\x6d\x67"]))) { goto uagsgicwwcakecwq; } $smuykqsageuocuos = $this->caokeucsksukesyo()->gkksucgseqqemesc(); if (!$smuykqsageuocuos->has($moooemyaqewumiay, $ikckcymqyiwygqsk[self::okmiyqowuqogaiiy])) { goto kcqueaewmayywqeq; } $moooemyaqewumiay = $smuykqsageuocuos->igmaewykumgwoaoy($moooemyaqewumiay, [$ikckcymqyiwygqsk[self::okmiyqowuqogaiiy] => ["\163\164\x79\x6c\145" => "\x66\x6f\x6e\x74\55\146\141\x6d\151\x6c\x79\72\40\x69\x6e\151\164\151\141\x6c\73"]]); kcqueaewmayywqeq: uagsgicwwcakecwq: return $moooemyaqewumiay; } }
