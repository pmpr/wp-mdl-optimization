<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a6a10b62e31             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Font; use Pmpr\Module\Optimization\Optimizer\Buffer\Engine as BufferEngine; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; class Engine extends BufferEngine { use PageManagerEngineTrait; public function kgquecmsgcouyaya() { $this->miasamwyaiagioug([$this, "\163\x61\151\x75\161\163\143\x6b\157\171\167\x6d\171\x63\151\157"], 0); } public function saiuqsckoywmycio(?string $moooemyaqewumiay) : ?string { $ikckcymqyiwygqsk = $this->wkagassgcaqeosio()->gokaoakuqescuuye(); if (!(!empty($ikckcymqyiwygqsk[self::okmiyqowuqogaiiy]) && (!isset($ikckcymqyiwygqsk["\x69\155\147"]) || !$ikckcymqyiwygqsk["\151\155\147"]))) { goto uagsgicwwcakecwq; } $smuykqsageuocuos = $this->caokeucsksukesyo()->gkksucgseqqemesc(); if (!$smuykqsageuocuos->has($moooemyaqewumiay, $ikckcymqyiwygqsk[self::okmiyqowuqogaiiy])) { goto kcqueaewmayywqeq; } $moooemyaqewumiay = $smuykqsageuocuos->igmaewykumgwoaoy($moooemyaqewumiay, [$ikckcymqyiwygqsk[self::okmiyqowuqogaiiy] => ["\163\x74\171\154\x65" => "\146\x6f\x6e\x74\x2d\146\141\155\x69\x6c\x79\72\40\151\x6e\x69\x74\x69\x61\x6c\x3b"]]); kcqueaewmayywqeq: uagsgicwwcakecwq: return $moooemyaqewumiay; } }
