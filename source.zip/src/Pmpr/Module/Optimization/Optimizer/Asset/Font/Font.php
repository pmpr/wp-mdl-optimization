<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd21640c7ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset\Font; class Font extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
