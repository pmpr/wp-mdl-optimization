<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f163107a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer; use Pmpr\Module\Optimization\Optimizer\Asset\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Config; use Pmpr\Module\Optimization\Optimizer\Buffer\Test; use Pmpr\Module\Optimization\Optimizer\Cache\Cache; use Pmpr\Module\Optimization\Optimizer\HTML\HTML; use Pmpr\Module\Optimization\Optimizer\Media\Media; use Pmpr\Module\Optimization\Optimizer\SpecialPage\SpecialPage; class Optimizer extends Common { public function mameiwsayuyquoeq() { HTML::symcgieuakksimmu(); Cache::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Media::symcgieuakksimmu(); SpecialPage::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\x70\154\141\x74\145\x5f\162\x65\x64\x69\162\145\x63\x74", [$this, "\147\151\x77\171\163\x6b\x77\x77\x6d\143\151\x65\165\x61\143\x71"], 999); } public function giwyskwwmcieuacq() { $uiewakwqscemywuo = new Config(["\x70\x61\x74\150" => $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::gyiksueiaeykqaqq)]); new Buffer(new Test($uiewakwqscemywuo, ["\x6c\x6f\147\147\x65\162" => $this->waasecgmwoucqoqa()])); } }
