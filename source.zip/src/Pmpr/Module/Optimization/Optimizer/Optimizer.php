<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c30d9443ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer; use Pmpr\Module\Optimization\Optimizer\Asset\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Config; use Pmpr\Module\Optimization\Optimizer\Buffer\Test; use Pmpr\Module\Optimization\Optimizer\Cache\Cache; use Pmpr\Module\Optimization\Optimizer\HTML\HTML; use Pmpr\Module\Optimization\Optimizer\Media\Media; use Pmpr\Module\Optimization\Optimizer\SpecialPage\SpecialPage; class Optimizer extends Common { public function mameiwsayuyquoeq() { HTML::symcgieuakksimmu(); Cache::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Media::symcgieuakksimmu(); SpecialPage::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\x6c\141\164\x65\137\162\x65\x64\x69\x72\145\x63\x74", [$this, "\147\x69\167\171\x73\x6b\x77\x77\155\143\x69\x65\165\141\143\x71"], 999); } public function giwyskwwmcieuacq() { $uiewakwqscemywuo = new Config(["\x70\141\164\x68" => $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::gyiksueiaeykqaqq)]); new Buffer(new Test($uiewakwqscemywuo, ["\154\157\x67\147\x65\162" => $this->waasecgmwoucqoqa()])); } }
