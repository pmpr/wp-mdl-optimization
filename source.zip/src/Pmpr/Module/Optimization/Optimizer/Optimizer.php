<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665adbb76768c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer; use Pmpr\Module\Optimization\Optimizer\Asset\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Config; use Pmpr\Module\Optimization\Optimizer\Buffer\Test; use Pmpr\Module\Optimization\Optimizer\Cache\Cache; use Pmpr\Module\Optimization\Optimizer\HTML\HTML; use Pmpr\Module\Optimization\Optimizer\Media\Media; use Pmpr\Module\Optimization\Optimizer\SpecialPage\SpecialPage; class Optimizer extends Common { public function mameiwsayuyquoeq() { HTML::symcgieuakksimmu(); Cache::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Media::symcgieuakksimmu(); SpecialPage::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\160\x6c\141\x74\x65\137\x72\145\x64\x69\x72\145\143\164", [$this, "\147\151\x77\171\x73\153\x77\167\x6d\143\x69\145\x75\x61\143\161"], 999); } public function giwyskwwmcieuacq() { $uiewakwqscemywuo = new Config(["\160\141\164\150" => $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::gyiksueiaeykqaqq)]); new Buffer(new Test($uiewakwqscemywuo, ["\x6c\157\147\x67\x65\162" => $this->waasecgmwoucqoqa()])); } }
