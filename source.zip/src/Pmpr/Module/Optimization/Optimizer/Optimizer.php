<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f43f6aa4f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer; use Pmpr\Module\Optimization\Optimizer\Asset\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Config; use Pmpr\Module\Optimization\Optimizer\Buffer\Test; use Pmpr\Module\Optimization\Optimizer\Cache\Cache; use Pmpr\Module\Optimization\Optimizer\HTML\HTML; use Pmpr\Module\Optimization\Optimizer\Media\Media; use Pmpr\Module\Optimization\Optimizer\SpecialPage\SpecialPage; class Optimizer extends Common { public function mameiwsayuyquoeq() { HTML::symcgieuakksimmu(); Cache::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Media::symcgieuakksimmu(); SpecialPage::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\x70\154\x61\x74\x65\x5f\162\x65\144\x69\x72\x65\x63\164", [$this, "\147\151\167\x79\163\153\167\167\x6d\143\x69\145\x75\141\x63\161"], 999); } public function giwyskwwmcieuacq() { $uiewakwqscemywuo = new Config(["\x70\141\164\150" => $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::gyiksueiaeykqaqq)]); new Buffer(new Test($uiewakwqscemywuo, ["\154\x6f\x67\147\145\162" => $this->waasecgmwoucqoqa()])); } }
