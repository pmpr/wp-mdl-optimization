<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637d2bee1dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer; use Pmpr\Module\Optimization\Optimizer\Asset\Asset; use Pmpr\Module\Optimization\Optimizer\Buffer\Config; use Pmpr\Module\Optimization\Optimizer\Buffer\Test; use Pmpr\Module\Optimization\Optimizer\Cache\Cache; use Pmpr\Module\Optimization\Optimizer\HTML\HTML; use Pmpr\Module\Optimization\Optimizer\Media\Media; use Pmpr\Module\Optimization\Optimizer\SpecialPage\SpecialPage; class Optimizer extends Common { public function mameiwsayuyquoeq() { HTML::symcgieuakksimmu(); Cache::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Media::symcgieuakksimmu(); SpecialPage::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\160\154\x61\x74\145\x5f\x72\145\x64\x69\162\x65\143\164", [$this, "\x67\151\x77\171\163\153\167\167\x6d\x63\151\x65\x75\141\143\x71"], 999); } public function giwyskwwmcieuacq() { $uiewakwqscemywuo = new Config(["\160\x61\164\x68" => $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(self::gyiksueiaeykqaqq)]); new Buffer(new Test($uiewakwqscemywuo, ["\x6c\157\x67\x67\145\x72" => $this->waasecgmwoucqoqa()])); } }
