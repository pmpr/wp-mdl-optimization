<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf88a1c26f3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\x73\163\x65\164\163\x5f"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\144\145\154\x61\x79\137"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
