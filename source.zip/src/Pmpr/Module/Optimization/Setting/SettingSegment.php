<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce7059178ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\163\x73\145\164\x73\x5f"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\x64\145\x6c\x61\171\x5f"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
