<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb0c5939             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\163\x73\145\164\163\137"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\144\x65\154\x61\x79\x5f"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
