<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1504adf49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\x61\163\x73\145\164\163\x5f"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\144\x65\x6c\141\171\137"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
