<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2337171efe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\163\163\x65\x74\163\x5f"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\144\145\x6c\141\171\137"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
