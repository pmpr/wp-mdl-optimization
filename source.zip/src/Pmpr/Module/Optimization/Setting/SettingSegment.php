<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d323439fdb4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\x61\x73\163\x65\164\x73\x5f"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\x64\145\154\x61\171\137"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
