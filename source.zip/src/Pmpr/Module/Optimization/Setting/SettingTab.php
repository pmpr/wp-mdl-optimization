<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dbbdd5e733e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; class SettingTab { }
