<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69a35d5c5b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; class Purge extends Common { public function ckuaeyecaekkkwqs($post = null) : bool { $macmssugksugukws = [self::ywskismomwmcsqam, self::scwmgoegsukauoku, self::cssaaweyquokqaeq, self::aqugcqsyeisayuog, self::sgoswgskyiiwkyuo]; $iueymcwwscwqkiyq = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ucwmcwqmqwaymkkc($post); if (!in_array($iueymcwwscwqkiyq, $macmssugksugukws, true)) { goto uookseqsmsqgweuy; } return false; uookseqsmsqgweuy: $gcgsqcoqciockquc = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->oequuauskyumwyau(); return !($gcgsqcoqciockquc && self::ukwaycqmyyuekwqg === $gcgsqcoqciockquc->action); } }
