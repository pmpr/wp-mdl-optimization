<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a54fbc54301             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; abstract class Common extends BaseClass implements CommonInterface { }
