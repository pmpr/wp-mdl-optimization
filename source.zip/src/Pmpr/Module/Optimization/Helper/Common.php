<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; abstract class Common extends BaseClass implements CommonInterface { }
