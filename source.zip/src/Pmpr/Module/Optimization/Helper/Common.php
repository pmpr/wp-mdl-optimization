<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba5a468b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; use Pmpr\Common\Foundation\Functions\Helper\Common as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; abstract class Common extends BaseClass implements CommonInterface { }
