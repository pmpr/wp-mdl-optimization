<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350189c616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; use Pmpr\Common\Foundation\Traits\InstanceTrait; class Helper extends Common { use InstanceTrait; public function gagsyqagguwwauac() : I18N { return $this->symcgieuakksimmu(I18N::class); } public function eioauiqeyweiokag() : Purge { return $this->symcgieuakksimmu(Purge::class); } }
