<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bec25a4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; use Pmpr\Common\Foundation\Traits\InstanceTrait; class Helper extends Common { use InstanceTrait; public function gagsyqagguwwauac() : I18N { return $this->symcgieuakksimmu(I18N::class); } public function eioauiqeyweiokag() : Purge { return $this->symcgieuakksimmu(Purge::class); } }
