<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6689b42493617             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization; use Pmpr\Common\Foundation\Process\Queue as BaseClass; use Pmpr\Module\Optimization\Interfaces\CommonInterface; class Queue extends BaseClass implements CommonInterface { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group = self::kgswyesggeyekgmg; } }
