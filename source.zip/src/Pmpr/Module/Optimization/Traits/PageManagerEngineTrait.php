<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afa619aaca2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\PageManager\Engine; trait PageManagerEngineTrait { protected ?Engine $pageManagerEngine = null; public function wkagassgcaqeosio() : Engine { if ($this->pageManagerEngine) { goto eqemoayymokeqaqi; } $this->pageManagerEngine = Engine::symcgieuakksimmu(); eqemoayymokeqaqi: return $this->pageManagerEngine; } }
