<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dc2456c625             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\PageManager\Engine; trait PageManagerEngineTrait { protected ?Engine $pageManagerEngine = null; public function wkagassgcaqeosio() : Engine { if ($this->pageManagerEngine) { goto qgegkeomwscwwiuw; } $this->pageManagerEngine = Engine::symcgieuakksimmu(); qgegkeomwscwwiuw: return $this->pageManagerEngine; } }
