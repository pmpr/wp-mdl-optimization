<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a555dadc1bf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\PageManager\Engine; trait PageManagerEngineTrait { protected ?Engine $pageManagerEngine = null; public function wkagassgcaqeosio() : Engine { if ($this->pageManagerEngine) { goto siuyaemoiiqyoggo; } $this->pageManagerEngine = Engine::symcgieuakksimmu(); siuyaemoiiqyoggo: return $this->pageManagerEngine; } }
