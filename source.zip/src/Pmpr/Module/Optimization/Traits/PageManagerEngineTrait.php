<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7139a54fa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\PageManager\Engine; trait PageManagerEngineTrait { protected ?Engine $pageManagerEngine = null; public function wkagassgcaqeosio() : Engine { if ($this->pageManagerEngine) { goto wagqgeqymeqoeuyi; } $this->pageManagerEngine = Engine::symcgieuakksimmu(); wagqgeqymeqoeuyi: return $this->pageManagerEngine; } }
