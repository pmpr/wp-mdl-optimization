<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d249276cd51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\Helper\Helper; trait HelperTrait { protected ?Helper $nativeHelper = null; public function isgmmgcaqsguwias() : Helper { if ($this->nativeHelper) { goto ysoqeuugiuswykyu; } $this->nativeHelper = new Helper(); ysoqeuugiuswykyu: return $this->nativeHelper; } }
