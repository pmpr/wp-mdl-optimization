<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e0f163107a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Common\Foundation\Interfaces\IconInterface; trait AlertTrait { public function kciwwegaqoqscqeo(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::uwykoocikuusgwyw, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function myysooquiyucgueg(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::oyycwgguwwuseiym, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function symouyowemaacayu() : string { $wkaqekwwgqsqwcoi = $this->kciwwegaqoqscqeo(["\143\x6c\x61\x73\x73" => "\x69\143\157\156\x2d\x6d\144"]); $uamcoiueqaamsqma = __("\x4f\160\x74\151\x6f\156\163\x20\164\x68\x61\x74\x20\143\x6f\156\x73\x75\x6d\x65\x20\143\x6f\x69\x6e\163\56", PR__MDL__OPTIMIZATION); return $wkaqekwwgqsqwcoi . $uamcoiueqaamsqma; } }
