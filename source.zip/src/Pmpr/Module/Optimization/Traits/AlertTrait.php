<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Common\Foundation\Interfaces\IconInterface; trait AlertTrait { public function kciwwegaqoqscqeo(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::uwykoocikuusgwyw, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function myysooquiyucgueg(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::oyycwgguwwuseiym, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function symouyowemaacayu() : string { $wkaqekwwgqsqwcoi = $this->kciwwegaqoqscqeo(["\143\154\141\163\x73" => "\x69\143\157\x6e\x2d\155\144"]); $uamcoiueqaamsqma = __("\117\x70\164\x69\x6f\x6e\x73\40\164\x68\x61\x74\x20\x63\157\x6e\x73\x75\155\145\x20\x63\157\x69\x6e\163\x2e", PR__MDL__OPTIMIZATION); return $wkaqekwwgqsqwcoi . $uamcoiueqaamsqma; } }
