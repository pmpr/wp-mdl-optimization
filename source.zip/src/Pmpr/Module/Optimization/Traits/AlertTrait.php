<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af1935df9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Common\Foundation\Interfaces\IconInterface; trait AlertTrait { public function kciwwegaqoqscqeo(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::uwykoocikuusgwyw, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function myysooquiyucgueg(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::oyycwgguwwuseiym, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function symouyowemaacayu() : string { $wkaqekwwgqsqwcoi = $this->kciwwegaqoqscqeo(["\x63\154\x61\163\x73" => "\x69\143\x6f\156\55\155\144"]); $uamcoiueqaamsqma = __("\117\x70\x74\151\x6f\x6e\163\x20\x74\150\x61\164\40\x63\x6f\x6e\163\165\155\x65\x20\x63\157\x69\x6e\x73\x2e", PR__MDL__OPTIMIZATION); return $wkaqekwwgqsqwcoi . $uamcoiueqaamsqma; } }
