<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dd893c52c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Common\Foundation\Interfaces\IconInterface; trait AlertTrait { public function kciwwegaqoqscqeo(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::uwykoocikuusgwyw, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function myysooquiyucgueg(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::oyycwgguwwuseiym, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function symouyowemaacayu() : string { $wkaqekwwgqsqwcoi = $this->kciwwegaqoqscqeo(["\x63\x6c\x61\163\163" => "\151\x63\157\156\55\x6d\x64"]); $uamcoiueqaamsqma = __("\117\x70\164\x69\x6f\156\x73\40\x74\150\141\x74\x20\x63\x6f\x6e\163\x75\x6d\145\x20\143\x6f\x69\156\163\x2e", PR__MDL__OPTIMIZATION); return $wkaqekwwgqsqwcoi . $uamcoiueqaamsqma; } }
