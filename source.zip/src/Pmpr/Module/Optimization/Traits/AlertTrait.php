<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663757b0e9f86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Common\Foundation\Interfaces\IconInterface; trait AlertTrait { public function kciwwegaqoqscqeo(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::uwykoocikuusgwyw, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function myysooquiyucgueg(array $wwgucssaecqekuek = []) { return $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->cuoygaaeqeqcuggu(IconInterface::oyycwgguwwuseiym, $wwgucssaecqekuek, [self::uociqugwegocyuue => self::eskykugsoyoiukae]); } public function symouyowemaacayu() : string { $wkaqekwwgqsqwcoi = $this->kciwwegaqoqscqeo(["\143\154\x61\x73\163" => "\151\x63\x6f\156\x2d\155\144"]); $uamcoiueqaamsqma = __("\x4f\x70\x74\151\157\x6e\163\40\x74\150\x61\164\40\143\x6f\156\x73\165\x6d\145\40\x63\157\x69\156\163\56", PR__MDL__OPTIMIZATION); return $wkaqekwwgqsqwcoi . $uamcoiueqaamsqma; } }
