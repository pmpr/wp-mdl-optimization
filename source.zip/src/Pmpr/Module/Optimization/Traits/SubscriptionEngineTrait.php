<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afcef5beb16             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\Subscription\Engine; trait SubscriptionEngineTrait { protected ?Engine $subscriptionEngine = null; public function cqscwmqsgomkogoq() : Engine { if ($this->subscriptionEngine) { goto ayyyeiyaosoacoqm; } $this->subscriptionEngine = Engine::symcgieuakksimmu(); ayyyeiyaosoacoqm: return $this->subscriptionEngine; } }
