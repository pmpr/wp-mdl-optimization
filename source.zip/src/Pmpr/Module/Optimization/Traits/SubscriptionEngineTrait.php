<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6668a93c5745b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\Subscription\Engine; trait SubscriptionEngineTrait { protected ?Engine $subscriptionEngine = null; public function cqscwmqsgomkogoq() : Engine { if ($this->subscriptionEngine) { goto yssscwioiyygssec; } $this->subscriptionEngine = Engine::symcgieuakksimmu(); yssscwioiyygssec: return $this->subscriptionEngine; } }
