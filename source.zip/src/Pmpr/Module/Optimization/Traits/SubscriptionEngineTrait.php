<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f17f3222             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Traits; use Pmpr\Module\Optimization\Subscription\Engine; trait SubscriptionEngineTrait { protected ?Engine $subscriptionEngine = null; public function cqscwmqsgomkogoq() : Engine { if ($this->subscriptionEngine) { goto gqyyccceswkqcmaa; } $this->subscriptionEngine = Engine::symcgieuakksimmu(); gqyyccceswkqcmaa: return $this->subscriptionEngine; } }
