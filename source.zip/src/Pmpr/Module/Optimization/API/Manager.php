<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1504adf49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\157\160\x74\151\x6d\x69\x7a\141\164\151\157\156\x2d\x6d\x61\156\x61\147\x65\162"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x72\145\155\157\164\x65\57\147\145\164\x2d\x61\x70\x70\163"); if (is_wp_error($sogksuscggsicmac)) { goto cecuyayqoioasumi; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); cecuyayqoioasumi: return $sogksuscggsicmac; } }
