<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357314a443             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; class Manager extends API { public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\57\157\x70\164\151\155\151\172\x61\164\151\x6f\x6e\55\x6d\x61\x6e\141\x67\145\162"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->caokeucsksukesyo()->cqusmgskowmesgcg()->ooouaomcuuakuaii()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x72\x65\x6d\x6f\x74\x65\x2f\147\145\x74\x2d\141\x70\x70\x73"); if (!is_wp_error($sogksuscggsicmac)) { $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); } return $sogksuscggsicmac; } }
