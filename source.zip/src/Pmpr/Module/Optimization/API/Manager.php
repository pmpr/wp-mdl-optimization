<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c783a6833             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\x6f\x70\164\151\155\x69\172\141\164\x69\x6f\156\x2d\155\141\156\141\x67\145\162"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\162\x65\155\157\164\x65\57\x67\145\164\55\141\160\x70\x73"); if (is_wp_error($sogksuscggsicmac)) { goto oksqsucimimsswcg; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); oksqsucimimsswcg: return $sogksuscggsicmac; } }
