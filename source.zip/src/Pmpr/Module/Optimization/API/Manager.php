<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6648bed4e3da1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API implements CommonInterface { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\57\157\160\164\151\155\151\172\141\x74\151\157\x6e\55\x6d\x61\156\141\x67\145\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(self::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\162\x65\x6d\157\164\x65\x2f\147\x65\164\55\141\x70\160\163"); if (is_wp_error($sogksuscggsicmac)) { goto qsygcycwieukkgwc; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue); qsygcycwieukkgwc: return $sogksuscggsicmac; } }
