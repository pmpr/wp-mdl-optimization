<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79d4da80             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\57\157\160\x74\x69\155\151\x7a\x61\x74\151\157\156\x2d\155\x61\156\141\147\x65\162"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\162\145\x6d\157\x74\145\x2f\x67\145\x74\x2d\141\x70\160\163"); if (is_wp_error($sogksuscggsicmac)) { goto cecuyayqoioasumi; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); cecuyayqoioasumi: return $sogksuscggsicmac; } }
