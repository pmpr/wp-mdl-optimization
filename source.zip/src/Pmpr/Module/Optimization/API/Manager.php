<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665b6a8b74913             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API implements CommonInterface { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\157\x70\164\x69\x6d\151\172\x61\x74\x69\x6f\x6e\x2d\x6d\x61\156\x61\x67\x65\162"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(self::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\x72\145\155\157\164\145\x2f\x67\x65\164\55\x61\x70\160\163"); if (is_wp_error($sogksuscggsicmac)) { goto qsygcycwieukkgwc; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue); qsygcycwieukkgwc: return $sogksuscggsicmac; } }
