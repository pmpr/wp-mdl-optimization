<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90c227ba3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API implements CommonInterface { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\57\x6f\x70\x74\151\155\x69\x7a\x61\x74\x69\x6f\x6e\55\x6d\141\x6e\x61\x67\145\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(self::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x72\x65\x6d\x6f\x74\x65\57\147\x65\164\x2d\x61\x70\x70\x73"); if (is_wp_error($sogksuscggsicmac)) { goto yiowgigkkwsoqcci; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue); yiowgigkkwsoqcci: return $sogksuscggsicmac; } }
