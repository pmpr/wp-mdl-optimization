<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d24006e45d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\x6f\160\x74\151\x6d\x69\172\x61\x74\151\x6f\156\x2d\155\141\x6e\141\x67\145\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x72\x65\155\x6f\x74\x65\57\147\x65\164\55\141\160\x70\x73"); if (is_wp_error($sogksuscggsicmac)) { goto cecuyayqoioasumi; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); cecuyayqoioasumi: return $sogksuscggsicmac; } }
