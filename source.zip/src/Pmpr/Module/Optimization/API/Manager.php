<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a58598b21ed             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API implements CommonInterface { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\x6f\160\164\x69\x6d\x69\x7a\x61\164\151\157\156\55\x6d\141\156\141\x67\145\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(self::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x72\145\x6d\157\164\x65\57\147\x65\164\55\x61\160\160\x73"); if (is_wp_error($sogksuscggsicmac)) { goto kocqqoyymosmuksu; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue); kocqqoyymosmuksu: return $sogksuscggsicmac; } }
