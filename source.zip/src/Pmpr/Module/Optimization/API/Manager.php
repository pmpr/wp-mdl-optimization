<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d249276cd51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\57\157\160\164\x69\155\151\x7a\141\164\151\x6f\x6e\x2d\x6d\x61\x6e\x61\x67\145\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x72\145\155\x6f\164\145\x2f\147\145\164\x2d\141\160\x70\x73"); if (is_wp_error($sogksuscggsicmac)) { goto cecuyayqoioasumi; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); cecuyayqoioasumi: return $sogksuscggsicmac; } }
