<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666978e4a7c7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Module\Optimization\Interfaces\CommonInterface; use Pmpr\Module\Optimization\Traits\CommonTrait; class Manager extends API implements CommonInterface { use CommonTrait; public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\x6f\x70\164\151\155\x69\x7a\x61\164\151\157\156\55\x6d\141\x6e\x61\147\x65\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(self::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\162\145\155\157\x74\145\x2f\x67\145\164\55\x61\160\x70\x73"); if (is_wp_error($sogksuscggsicmac)) { goto quwcqmyokicssyew; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, self::uiwqcumqkgikqyue); quwcqmyokicssyew: return $sogksuscggsicmac; } }
