<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c4e0adc06c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([self::kekcgssiyagioocg => 5, self::wuowaiyouwecckaw => "\x6f\x70\164\x5f\x73\x70\145\x65\144\137\164\x65\163\x74", self::ysgwugcqguggmigq => __("\105\154\145\x63\x74\145\x64\40\x50\141\147\x65\163\x27\x73\x20\x53\x70\x65\145\144", PR__MDL__OPTIMIZATION), self::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
