<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32f1aa2d0a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([Constants::kekcgssiyagioocg => 5, Constants::wuowaiyouwecckaw => "\157\160\x74\x5f\163\x70\x65\145\144\x5f\x74\x65\163\x74", Constants::ysgwugcqguggmigq => __("\105\154\x65\143\x74\x65\144\x20\x50\x61\x67\145\163\x27\x73\x20\x53\x70\x65\145\144", PR__MDL__OPTIMIZATION), Constants::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
