<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b61878830b2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([self::kekcgssiyagioocg => 5, self::wuowaiyouwecckaw => "\157\160\x74\137\163\x70\145\145\x64\x5f\x74\x65\x73\x74", self::ysgwugcqguggmigq => __("\105\x6c\145\143\164\145\144\x20\120\x61\x67\145\163\x27\x73\40\123\160\145\x65\x64", PR__MDL__OPTIMIZATION), self::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
