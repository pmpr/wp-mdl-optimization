<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd253c8f77d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([self::kekcgssiyagioocg => 5, self::wuowaiyouwecckaw => "\157\x70\x74\x5f\x73\160\x65\145\x64\137\x74\145\163\164", self::ysgwugcqguggmigq => __("\105\x6c\145\143\x74\x65\144\x20\120\141\x67\145\x73\x27\163\40\x53\160\145\145\x64", PR__MDL__OPTIMIZATION), self::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
