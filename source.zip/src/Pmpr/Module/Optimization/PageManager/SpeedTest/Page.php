<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b9397c5c62b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([self::kekcgssiyagioocg => 5, self::wuowaiyouwecckaw => "\x6f\160\164\x5f\163\x70\x65\x65\144\137\164\x65\163\x74", self::ysgwugcqguggmigq => __("\105\154\145\x63\x74\x65\x64\x20\120\x61\147\145\x73\47\x73\40\x53\160\x65\x65\144", PR__MDL__OPTIMIZATION), self::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
