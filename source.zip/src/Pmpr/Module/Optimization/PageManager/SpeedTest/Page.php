<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f17f3222             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([self::kekcgssiyagioocg => 5, self::wuowaiyouwecckaw => "\x6f\x70\x74\x5f\163\160\x65\145\144\137\x74\145\x73\x74", self::ysgwugcqguggmigq => __("\x45\154\145\143\x74\145\144\40\x50\141\x67\x65\163\47\x73\40\123\x70\145\145\x64", PR__MDL__OPTIMIZATION), self::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
