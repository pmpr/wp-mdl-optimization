<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebb592725             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Impression extends Common { public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::cgaumaacsaeauwqy)->guiaswksukmgageq(__("\x49\x6d\x70\x72\145\x73\163\151\157\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\111\x6d\160\162\145\163\x73\x69\157\x6e\x73", PR__MDL__OPTIMIZATION))->wiskakymeaywyeuw($this->akuociswqmoigkas())->qemeyueyiwgsokuc()->ckaeqgiaiqwsccke(50)->eesuqwkusmukgwma(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::auqoykcmsiauccao)->gswweykyogmsyawy(__("\x55\122\114", PR__MDL__OPTIMIZATION)))->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::ciywsqoeiymemsys)->gswweykyogmsyawy(__("\123\x74\141\164\x75\163", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, self::uowmiwoiaoekusui, __("\x45\x78\x63\x6c\x75\x64\145\144", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(2, self::ckayguugsawsacqu, __("\x49\156\x63\154\x75\x64\x65\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(self::uowmiwoiaoekusui)); parent::ewaqwooqoqmcoomi(); } }
