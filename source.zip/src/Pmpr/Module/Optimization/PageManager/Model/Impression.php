<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aeb001123c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Impression extends Common { public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::cgaumaacsaeauwqy)->guiaswksukmgageq(__("\x49\155\x70\x72\x65\163\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x49\155\160\x72\x65\163\163\x69\157\x6e\163", PR__MDL__OPTIMIZATION))->wiskakymeaywyeuw($this->akuociswqmoigkas())->qemeyueyiwgsokuc()->ckaeqgiaiqwsccke(50)->eesuqwkusmukgwma(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::auqoykcmsiauccao)->gswweykyogmsyawy(__("\x55\x52\114", PR__MDL__OPTIMIZATION)))->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::ciywsqoeiymemsys)->gswweykyogmsyawy(__("\123\x74\141\x74\165\x73", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, self::uowmiwoiaoekusui, __("\x45\170\143\x6c\x75\x64\145\144", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(2, self::ckayguugsawsacqu, __("\x49\x6e\x63\x6c\165\144\145\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(self::uowmiwoiaoekusui)); parent::ewaqwooqoqmcoomi(); } }
