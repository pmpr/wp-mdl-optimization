<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a57ce0afbe8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Impression extends Common { public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::cgaumaacsaeauwqy)->guiaswksukmgageq(__("\111\x6d\x70\162\x65\x73\x73\151\157\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x49\155\160\x72\145\163\x73\x69\x6f\156\x73", PR__MDL__OPTIMIZATION))->wiskakymeaywyeuw($this->akuociswqmoigkas())->qemeyueyiwgsokuc()->ckaeqgiaiqwsccke(50)->eesuqwkusmukgwma(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::auqoykcmsiauccao)->gswweykyogmsyawy(__("\125\122\x4c", PR__MDL__OPTIMIZATION)))->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::ciywsqoeiymemsys)->gswweykyogmsyawy(__("\x53\x74\x61\164\165\x73", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, self::uowmiwoiaoekusui, __("\x45\170\x63\154\165\144\x65\x64", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(2, self::ckayguugsawsacqu, __("\x49\156\143\154\x75\144\x65\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(self::uowmiwoiaoekusui)); parent::ewaqwooqoqmcoomi(); } }
