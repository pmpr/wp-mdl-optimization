<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68855d388b9a0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Impression extends Common { public function register() { $this->saemoowcasogykak(IconInterface::cgaumaacsaeauwqy)->guiaswksukmgageq(__('Impression', PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__('Impressions', PR__MDL__OPTIMIZATION))->eesuqwkusmukgwma(); $this->ecmiqywsauuoccwo(Constants::weiosaewqequuyuq); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::auqoykcmsiauccao)->gswweykyogmsyawy(__('URL', PR__MDL__OPTIMIZATION)))->cquokmemekqqywgi($eqwoegegiamegqsm->yyuiuwgokmwioomq(Constants::ciywsqoeiymemsys)->gswweykyogmsyawy(__('Status', PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::uowmiwoiaoekusui, __('Excluded', PR__MDL__OPTIMIZATION))->kesomeowemmyygey(2, Constants::ckayguugsawsacqu, __('Included', PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::uowmiwoiaoekusui)->qassieeyqwaysucq()); parent::uwmqacgewuauagai(); } }
