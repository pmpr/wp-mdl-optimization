<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637d2bee1dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Impression extends Common { public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::cgaumaacsaeauwqy)->guiaswksukmgageq(__("\x49\155\x70\162\x65\x73\163\151\157\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\111\155\x70\162\145\163\163\151\x6f\x6e\x73", PR__MDL__OPTIMIZATION))->wiskakymeaywyeuw($this->akuociswqmoigkas())->qemeyueyiwgsokuc()->ckaeqgiaiqwsccke(50)->eesuqwkusmukgwma(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::auqoykcmsiauccao)->gswweykyogmsyawy(__("\x55\x52\114", PR__MDL__OPTIMIZATION)))->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::ciywsqoeiymemsys)->gswweykyogmsyawy(__("\x53\164\x61\164\x75\x73", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, self::uowmiwoiaoekusui, __("\105\x78\x63\154\165\x64\x65\144", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(2, self::ckayguugsawsacqu, __("\111\156\x63\x6c\165\x64\x65\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(self::uowmiwoiaoekusui)); parent::ewaqwooqoqmcoomi(); } }
