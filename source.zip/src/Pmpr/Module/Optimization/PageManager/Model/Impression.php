<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd253c8f77d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Impression extends Common { public $timestamps = null; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::cgaumaacsaeauwqy)->guiaswksukmgageq(__("\111\155\x70\162\x65\x73\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\111\x6d\160\x72\x65\163\x73\x69\157\156\163", PR__MDL__OPTIMIZATION))->wiskakymeaywyeuw($this->akuociswqmoigkas())->qemeyueyiwgsokuc()->ckaeqgiaiqwsccke(50)->eesuqwkusmukgwma(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::auqoykcmsiauccao)->gswweykyogmsyawy(__("\125\x52\114", PR__MDL__OPTIMIZATION)))->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::ciywsqoeiymemsys)->gswweykyogmsyawy(__("\x53\164\x61\164\x75\163", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, self::uowmiwoiaoekusui, __("\105\170\x63\x6c\x75\144\x65\x64", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(2, self::ckayguugsawsacqu, __("\x49\x6e\143\154\x75\x64\x65\144", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(self::uowmiwoiaoekusui)); parent::ewaqwooqoqmcoomi(); } }
