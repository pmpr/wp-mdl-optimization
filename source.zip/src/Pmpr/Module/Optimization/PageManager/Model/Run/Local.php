<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66afcef5beb16             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\157\x63\x61\154\40\122\165\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\143\x61\x6c\x20\x52\165\156\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\120\162\x65\x6c\157\x61\x64", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\x41\x63\164\x69\157\156", PR__MDL__OPTIMIZATION))); } }
