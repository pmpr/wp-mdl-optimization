<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a3b3fc9b6de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\114\x6f\143\141\154\x20\x52\165\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\x6f\143\141\x6c\x20\x52\165\156\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\x72\145\x6c\x6f\x61\144", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\101\x63\x74\151\157\x6e", PR__MDL__OPTIMIZATION))); } }
