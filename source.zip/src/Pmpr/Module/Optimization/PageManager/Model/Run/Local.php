<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4181e072c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\x63\x61\x6c\x20\122\165\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\143\x61\154\40\x52\165\156\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\120\162\145\154\157\141\x64", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\x41\143\x74\151\x6f\156", PR__MDL__OPTIMIZATION))); } }
