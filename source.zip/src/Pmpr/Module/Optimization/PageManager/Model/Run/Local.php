<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aeb001123c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\143\141\154\x20\x52\165\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\x63\x61\x6c\40\x52\x75\x6e\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\x72\x65\x6c\157\x61\x64", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\x41\143\164\x69\x6f\x6e", PR__MDL__OPTIMIZATION))); } }
