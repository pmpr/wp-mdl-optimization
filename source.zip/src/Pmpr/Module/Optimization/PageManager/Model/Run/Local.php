<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2162b04da4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\114\x6f\143\141\154\x20\122\165\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\143\x61\154\40\122\x75\156\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x41\143\x74\x69\x6f\156", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\x50\x72\x65\154\157\x61\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
