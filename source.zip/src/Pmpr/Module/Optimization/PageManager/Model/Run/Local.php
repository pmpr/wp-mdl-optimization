<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aff7366c1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\114\157\x63\x61\154\40\x52\x75\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\157\143\141\x6c\40\x52\x75\x6e\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\120\162\x65\154\x6f\x61\144", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\101\143\164\151\x6f\x6e", PR__MDL__OPTIMIZATION))); } }
