<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d230b1b85af             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\143\141\154\x20\122\x75\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\157\143\141\154\x20\122\x75\156\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x41\143\x74\151\x6f\156", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\120\162\x65\154\157\141\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
