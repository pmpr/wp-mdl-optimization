<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665872dfe6b03             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\x63\141\154\40\x52\x75\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\157\x63\x61\x6c\x20\122\x75\x6e\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\162\145\154\157\x61\x64", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\101\x63\x74\151\157\x6e", PR__MDL__OPTIMIZATION))); } }
