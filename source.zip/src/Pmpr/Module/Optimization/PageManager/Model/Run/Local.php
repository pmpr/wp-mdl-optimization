<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758115135c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function register() { $this->guiaswksukmgageq(__("\114\x6f\x63\x61\154\40\x52\x75\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\143\x61\154\x20\122\x75\156\163", PR__MDL__OPTIMIZATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x41\x63\164\151\157\x6e", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\120\x72\145\154\157\x61\144", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
