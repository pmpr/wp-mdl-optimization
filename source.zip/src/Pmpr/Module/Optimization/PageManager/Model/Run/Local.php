<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665875e35aad0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\x63\141\154\x20\x52\165\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\157\x63\x61\154\x20\x52\165\156\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\120\x72\145\x6c\157\141\144", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\x41\x63\x74\x69\157\x6e", PR__MDL__OPTIMIZATION))); } }
