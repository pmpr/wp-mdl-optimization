<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668682bec25a4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\143\141\154\40\x52\x75\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\157\143\x61\154\x20\x52\165\x6e\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\120\x72\x65\154\157\141\144", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\x41\143\x74\x69\157\156", PR__MDL__OPTIMIZATION))); } }
