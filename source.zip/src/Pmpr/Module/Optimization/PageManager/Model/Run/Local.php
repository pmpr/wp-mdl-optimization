<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d1de2caabf8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\114\157\143\141\x6c\x20\x52\x75\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\x63\141\154\x20\122\165\156\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x41\x63\x74\151\x6f\x6e", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\120\162\x65\154\157\x61\144", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
