<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a6a10b62e31             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\157\143\141\x6c\x20\122\x75\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\157\143\141\x6c\x20\122\165\x6e\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\x72\145\154\157\x61\144", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\x41\143\x74\x69\x6f\x6e", PR__MDL__OPTIMIZATION))); } }
