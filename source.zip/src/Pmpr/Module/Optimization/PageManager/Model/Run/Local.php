<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec4797d504             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\x63\141\x6c\x20\x52\x75\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\157\143\141\154\40\x52\165\x6e\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\162\x65\154\x6f\141\x64", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\101\143\164\x69\157\x6e", PR__MDL__OPTIMIZATION))); } }
