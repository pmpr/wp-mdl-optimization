<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66373458f3af9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\114\x6f\143\141\154\x20\122\165\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\157\143\141\x6c\x20\x52\165\x6e\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\120\x72\145\154\x6f\141\x64", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\x41\143\x74\151\157\x6e", PR__MDL__OPTIMIZATION))); } }
