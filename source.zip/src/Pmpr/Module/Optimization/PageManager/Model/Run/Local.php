<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a5875d8609d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\157\143\x61\x6c\40\122\x75\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\157\143\x61\154\x20\122\165\x6e\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\x72\x65\154\x6f\141\144", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\101\143\x74\151\x6f\x6e", PR__MDL__OPTIMIZATION))); } }
