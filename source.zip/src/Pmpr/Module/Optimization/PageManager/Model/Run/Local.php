<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350bd82c2a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\x6f\143\141\x6c\40\122\165\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\143\x61\154\40\122\165\x6e\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\162\x65\x6c\x6f\x61\x64", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\101\x63\x74\151\157\156", PR__MDL__OPTIMIZATION))); } }
