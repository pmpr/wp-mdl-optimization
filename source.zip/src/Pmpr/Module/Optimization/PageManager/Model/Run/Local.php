<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6d38ae4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\114\x6f\x63\141\154\x20\122\x75\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\157\x63\x61\x6c\x20\x52\x75\x6e\163", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(self::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->kesomeowemmyygey(1, self::iwksyuwwwkucsisq, __("\x50\162\145\x6c\x6f\141\144", PR__MDL__OPTIMIZATION))->gswweykyogmsyawy(__("\101\143\x74\151\x6f\156", PR__MDL__OPTIMIZATION))); } }
