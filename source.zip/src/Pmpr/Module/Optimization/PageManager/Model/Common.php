<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb0c5939             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\x69\141\154\137\x70\x61\147\145"; const wqqksssaoggqceky = "\x64\151\x73\x63\162\151\155\x69\x6e\x61\x74\x6f\162"; const swkaqiikoaickuui = "\157\x70\164\151\155\151\x7a\145"; const ccoesaeoiusskiew = "\162\145\x2d\157\x70\x74\151\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\145\x5f\156\x6f\156\x63\x65"; const hwawamsmicyywemy = "\x63\x61\x63\150\x65\137\x73\x74\x61\x74\x75\163"; }
