<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66375048491fe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\x61\154\x5f\160\x61\147\145"; const mcewqquusaugsmmm = "\163\160\x65\x63\x69\141\154\x5f\x70\x61\147\145\163"; const wqqksssaoggqceky = "\144\151\x73\x63\x72\151\x6d\151\x6e\141\x74\157\x72"; }
