<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2ec2cd5b75             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\x69\x61\x6c\x5f\x70\141\147\x65"; const mcewqquusaugsmmm = "\x73\x70\145\x63\x69\x61\x6c\137\160\141\147\145\x73"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\x6d\151\156\141\x74\x6f\x72"; const swkaqiikoaickuui = "\157\x70\164\151\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\x72\145\55\x6f\160\164\x69\x6d\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\x67\x65\x5f\156\157\156\143\x65"; const hwawamsmicyywemy = "\143\141\143\150\145\137\x73\x74\141\164\165\163"; }
