<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             666978e4a7c7f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\141\154\x5f\160\141\147\145"; const mcewqquusaugsmmm = "\x73\160\145\143\x69\x61\x6c\137\x70\141\x67\145\163"; const wqqksssaoggqceky = "\144\151\x73\x63\x72\x69\x6d\x69\156\141\164\x6f\x72"; }
