<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31ce4ed382             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\141\x6c\137\160\141\147\x65"; const mcewqquusaugsmmm = "\163\x70\x65\x63\151\x61\154\x5f\160\141\147\145\163"; const wqqksssaoggqceky = "\x64\151\x73\x63\x72\151\x6d\151\x6e\x61\x74\x6f\162"; const swkaqiikoaickuui = "\157\160\164\x69\155\151\172\x65"; const ccoesaeoiusskiew = "\x72\x65\55\157\160\164\x69\x6d\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\x67\145\x5f\156\x6f\156\143\145"; const hwawamsmicyywemy = "\x63\141\x63\x68\x65\137\x73\x74\x61\164\x75\x73"; }
