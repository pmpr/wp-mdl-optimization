<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa800b89726             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\x63\151\141\x6c\x5f\160\x61\147\x65"; const wqqksssaoggqceky = "\144\151\x73\x63\162\151\x6d\151\x6e\x61\164\x6f\162"; const swkaqiikoaickuui = "\x6f\160\x74\x69\x6d\x69\172\x65"; const ccoesaeoiusskiew = "\x72\145\55\157\x70\x74\x69\x6d\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\145\137\x6e\157\x6e\x63\145"; const hwawamsmicyywemy = "\x63\x61\143\150\145\137\x73\164\141\164\165\163"; }
