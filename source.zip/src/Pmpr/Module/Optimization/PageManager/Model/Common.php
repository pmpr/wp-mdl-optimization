<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6673f43f6aa4f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\151\141\154\x5f\160\141\x67\145"; const mcewqquusaugsmmm = "\x73\x70\x65\143\x69\x61\x6c\x5f\x70\x61\x67\x65\x73"; const wqqksssaoggqceky = "\x64\151\163\143\x72\x69\x6d\151\156\141\164\157\x72"; }
