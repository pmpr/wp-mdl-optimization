<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a869bef5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\x63\x69\x61\154\137\x70\x61\x67\x65"; const wqqksssaoggqceky = "\144\151\163\143\x72\x69\x6d\151\x6e\141\164\157\x72"; const swkaqiikoaickuui = "\157\160\x74\x69\155\x69\x7a\145"; const ccoesaeoiusskiew = "\x72\x65\55\x6f\160\164\x69\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\145\x5f\x6e\x6f\156\143\x65"; const hwawamsmicyywemy = "\143\141\143\150\145\x5f\x73\164\x61\164\x75\x73"; }
