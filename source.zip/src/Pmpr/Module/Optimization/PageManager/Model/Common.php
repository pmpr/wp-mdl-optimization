<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ada53dffd1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\141\154\x5f\160\141\x67\x65"; const mcewqquusaugsmmm = "\163\160\145\143\x69\x61\x6c\x5f\160\141\x67\145\163"; const wqqksssaoggqceky = "\144\x69\163\143\162\x69\155\151\x6e\x61\164\x6f\x72"; }
