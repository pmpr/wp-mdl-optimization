<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4c4bca826             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\x69\141\154\137\160\x61\x67\x65"; const mcewqquusaugsmmm = "\163\x70\145\143\151\x61\154\137\x70\x61\x67\x65\163"; const wqqksssaoggqceky = "\x64\x69\163\143\162\151\155\x69\156\141\164\x6f\x72"; const swkaqiikoaickuui = "\157\x70\x74\x69\155\151\172\145"; const ccoesaeoiusskiew = "\162\x65\55\157\x70\x74\x69\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\147\x65\x5f\156\x6f\x6e\143\145"; const hwawamsmicyywemy = "\x63\141\143\150\x65\137\163\164\x61\x74\165\163"; }
