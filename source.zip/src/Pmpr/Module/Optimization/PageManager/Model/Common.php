<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665c381549fb7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\151\x61\x6c\x5f\x70\x61\x67\145"; const mcewqquusaugsmmm = "\x73\160\145\143\x69\141\154\137\x70\141\x67\x65\163"; const wqqksssaoggqceky = "\x64\151\x73\143\x72\x69\x6d\x69\156\141\164\157\162"; }
