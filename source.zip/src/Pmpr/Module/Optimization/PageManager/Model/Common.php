<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf6837cd4a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\151\141\x6c\x5f\160\141\147\145"; const mcewqquusaugsmmm = "\x73\x70\145\143\x69\141\x6c\137\x70\141\x67\145\163"; const wqqksssaoggqceky = "\144\x69\x73\143\x72\151\155\x69\156\141\164\x6f\162"; const swkaqiikoaickuui = "\x6f\x70\164\151\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\162\145\55\157\160\164\x69\x6d\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\x65\x5f\156\x6f\x6e\143\x65"; const hwawamsmicyywemy = "\143\x61\x63\150\145\137\x73\164\141\164\165\163"; }
