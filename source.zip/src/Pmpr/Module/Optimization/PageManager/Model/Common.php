<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d3161a77b51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\151\x61\x6c\x5f\x70\141\147\x65"; const mcewqquusaugsmmm = "\163\160\x65\143\151\x61\154\x5f\x70\141\x67\145\163"; const wqqksssaoggqceky = "\144\151\x73\143\x72\x69\x6d\151\156\141\164\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\164\x69\155\x69\172\x65"; const ccoesaeoiusskiew = "\x72\145\55\157\x70\164\151\155\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\x65\x5f\156\x6f\156\x63\145"; const hwawamsmicyywemy = "\x63\141\143\x68\145\x5f\x73\164\x61\x74\x75\163"; }
