<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c7b6e5555be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\x63\151\141\154\x5f\x70\141\x67\145"; const mcewqquusaugsmmm = "\x73\x70\145\x63\151\141\154\137\x70\x61\x67\x65\163"; const wqqksssaoggqceky = "\x64\151\163\143\162\x69\x6d\151\156\x61\164\157\162"; }
