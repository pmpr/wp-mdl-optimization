<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aeb001123c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\x69\141\154\137\x70\141\x67\145"; const mcewqquusaugsmmm = "\x73\x70\x65\x63\151\141\154\x5f\x70\x61\147\x65\x73"; const wqqksssaoggqceky = "\144\x69\163\x63\162\x69\x6d\x69\156\141\164\x6f\x72"; }
