<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d316fa74495             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\x69\x61\154\x5f\160\141\147\145"; const mcewqquusaugsmmm = "\x73\160\145\x63\151\x61\154\x5f\x70\141\x67\x65\x73"; const wqqksssaoggqceky = "\144\151\163\x63\162\151\x6d\151\x6e\x61\164\157\x72"; const swkaqiikoaickuui = "\157\x70\x74\x69\155\151\172\x65"; const ccoesaeoiusskiew = "\x72\145\55\157\x70\164\151\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\147\145\x5f\x6e\157\x6e\143\x65"; const hwawamsmicyywemy = "\x63\x61\143\x68\145\137\x73\x74\141\x74\165\163"; }
