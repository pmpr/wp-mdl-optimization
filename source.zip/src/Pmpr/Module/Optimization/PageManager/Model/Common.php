<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672357314a443             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\x61\x6c\x5f\x70\x61\x67\x65"; const wqqksssaoggqceky = "\x64\151\x73\x63\x72\151\155\151\x6e\141\164\157\162"; const swkaqiikoaickuui = "\x6f\160\164\x69\155\151\172\x65"; const ccoesaeoiusskiew = "\162\x65\55\157\x70\x74\x69\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\x67\x65\137\x6e\x6f\x6e\143\145"; const hwawamsmicyywemy = "\x63\141\143\150\145\137\163\x74\141\164\x75\163"; }
