<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf4bb05f1e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\x61\154\137\x70\141\x67\145"; const mcewqquusaugsmmm = "\163\x70\x65\x63\151\x61\x6c\137\x70\141\147\145\x73"; const wqqksssaoggqceky = "\x64\x69\163\x63\x72\x69\x6d\151\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\157\160\x74\151\x6d\x69\x7a\x65"; const ccoesaeoiusskiew = "\162\x65\x2d\157\160\x74\151\x6d\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\162\147\145\x5f\156\x6f\x6e\x63\x65"; const hwawamsmicyywemy = "\143\x61\x63\150\145\137\163\x74\x61\x74\165\163"; }
