<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb243a19822             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\x61\154\137\x70\141\x67\145"; const mcewqquusaugsmmm = "\163\160\145\143\x69\141\154\x5f\x70\141\x67\145\163"; const wqqksssaoggqceky = "\x64\x69\163\143\x72\x69\155\x69\x6e\x61\164\x6f\x72"; const swkaqiikoaickuui = "\157\x70\164\x69\155\151\x7a\145"; const ccoesaeoiusskiew = "\162\145\x2d\x6f\160\x74\151\x6d\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\x67\145\137\156\x6f\x6e\143\145"; const hwawamsmicyywemy = "\143\141\143\x68\x65\x5f\163\164\x61\x74\165\163"; }
