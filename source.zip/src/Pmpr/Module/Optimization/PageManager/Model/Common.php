<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce68cc41878             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\x69\x61\x6c\x5f\160\141\x67\145"; const mcewqquusaugsmmm = "\x73\160\145\x63\x69\141\x6c\137\160\141\147\x65\163"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\x6d\x69\156\141\x74\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\164\151\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\162\145\x2d\x6f\160\164\151\155\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\x65\137\156\x6f\156\143\145"; const hwawamsmicyywemy = "\143\x61\x63\150\x65\x5f\163\164\x61\x74\165\x73"; }
