<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8e1ec93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\x63\x69\x61\154\137\160\x61\x67\145"; const wqqksssaoggqceky = "\144\x69\163\143\162\151\x6d\151\x6e\141\164\157\x72"; const swkaqiikoaickuui = "\157\x70\x74\151\155\151\172\145"; const ccoesaeoiusskiew = "\162\x65\x2d\x6f\x70\164\x69\x6d\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\147\145\x5f\x6e\157\156\x63\x65"; const hwawamsmicyywemy = "\143\141\x63\x68\145\137\x73\164\x61\x74\x75\163"; }
