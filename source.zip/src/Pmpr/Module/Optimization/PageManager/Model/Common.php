<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11a697384             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\x69\x61\154\137\160\x61\x67\145"; const mcewqquusaugsmmm = "\163\160\x65\143\x69\141\x6c\x5f\x70\x61\x67\145\163"; const wqqksssaoggqceky = "\144\x69\163\x63\x72\151\155\151\x6e\x61\x74\157\x72"; const swkaqiikoaickuui = "\x6f\x70\x74\x69\x6d\x69\x7a\x65"; const ccoesaeoiusskiew = "\x72\x65\x2d\x6f\160\164\151\x6d\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\x65\x5f\156\157\156\x63\x65"; const hwawamsmicyywemy = "\143\x61\x63\x68\x65\x5f\x73\x74\x61\164\x75\x73"; }
