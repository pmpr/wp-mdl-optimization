<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4e02be33a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\x63\x69\x61\x6c\x5f\160\x61\x67\145"; const mcewqquusaugsmmm = "\x73\160\x65\x63\151\x61\154\x5f\x70\x61\147\x65\x73"; const wqqksssaoggqceky = "\144\151\163\143\x72\151\155\151\x6e\x61\164\157\x72"; const swkaqiikoaickuui = "\157\x70\164\151\155\151\172\145"; const ccoesaeoiusskiew = "\x72\x65\x2d\157\x70\164\151\155\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\147\x65\137\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\143\141\x63\x68\145\137\x73\x74\141\x74\165\x73"; }
