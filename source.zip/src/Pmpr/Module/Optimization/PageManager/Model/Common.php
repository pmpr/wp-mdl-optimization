<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae90c7cdea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\151\141\x6c\x5f\x70\141\x67\x65"; const mcewqquusaugsmmm = "\x73\160\x65\143\x69\141\x6c\x5f\160\141\x67\145\x73"; const wqqksssaoggqceky = "\144\151\163\x63\x72\x69\x6d\x69\x6e\141\x74\x6f\x72"; const swkaqiikoaickuui = "\157\x70\164\x69\x6d\151\x7a\145"; const ccoesaeoiusskiew = "\162\145\55\x6f\160\x74\x69\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\x65\137\x6e\x6f\x6e\143\145"; const hwawamsmicyywemy = "\143\141\143\x68\x65\x5f\x73\164\x61\x74\165\x73"; }
