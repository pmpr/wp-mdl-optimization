<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31c5704a7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\151\141\154\137\x70\x61\147\145"; const mcewqquusaugsmmm = "\163\160\145\143\151\141\154\x5f\x70\141\x67\145\163"; const wqqksssaoggqceky = "\x64\151\163\x63\162\x69\155\151\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\x74\x69\155\151\x7a\145"; const ccoesaeoiusskiew = "\162\x65\x2d\157\x70\164\151\155\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\145\x5f\x6e\157\x6e\x63\x65"; const hwawamsmicyywemy = "\143\x61\143\150\145\137\x73\x74\141\164\x75\163"; }
