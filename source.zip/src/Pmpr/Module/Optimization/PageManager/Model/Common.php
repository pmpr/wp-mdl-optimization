<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668daba5a468b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\143\151\x61\154\137\160\x61\147\145"; const mcewqquusaugsmmm = "\x73\x70\x65\x63\151\x61\x6c\x5f\160\x61\x67\145\x73"; const wqqksssaoggqceky = "\x64\151\163\143\162\151\155\151\x6e\x61\x74\157\x72"; }
