<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cf8fcabf8fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\151\141\x6c\137\x70\141\147\145"; const mcewqquusaugsmmm = "\163\160\145\x63\151\141\154\x5f\x70\141\x67\145\163"; const wqqksssaoggqceky = "\x64\151\x73\143\162\151\155\151\156\141\x74\157\x72"; const swkaqiikoaickuui = "\157\x70\x74\151\x6d\x69\172\145"; const ccoesaeoiusskiew = "\x72\x65\x2d\157\x70\164\x69\x6d\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\x65\x5f\156\x6f\156\x63\x65"; const hwawamsmicyywemy = "\x63\141\143\150\145\x5f\x73\x74\x61\x74\x75\163"; }
