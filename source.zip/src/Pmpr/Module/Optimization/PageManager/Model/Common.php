<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668f1c10d873e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\151\x61\x6c\x5f\x70\x61\x67\145"; const mcewqquusaugsmmm = "\x73\160\145\143\x69\141\154\137\160\x61\x67\145\163"; const wqqksssaoggqceky = "\144\151\163\x63\x72\x69\155\151\x6e\x61\x74\x6f\162"; }
