<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6686855490492             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\143\x69\141\154\x5f\160\141\147\x65"; const mcewqquusaugsmmm = "\163\160\x65\143\151\x61\154\x5f\160\141\147\145\x73"; const wqqksssaoggqceky = "\x64\x69\163\143\162\151\155\151\156\x61\x74\157\x72"; }
