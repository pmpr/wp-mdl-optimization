<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132a7dc622             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\x61\154\x5f\160\x61\x67\145"; const wqqksssaoggqceky = "\144\x69\x73\143\162\151\x6d\151\156\x61\164\x6f\162"; const swkaqiikoaickuui = "\x6f\160\164\151\155\151\172\x65"; const ccoesaeoiusskiew = "\162\x65\x2d\157\x70\x74\x69\x6d\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\147\145\x5f\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\x63\141\143\x68\x65\137\163\164\x61\x74\165\163"; }
