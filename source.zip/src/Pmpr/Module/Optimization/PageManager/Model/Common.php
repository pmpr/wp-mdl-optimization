<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581d1c9b1ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\141\x6c\137\160\x61\x67\145"; const wqqksssaoggqceky = "\144\x69\x73\143\162\151\155\x69\156\x61\x74\x6f\162"; const swkaqiikoaickuui = "\x6f\x70\x74\x69\155\x69\x7a\145"; const ccoesaeoiusskiew = "\162\x65\55\x6f\160\x74\x69\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\145\x5f\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\143\141\143\150\145\x5f\163\164\x61\164\x75\x73"; }
