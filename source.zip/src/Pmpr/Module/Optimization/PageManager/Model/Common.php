<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665aff7366c1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\151\141\x6c\x5f\x70\141\147\x65"; const mcewqquusaugsmmm = "\x73\160\x65\x63\x69\141\x6c\x5f\160\x61\147\145\x73"; const wqqksssaoggqceky = "\144\x69\163\143\162\151\155\x69\x6e\x61\x74\x6f\162"; }
