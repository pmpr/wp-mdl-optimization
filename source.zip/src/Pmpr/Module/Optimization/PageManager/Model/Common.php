<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cba0bde7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\141\154\137\160\141\147\x65"; const mcewqquusaugsmmm = "\x73\160\145\x63\151\141\154\137\x70\x61\x67\145\x73"; const wqqksssaoggqceky = "\144\x69\163\x63\162\x69\x6d\x69\156\x61\164\157\162"; }
