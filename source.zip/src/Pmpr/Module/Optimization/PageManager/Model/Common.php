<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16dc16c38             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\143\x69\x61\154\x5f\x70\141\147\x65"; const mcewqquusaugsmmm = "\x73\x70\145\143\151\141\154\137\160\141\x67\145\x73"; const wqqksssaoggqceky = "\144\x69\x73\143\x72\x69\x6d\x69\156\x61\164\157\x72"; const swkaqiikoaickuui = "\x6f\x70\x74\x69\x6d\151\x7a\x65"; const ccoesaeoiusskiew = "\x72\145\55\157\x70\164\151\155\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\147\145\x5f\x6e\x6f\156\143\x65"; const hwawamsmicyywemy = "\x63\x61\x63\x68\145\137\x73\164\x61\164\x75\163"; }
