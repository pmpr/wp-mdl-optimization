<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66583cebac3c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\x63\151\x61\154\x5f\x70\x61\147\145"; const mcewqquusaugsmmm = "\x73\160\145\143\151\x61\154\x5f\160\141\147\145\x73"; const wqqksssaoggqceky = "\144\x69\x73\x63\x72\x69\x6d\151\156\141\164\157\162"; }
