<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d30394ae64b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\143\151\x61\x6c\137\160\141\x67\145"; const mcewqquusaugsmmm = "\163\x70\x65\143\x69\x61\154\x5f\x70\141\x67\x65\163"; const wqqksssaoggqceky = "\144\x69\163\x63\162\x69\155\x69\x6e\x61\164\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\x74\151\155\151\x7a\x65"; const ccoesaeoiusskiew = "\162\x65\x2d\x6f\160\164\151\x6d\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\147\145\x5f\x6e\x6f\x6e\143\x65"; const hwawamsmicyywemy = "\x63\x61\143\150\145\x5f\163\x74\x61\164\165\x73"; }
