<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634ff5a86835             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\x63\151\141\x6c\137\160\141\x67\x65"; const mcewqquusaugsmmm = "\x73\x70\145\143\x69\141\154\x5f\x70\x61\x67\145\163"; const wqqksssaoggqceky = "\144\151\x73\143\x72\151\x6d\x69\x6e\x61\164\157\162"; }
