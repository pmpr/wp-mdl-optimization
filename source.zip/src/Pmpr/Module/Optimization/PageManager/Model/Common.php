<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66869afc6c108             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\143\151\x61\154\137\160\x61\147\x65"; const mcewqquusaugsmmm = "\163\160\145\x63\151\141\x6c\x5f\160\x61\147\x65\163"; const wqqksssaoggqceky = "\144\151\x73\143\x72\151\155\151\156\141\164\157\x72"; }
