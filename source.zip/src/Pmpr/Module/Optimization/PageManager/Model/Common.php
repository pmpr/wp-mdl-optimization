<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708194f632             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\x69\x61\154\137\160\141\147\x65"; const mcewqquusaugsmmm = "\x73\x70\145\x63\151\141\154\x5f\160\x61\147\145\163"; const wqqksssaoggqceky = "\144\x69\x73\x63\x72\151\155\x69\x6e\141\x74\157\x72"; }
