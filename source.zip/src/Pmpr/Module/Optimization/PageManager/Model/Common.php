<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675819c784426             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\151\x61\154\137\x70\x61\147\145"; const wqqksssaoggqceky = "\x64\x69\163\x63\162\151\x6d\151\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\x74\151\155\x69\172\145"; const ccoesaeoiusskiew = "\x72\145\55\157\x70\164\x69\155\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\147\x65\x5f\156\157\156\143\145"; const hwawamsmicyywemy = "\x63\141\143\150\145\137\x73\164\141\164\165\x73"; }
