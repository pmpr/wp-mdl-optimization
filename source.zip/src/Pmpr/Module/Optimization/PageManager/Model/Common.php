<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665872dfe6b03             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\151\x61\154\x5f\x70\x61\147\x65"; const mcewqquusaugsmmm = "\x73\x70\x65\143\x69\141\x6c\137\x70\x61\x67\x65\163"; const wqqksssaoggqceky = "\x64\x69\x73\143\x72\151\x6d\151\x6e\141\164\x6f\x72"; }
