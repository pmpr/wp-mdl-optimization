<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af1935df9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\x69\x61\154\137\x70\x61\147\145"; const mcewqquusaugsmmm = "\163\160\x65\143\x69\141\154\x5f\x70\x61\147\145\163"; const wqqksssaoggqceky = "\x64\x69\163\x63\162\x69\x6d\151\x6e\x61\164\x6f\162"; }
