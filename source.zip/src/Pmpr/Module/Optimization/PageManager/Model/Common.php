<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2db183c14             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\x69\141\154\137\x70\141\x67\x65"; const mcewqquusaugsmmm = "\163\160\x65\x63\x69\141\154\137\x70\x61\x67\145\163"; const wqqksssaoggqceky = "\144\x69\163\x63\162\x69\155\151\x6e\x61\164\x6f\x72"; }
