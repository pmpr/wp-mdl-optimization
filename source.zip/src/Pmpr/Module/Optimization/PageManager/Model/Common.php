<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ec4797d504             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\151\x61\x6c\137\160\141\147\145"; const mcewqquusaugsmmm = "\163\160\x65\x63\151\x61\154\137\x70\141\147\x65\163"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\155\x69\156\141\x74\x6f\162"; }
