<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6637389418f87             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\151\141\x6c\137\160\x61\147\145"; const mcewqquusaugsmmm = "\x73\x70\145\x63\151\x61\154\137\x70\x61\x67\145\x73"; const wqqksssaoggqceky = "\144\x69\x73\143\x72\151\155\151\x6e\x61\164\x6f\162"; }
