<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a608b965f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\x61\x6c\x5f\160\x61\147\145"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\151\x6d\x69\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\157\160\x74\151\155\x69\x7a\x65"; const ccoesaeoiusskiew = "\162\145\x2d\x6f\x70\x74\151\x6d\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\x65\137\x6e\x6f\x6e\143\x65"; const hwawamsmicyywemy = "\143\141\x63\x68\145\137\x73\164\141\x74\165\x73"; }
