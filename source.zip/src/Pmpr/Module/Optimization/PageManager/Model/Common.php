<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a69ee00a3ca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\143\x69\141\154\x5f\x70\x61\x67\x65"; const mcewqquusaugsmmm = "\x73\160\x65\x63\x69\x61\x6c\x5f\160\x61\147\145\163"; const wqqksssaoggqceky = "\x64\151\x73\143\x72\x69\155\151\x6e\x61\164\157\162"; }
