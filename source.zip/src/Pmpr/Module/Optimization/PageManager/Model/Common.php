<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668724cd3b441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\x69\141\x6c\x5f\160\x61\147\x65"; const mcewqquusaugsmmm = "\163\160\145\143\151\141\154\137\x70\x61\147\x65\163"; const wqqksssaoggqceky = "\144\x69\163\143\162\151\x6d\151\156\141\x74\x6f\162"; }
