<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66369e99bb80d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\143\x69\141\154\137\x70\x61\x67\x65"; const mcewqquusaugsmmm = "\x73\160\145\143\151\141\x6c\x5f\x70\141\147\x65\x73"; const wqqksssaoggqceky = "\144\151\x73\143\162\151\155\x69\156\x61\164\x6f\x72"; }
