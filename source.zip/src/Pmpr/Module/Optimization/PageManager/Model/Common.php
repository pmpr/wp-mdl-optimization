<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ad9ca28a94             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\141\x6c\137\160\141\x67\145"; const mcewqquusaugsmmm = "\x73\160\145\x63\x69\x61\x6c\137\x70\x61\147\145\x73"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\x6d\x69\x6e\x61\164\x6f\x72"; }
