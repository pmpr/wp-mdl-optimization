<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c4e0adc06c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\151\x61\154\137\160\141\147\x65"; const mcewqquusaugsmmm = "\163\160\145\x63\151\141\154\137\160\x61\147\x65\x73"; const wqqksssaoggqceky = "\144\x69\x73\x63\162\x69\155\x69\156\141\164\x6f\x72"; }
