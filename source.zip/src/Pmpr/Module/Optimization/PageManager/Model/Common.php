<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d31f6c057e7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\151\x61\154\137\x70\x61\147\x65"; const mcewqquusaugsmmm = "\x73\160\x65\x63\x69\141\x6c\137\x70\x61\x67\x65\163"; const wqqksssaoggqceky = "\144\x69\163\143\162\151\155\151\156\x61\x74\157\x72"; const swkaqiikoaickuui = "\x6f\x70\x74\151\x6d\x69\x7a\x65"; const ccoesaeoiusskiew = "\162\x65\55\157\160\164\151\x6d\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\x67\145\x5f\x6e\157\x6e\x63\x65"; const hwawamsmicyywemy = "\x63\141\x63\150\x65\137\x73\164\x61\x74\x75\x73"; }
