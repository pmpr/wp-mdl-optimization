<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f51179ea7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\x69\x61\x6c\x5f\160\x61\147\x65"; const mcewqquusaugsmmm = "\163\x70\x65\x63\151\x61\154\137\x70\141\147\145\x73"; const wqqksssaoggqceky = "\144\x69\163\143\x72\x69\x6d\151\x6e\141\x74\x6f\162"; }
