<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66697656b7da9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\141\x6c\137\160\x61\147\145"; const mcewqquusaugsmmm = "\163\x70\x65\x63\151\x61\x6c\x5f\160\141\x67\145\x73"; const wqqksssaoggqceky = "\x64\151\163\x63\x72\151\x6d\151\156\x61\164\157\x72"; }
