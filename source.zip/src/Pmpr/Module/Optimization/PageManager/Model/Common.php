<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d32325cda1b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\141\x6c\137\160\x61\x67\x65"; const mcewqquusaugsmmm = "\x73\160\x65\143\151\x61\154\137\x70\141\147\x65\163"; const wqqksssaoggqceky = "\x64\x69\163\143\162\x69\x6d\151\x6e\141\x74\157\x72"; const swkaqiikoaickuui = "\x6f\160\x74\151\155\x69\x7a\145"; const ccoesaeoiusskiew = "\162\x65\x2d\157\x70\x74\151\155\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\x67\145\x5f\156\x6f\156\x63\x65"; const hwawamsmicyywemy = "\x63\x61\143\x68\145\137\163\164\141\x74\x75\x73"; }
