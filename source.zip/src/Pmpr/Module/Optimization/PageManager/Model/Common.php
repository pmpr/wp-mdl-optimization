<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665dbcb8a031d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\x61\154\137\x70\141\x67\145"; const mcewqquusaugsmmm = "\x73\x70\x65\x63\x69\141\154\x5f\160\141\x67\x65\x73"; const wqqksssaoggqceky = "\144\x69\x73\143\162\151\x6d\151\x6e\141\x74\x6f\162"; }
