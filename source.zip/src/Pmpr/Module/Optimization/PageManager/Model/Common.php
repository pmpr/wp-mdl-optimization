<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b6d38ae4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\x63\151\x61\x6c\137\160\x61\x67\x65"; const mcewqquusaugsmmm = "\163\x70\x65\143\x69\141\154\137\x70\141\147\x65\163"; const wqqksssaoggqceky = "\x64\x69\163\x63\162\151\155\x69\x6e\x61\164\157\x72"; }
