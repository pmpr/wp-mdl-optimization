<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665e2e8b4802f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\x69\x61\x6c\x5f\x70\141\x67\145"; const mcewqquusaugsmmm = "\x73\x70\145\x63\x69\141\154\137\x70\x61\x67\x65\163"; const wqqksssaoggqceky = "\x64\x69\x73\143\162\x69\x6d\x69\x6e\x61\164\x6f\x72"; }
