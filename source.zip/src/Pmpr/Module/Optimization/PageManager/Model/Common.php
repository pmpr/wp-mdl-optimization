<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758115135c8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\141\x6c\x5f\160\x61\x67\x65"; const wqqksssaoggqceky = "\144\151\x73\x63\162\x69\155\151\x6e\141\164\x6f\x72"; const swkaqiikoaickuui = "\157\160\x74\x69\155\x69\172\x65"; const ccoesaeoiusskiew = "\162\145\55\x6f\x70\164\151\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\147\x65\137\x6e\157\156\x63\x65"; const hwawamsmicyywemy = "\143\141\143\150\x65\x5f\163\164\x61\x74\x75\x73"; }
