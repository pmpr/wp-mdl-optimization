<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29dc7ba6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\151\x61\x6c\x5f\160\141\147\145"; const wqqksssaoggqceky = "\x64\151\163\x63\x72\151\155\151\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\157\160\164\151\x6d\151\x7a\x65"; const ccoesaeoiusskiew = "\x72\x65\55\157\160\164\x69\155\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\x67\145\137\156\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\x63\141\x63\x68\145\x5f\163\164\x61\164\x75\x73"; }
