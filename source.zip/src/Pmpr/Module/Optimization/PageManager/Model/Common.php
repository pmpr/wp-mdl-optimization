<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b9397c5c62b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\141\154\137\160\141\x67\145"; const mcewqquusaugsmmm = "\163\160\x65\x63\x69\141\154\137\x70\x61\147\x65\163"; const wqqksssaoggqceky = "\x64\151\163\143\162\151\x6d\151\x6e\141\x74\157\162"; }
