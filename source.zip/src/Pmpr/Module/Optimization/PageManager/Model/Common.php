<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580890b0d1e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\151\141\154\x5f\160\141\147\x65"; const wqqksssaoggqceky = "\144\151\163\143\162\151\155\x69\156\141\x74\157\162"; const swkaqiikoaickuui = "\x6f\160\164\151\155\x69\172\x65"; const ccoesaeoiusskiew = "\162\145\55\157\x70\164\x69\x6d\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\147\145\137\156\x6f\156\143\145"; const hwawamsmicyywemy = "\143\141\x63\150\145\x5f\x73\164\141\x74\165\163"; }
