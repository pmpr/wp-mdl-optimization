<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665ae7eec53d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\x69\x61\154\x5f\x70\x61\x67\x65"; const mcewqquusaugsmmm = "\163\160\145\143\x69\141\x6c\137\160\141\147\x65\x73"; const wqqksssaoggqceky = "\144\x69\163\x63\x72\x69\x6d\151\x6e\141\164\x6f\162"; }
