<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66696e7e43c2d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\151\141\154\137\x70\141\147\145"; const mcewqquusaugsmmm = "\163\x70\145\x63\x69\x61\154\x5f\160\x61\x67\145\x73"; const wqqksssaoggqceky = "\x64\151\163\x63\x72\151\x6d\x69\156\141\x74\157\x72"; }
