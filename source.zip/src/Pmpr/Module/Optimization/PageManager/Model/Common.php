<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665f4289276f4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\x63\151\141\154\x5f\160\141\x67\145"; const mcewqquusaugsmmm = "\x73\x70\145\x63\x69\x61\x6c\x5f\x70\x61\x67\145\163"; const wqqksssaoggqceky = "\144\151\x73\x63\162\151\x6d\151\x6e\x61\x74\x6f\x72"; }
