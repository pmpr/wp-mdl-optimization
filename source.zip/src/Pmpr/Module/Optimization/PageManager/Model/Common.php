<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1342843d30             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\141\154\137\x70\x61\147\x65"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\155\x69\156\141\x74\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\x74\x69\155\151\x7a\x65"; const ccoesaeoiusskiew = "\x72\x65\55\157\160\x74\x69\155\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\x65\137\x6e\157\156\143\x65"; const hwawamsmicyywemy = "\x63\141\x63\150\145\137\163\164\141\164\x75\x73"; }
