<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce6e608ebb7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\151\x61\x6c\137\x70\x61\x67\x65"; const mcewqquusaugsmmm = "\163\x70\145\143\151\141\x6c\x5f\x70\141\x67\145\x73"; const wqqksssaoggqceky = "\144\x69\163\143\162\151\x6d\151\x6e\x61\164\157\162"; const swkaqiikoaickuui = "\x6f\x70\164\x69\155\x69\172\x65"; const ccoesaeoiusskiew = "\162\x65\x2d\x6f\x70\164\151\155\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\x65\137\x6e\157\156\143\145"; const hwawamsmicyywemy = "\143\141\x63\150\x65\137\x73\164\x61\164\165\163"; }
