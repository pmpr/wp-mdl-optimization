<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2f79d4da80             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\x63\151\x61\154\x5f\x70\x61\x67\145"; const mcewqquusaugsmmm = "\163\x70\x65\143\x69\x61\x6c\x5f\160\141\147\x65\x73"; const wqqksssaoggqceky = "\x64\x69\163\x63\162\x69\155\151\x6e\141\164\157\x72"; const swkaqiikoaickuui = "\157\x70\x74\x69\155\151\172\x65"; const ccoesaeoiusskiew = "\x72\145\55\157\160\164\x69\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\x67\145\137\156\x6f\x6e\143\145"; const hwawamsmicyywemy = "\143\x61\143\150\145\137\x73\x74\x61\164\165\x73"; }
