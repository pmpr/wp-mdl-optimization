<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d8c783a6833             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\141\x6c\137\x70\141\147\x65"; const mcewqquusaugsmmm = "\x73\x70\x65\143\x69\141\154\137\x70\141\147\145\163"; const wqqksssaoggqceky = "\144\x69\163\143\x72\x69\155\x69\156\141\164\157\x72"; const swkaqiikoaickuui = "\x6f\160\x74\x69\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\x72\x65\55\157\160\x74\x69\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\162\147\145\137\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\x63\x61\x63\150\145\137\x73\x74\141\164\165\x73"; }
