<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b5148c02d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\141\154\137\x70\x61\x67\x65"; const wqqksssaoggqceky = "\x64\x69\x73\143\x72\151\155\x69\156\141\x74\x6f\162"; const swkaqiikoaickuui = "\157\x70\x74\x69\x6d\151\172\145"; const ccoesaeoiusskiew = "\162\145\55\157\160\164\x69\155\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\x65\137\156\x6f\x6e\143\145"; const hwawamsmicyywemy = "\143\141\x63\x68\145\137\x73\164\x61\164\165\x73"; }
