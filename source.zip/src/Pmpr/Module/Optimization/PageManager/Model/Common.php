<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             664697c805b60             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\151\141\154\137\x70\141\x67\145"; const mcewqquusaugsmmm = "\x73\x70\145\x63\151\141\154\137\160\141\x67\145\x73"; const wqqksssaoggqceky = "\x64\x69\163\143\162\151\x6d\151\156\141\x74\x6f\x72"; }
