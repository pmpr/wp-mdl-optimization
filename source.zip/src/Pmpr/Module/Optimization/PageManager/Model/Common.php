<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fa68d1c92             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\x63\x69\x61\154\x5f\x70\x61\x67\x65"; const wqqksssaoggqceky = "\x64\151\x73\x63\162\151\155\151\x6e\141\x74\x6f\162"; const swkaqiikoaickuui = "\157\x70\164\x69\155\x69\172\x65"; const ccoesaeoiusskiew = "\x72\x65\x2d\x6f\160\164\x69\x6d\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\147\x65\x5f\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\x63\x61\x63\150\x65\137\163\164\141\164\x75\163"; }
