<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a0bdd937640             |
    |_______________________________________|
*/
 use Pmpr\Module\Optimization\Optimization; Optimization::symcgieuakksimmu();
