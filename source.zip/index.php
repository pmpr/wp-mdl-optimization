<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66d2337171efe             |
    |_______________________________________|
*/
 use Pmpr\Module\Optimization\Optimization; Optimization::symcgieuakksimmu();
