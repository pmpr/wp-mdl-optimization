<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6634f51179ea7             |
    |_______________________________________|
*/
 use Pmpr\Module\Optimization\Optimization; Optimization::symcgieuakksimmu();
