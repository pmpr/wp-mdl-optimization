<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             665af79314d69             |
    |_______________________________________|
*/
 use Pmpr\Module\Optimization\Optimization; Optimization::symcgieuakksimmu();
