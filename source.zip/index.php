<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66350bd82c2a9             |
    |_______________________________________|
*/
 use Pmpr\Module\Optimization\Optimization; Optimization::symcgieuakksimmu();
